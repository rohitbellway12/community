@props([
    'title' => 'Community | REIAC',
    'active' => 'home',
    'user' => auth()->user(),
    'sidebar' => true,
    'rightbar' => true,
    'notificationsCount' => 0,
    'testStats' => null,
    'testAttempts' => null,
    'activityProgress' => null,
])

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="bg-slate-100" x-data="{ mobileMenuOpen: false }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title }}</title>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="min-h-screen m-0 w-full max-w-none overflow-x-hidden bg-slate-100">
@php
    use App\Models\Follow;

    $user = $user ?? $profileUser ?? auth()->user();
    $profileUser = $profileUser ?? $user;
    $profile = $profile ?? $user?->profile ?? null;

    $isOwnProfile = auth()->check() && (int) auth()->id() === (int) ($user?->id ?? 0);

    $avatarUrl = $profile->avatar
        ? asset('storage/' . $profile->avatar)
        : 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=e2e8f0&color=0f172a&size=200';

    $coverUrl = $profile->cover_image
        ? asset('storage/' . $profile->cover_image)
        : 'https://images.unsplash.com/photo-1557683316-973673baf926?w=1200&h=400&fit=crop';

    $bio = $profile->bio
        ?? 'Passionate about learning, sharing knowledge and connecting with the community.';

    $location = $profile->location
        ?? $profile->city
        ?? $profile->country?->name;

    $joinedDate = $user->created_at?->format('F Y');

    $username = $profile->username;

    $activeTab = request()->query('tab', 'posts');
    if (!in_array($activeTab, ['posts', 'comments', 'followers', 'following', 'tests'])) {
        $activeTab = 'posts';
    }

    $followersCount = Follow::where('following_id', $user->id)->count();
    $followingCount = Follow::where('follower_id', $user->id)->count();

    $followers = collect();
    $following = collect();

    if ($activeTab === 'followers') {
        $followers = Follow::where('following_id', $user->id)
            ->with(['follower.profile'])
            ->latest()
            ->paginate(12, ['*'], 'followers_page')
            ->withQueryString();
    }

    if ($activeTab === 'following') {
        $following = Follow::where('follower_id', $user->id)
            ->with(['following.profile'])
            ->latest()
            ->paginate(12, ['*'], 'following_page')
            ->withQueryString();
    }
@endphp


<style>
    html, body {
        width: 100%;
        max-width: 100%;
        min-width: 0;
        margin: 0;
        padding: 0;
    }

    *, *::before, *::after {
        box-sizing: border-box;
    }

    /* ---------------------------------------------------------------
       Mobile profile/feed normalization
       The post feature markup intentionally contains small desktop
       utility text sizes. On phones those sizes become unreadable.
       Keep desktop untouched and normalize only <= 639px.
    --------------------------------------------------------------- */
    @media (max-width: 639px) {
        .community-profile-page {
            width: 100%;
            max-width: 100%;
            min-width: 0;
            overflow-x: hidden;
        }

        .community-profile-page .community-profile-shell {
            width: 100%;
            max-width: none;
            padding-left: .5rem !important;
            padding-right: .5rem !important;
            padding-top: .5rem !important;
            padding-bottom: 4.5rem !important;
        }

        .community-profile-page .community-profile-layout {
            display: block !important;
            width: 100%;
        }

        .community-profile-page .community-profile-main {
            width: 100% !important;
            max-width: none !important;
            min-width: 0 !important;
        }

        .community-profile-page .community-profile-main > * {
            min-width: 0;
            max-width: 100%;
        }

        /* Readable typography on small screens. */
        .community-profile-page [class~="text-[8px]"]  { font-size: .6875rem !important; line-height: 1rem !important; }
        .community-profile-page [class~="text-[9px]"]  { font-size: .6875rem !important; line-height: 1rem !important; }
        .community-profile-page [class~="text-[10px]"] { font-size: .75rem !important; line-height: 1.05rem !important; }
        .community-profile-page [class~="text-[11px]"] { font-size: .8125rem !important; line-height: 1.15rem !important; }
        .community-profile-page [class~="text-xs"]      { font-size: .75rem !important; line-height: 1.05rem !important; }

        /* Profile header */
        .community-profile-page .profile-header-card {
            border-radius: .875rem !important;
        }

        .community-profile-page .profile-cover {
            height: 9rem !important;
        }

        .community-profile-page .profile-header-content {
            padding-left: .875rem !important;
            padding-right: .875rem !important;
            padding-bottom: 1rem !important;
        }

        .community-profile-page .profile-stats {
            grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
            gap: .4rem !important;
            margin-top: 1rem !important;
            padding-top: 1rem !important;
        }

        .community-profile-page .profile-stat {
            padding: .65rem .35rem !important;
            border-radius: .65rem !important;
        }

        .community-profile-page .profile-tabs {
            gap: 1.25rem !important;
            margin-top: 1rem !important;
            padding-left: .15rem;
            padding-right: .15rem;
            -webkit-overflow-scrolling: touch;
        }

        /* Post cards */
        .community-profile-page .community-post-card {
            width: 100% !important;
            max-width: 100% !important;
            padding: .875rem !important;
            border-radius: .875rem !important;
        }

        .community-profile-page .community-post-media {
            width: 100% !important;
            height: 13.75rem !important;
            max-height: 13.75rem !important;
            border-radius: .75rem !important;
        }

        .community-profile-page .community-post-media img,
        .community-profile-page .community-post-media video {
            width: 100% !important;
            height: 100% !important;
            object-fit: contain !important;
        }

        /* Inputs/buttons should remain finger-friendly. */
        .community-profile-page textarea,
        .community-profile-page input,
        .community-profile-page select {
            font-size: .875rem !important;
        }

        .community-profile-page button,
        .community-profile-page a {
            -webkit-tap-highlight-color: transparent;
        }

        /* Modals fit comfortably on phones. */
        .community-profile-page [class*="max-w-[700px]"] {
            width: 100% !important;
            max-width: calc(100vw - 1rem) !important;
        }
    }

    @media (min-width: 640px) {
        .community-profile-page .community-post-media {
            height: 22.5rem;
        }
    }

    .community-profile-page .community-post-card {
        text-align: left !important;
    }

    .community-profile-page .community-post-title {
        text-align: left !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .community-profile-page .community-post-title h2,
    .community-profile-page .community-post-title h3,
    .community-profile-page .community-post-title a {
        text-align: left !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .community-profile-page .community-post-content,
    .community-profile-page .community-post-content * {
        text-align: left !important;
    }
</style>

<div class="community-profile-page min-h-screen bg-slate-100/60 text-slate-800 antialiased selection:bg-amber-400 selection:text-slate-950 pb-20 lg:pb-0">
    <div class="sticky top-0 z-50">
        <x-community.topbar :notifications-count="$notificationsCount" :user="$user" />
    </div>

    <div class="community-profile-shell max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div class="community-profile-layout grid grid-cols-1 lg:grid-cols-[280px_minmax(0,1fr)] gap-6 items-start">
            
            <x-community.sidebar :top-contributors="$topContributors ?? collect()" />

            <main class="community-profile-main min-w-0 w-full space-y-6">
                <div>
                    <a
                        href="{{ route('community.index') }}"
                        class="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-900 transition py-1"
                    >
                        <svg
                            class="w-4 h-4 shrink-0"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2.5"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M10 19l-7-7m0 0l7-7m-7 7h18"
                            />
                        </svg>
                        <span>Back to community feed</span>
                    </a>
                </div>

                <div class="profile-header-card bg-white rounded-2xl shadow-sm border border-slate-200/70 overflow-hidden">
                    <div class="profile-cover h-36 sm:h-48 md:h-60 w-full relative bg-slate-900">
                        <img
                            src="{{ $coverUrl }}"
                            alt="Profile cover"
                            class="w-full h-full object-cover"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-transparent"></div>
                    </div>

                    <div class="profile-header-content px-5 sm:px-8 pb-6 relative">
                        <div class="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 -mt-12 sm:-mt-16 md:-mt-20 mb-5 relative z-10">
                            <div class="relative w-fit">
                                <img
                                    src="{{ $avatarUrl }}"
                                    alt="{{ $user->name }}"
                                    class="w-24 h-24 sm:w-32 sm:h-32 md:w-36 md:h-36 rounded-full border-4 border-white object-cover shadow-md bg-white"
                                >
                                @if ($profile?->country)
                                    @php
                                        $isoCode = strtolower(trim($profile->country->iso_code ?: ''));
                                        if (!$isoCode && !empty($profile->country->code) && strlen(trim($profile->country->code)) === 2) {
                                            $isoCode = strtolower(trim($profile->country->code));
                                        }
                                    @endphp
                                    @if ($isoCode)
                                        <span class="absolute bottom-1 right-1 sm:bottom-1.5 sm:right-1.5 md:bottom-2 md:right-2 w-7 h-7 sm:w-8 sm:h-8 md:w-9 md:h-9 rounded-full border-2 sm:border-[2.5px] border-white shadow-md overflow-hidden bg-white flex items-center justify-center shrink-0"
                                              title="{{ $profile->country->name }}">
                                            <img
                                                src="https://flagcdn.com/w80/{{ $isoCode }}.png"
                                                alt="{{ $profile->country->name }}"
                                                class="w-full h-full object-cover rounded-full"
                                                loading="lazy"
                                                onerror="this.style.display='none'"
                                            >
                                        </span>
                                    @elseif (!empty($profile->country->flag) && (str_starts_with($profile->country->flag, 'http://') || str_starts_with($profile->country->flag, 'https://')))
                                        <span class="absolute bottom-1 right-1 sm:bottom-1.5 sm:right-1.5 md:bottom-2 md:right-2 w-7 h-7 sm:w-8 sm:h-8 md:w-9 md:h-9 rounded-full border-2 sm:border-[2.5px] border-white shadow-md overflow-hidden bg-white flex items-center justify-center shrink-0"
                                              title="{{ $profile->country->name }}">
                                            <img
                                                src="{{ $profile->country->flag }}"
                                                alt="{{ $profile->country->name }}"
                                                class="w-full h-full object-cover rounded-full"
                                                loading="lazy"
                                                onerror="this.style.display='none'"
                                            >
                                        </span>
                                    @elseif (!empty($profile->country->flag))
                                        <span class="absolute bottom-1 right-1 sm:bottom-1.5 sm:right-1.5 md:bottom-2 md:right-2 w-7 h-7 sm:w-8 sm:h-8 md:w-9 md:h-9 rounded-full border-2 sm:border-[2.5px] border-white shadow-md overflow-hidden bg-white flex items-center justify-center text-xs sm:text-sm shrink-0"
                                              title="{{ $profile->country->name }}">
                                            {{ $profile->country->flag }}
                                        </span>
                                    @else
                                        <span class="absolute bottom-2 right-2 w-4 h-4 sm:w-5 sm:h-5 bg-emerald-500 border-2 border-white rounded-full"></span>
                                    @endif
                                @else
                                    <span class="absolute bottom-2 right-2 w-4 h-4 sm:w-5 sm:h-5 bg-emerald-500 border-2 border-white rounded-full"></span>
                                @endif
                            </div>

                            <div class="flex flex-wrap items-center gap-2.5">
                                @if($isOwnProfile)
                                    <a
                                        href="{{ route('community.profile.edit') }}"
                                        class="bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs px-5 py-2.5 rounded-xl transition shadow-sm inline-flex items-center justify-center cursor-pointer"
                                    >
                                        Edit Profile
                                    </a>

                                    <button
                                        type="button"
                                        onclick="confirmAccountDelete()"
                                        class="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition shadow-sm inline-flex items-center justify-center cursor-pointer"
                                    >
                                        Delete Account
                                    </button>

                                    <form
                                        id="delete-account-form"
                                        action="{{ route('profile.destroy') }}"
                                        method="POST"
                                        style="display: none;"
                                    >
                                        @csrf
                                        @method('DELETE')
                                        <input type="hidden" name="password" id="delete-password">
                                    </form>
                                @else
                                    @php
                                        $isFollowingThisUser = auth()->check()
                                            ? \App\Models\Follow::where('follower_id', auth()->id())
                                                ->where('following_id', $user->id)
                                                ->exists()
                                            : false;
                                    @endphp
                                    <div
                                        x-data="{
                                            following: {{ $isFollowingThisUser ? 'true' : 'false' }},
                                            loading: false,
                                            toggleFollow() {
                                                @guest
                                                    window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                    return;
                                                @endguest

                                                if (this.loading) return;
                                                this.loading = true;

                                                fetch('{{ route('users.follow.toggle', $user) }}', {
                                                    method: 'POST',
                                                    headers: {
                                                        'Content-Type': 'application/json',
                                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                        'Accept': 'application/json'
                                                    }
                                                })
                                                .then(async response => {
                                                    if (response.status === 401) {
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return null;
                                                    }
                                                    return response.json();
                                                })
                                                .then(data => {
                                                    if (data && data.success && data.data) {
                                                        this.following = Boolean(data.data.following);
                                                    }
                                                })
                                                .catch(error => {
                                                    console.error('Follow error:', error);
                                                })
                                                .finally(() => {
                                                    this.loading = false;
                                                });
                                            }
                                        }"
                                    >
                                        <button
                                            type="button"
                                            @click="toggleFollow()"
                                            :disabled="loading"
                                            class="font-bold text-xs px-5 py-2.5 rounded-xl transition shadow-sm inline-flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                                            :class="following
                                                ? 'bg-white text-slate-700 hover:bg-red-50 hover:text-red-600 hover:border-red-200 border border-slate-200 shadow-xs'
                                                : 'bg-amber-400 hover:bg-amber-500 text-slate-950'"
                                        >
                                            <svg
                                                x-show="!loading && !following"
                                                class="w-3.5 h-3.5"
                                                fill="none"
                                                stroke="currentColor"
                                                stroke-width="2.5"
                                                viewBox="0 0 24 24"
                                            >
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                            </svg>
                                            <svg
                                                x-show="!loading && following"
                                                class="w-3.5 h-3.5 text-emerald-600"
                                                fill="none"
                                                stroke="currentColor"
                                                stroke-width="2.5"
                                                viewBox="0 0 24 24"
                                            >
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                                            </svg>
                                            <span x-text="following ? 'Following' : 'Follow'"></span>
                                        </button>
                                    </div>
                                @endif
                            </div>
                        </div>

                        <div class="space-y-2.5 min-w-0">
                            <div class="flex flex-wrap items-center gap-2">
                                <h1 class="text-xl sm:text-2xl font-extrabold text-[#0b1329] tracking-tight break-words">
                                    {{ $user->name }}
                                </h1>

                                @if($profile->pronouns)
                                    <span class="bg-blue-50 text-blue-600 text-[10px] font-bold px-2 py-0.5 rounded-md">
                                        {{ $profile->pronouns }}
                                    </span>
                                @endif
                            </div>

                            <p class="text-xs text-slate-400 font-medium break-all">
                                {{ '@' . $username }}
                            </p>

                            <p class="text-xs text-slate-600 leading-relaxed max-w-3xl break-words">
                                {{ $bio }}
                            </p>

                            <div class="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs font-medium text-slate-400 pt-1">
                                @if($location)
                                    <span class="flex items-center gap-1 min-w-0">
                                        <svg
                                            class="w-3.5 h-3.5 text-slate-400 shrink-0"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            viewBox="0 0 24 24"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"
                                            />
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"
                                            />
                                        </svg>
                                        <span class="truncate">{{ $location }}</span>
                                    </span>
                                @endif

                                @if($joinedDate)
                                    <span class="flex items-center gap-1 min-w-0">
                                        <svg
                                            class="w-3.5 h-3.5 text-slate-400 shrink-0"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            viewBox="0 0 24 24"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"
                                            />
                                        </svg>
                                        <span>Joined {{ $joinedDate }}</span>
                                    </span>
                                @endif
                            </div>
                        </div>

                        {{-- =========================================================================
                             REFERRAL CODE & SHARE LINK (OWN PROFILE ONLY)
                             ========================================================================= --}}
                        @if($isOwnProfile && !empty($user->referral_code))
                            <div class="mt-4 p-4 rounded-2xl bg-amber-50/70 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                                 x-data="{ copiedCode: false, copiedLink: false }">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
                                        🎁
                                    </div>
                                    <div>
                                        <div class="text-xs font-black text-slate-900 flex items-center gap-2">
                                            <span>Your Referral Code:</span>
                                            <span class="font-mono bg-white px-2 py-0.5 rounded-lg border border-amber-300 text-amber-800 tracking-wider font-bold select-all">{{ $user->referral_code }}</span>
                                        </div>
                                        <div class="text-[11px] text-slate-500 font-medium mt-0.5">
                                            Share your code or link with friends to earn contest referral points.
                                        </div>
                                    </div>
                                </div>

                                <div class="flex items-center gap-2 shrink-0">
                                    <button type="button"
                                            @click="navigator.clipboard.writeText('{{ $user->referral_code }}'); copiedCode = true; setTimeout(() => copiedCode = false, 2000)"
                                            class="px-3 py-1.5 rounded-xl border border-amber-300 bg-white hover:bg-amber-100 text-amber-900 font-bold text-xs transition cursor-pointer">
                                        <span x-show="!copiedCode">Copy Code</span>
                                        <span x-show="copiedCode" class="text-emerald-700 font-bold">✓ Copied</span>
                                    </button>

                                    <button type="button"
                                            @click="navigator.clipboard.writeText('{{ route('register') }}' + '?ref=' + '{{ $user->referral_code }}'); copiedLink = true; setTimeout(() => copiedLink = false, 2000)"
                                            class="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs transition cursor-pointer shadow-xs">
                                        <span x-show="!copiedLink">Share Link</span>
                                        <span x-show="copiedLink" class="text-white">✓ Link Copied</span>
                                    </button>
                                </div>
                            </div>
                        @endif

                        {{-- =========================================================================
                             PROFILE COMPLETION & ACTIVITY PROGRESS BAR (SET BY ADMIN)
                             ========================================================================= --}}
                        @if(isset($activityProgress) && !empty($activityProgress['total_count']))
                            <div class="mt-6 pt-6 border-t border-slate-100" x-data="{ checklistOpen: false }">
                                <div class="bg-gradient-to-br from-slate-50 to-indigo-50/40 p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-2xs">
                                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2.5">
                                        <div class="flex items-center gap-2.5">
                                            <div class="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"/></svg>
                                            </div>
                                            <div>
                                                <div class="flex items-center gap-2">
                                                    <h3 class="text-xs sm:text-sm font-black text-slate-900">
                                                        {{ $isOwnProfile ? 'Your Profile Completion' : 'Member Activity Strength' }}
                                                    </h3>
                                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-black {{ $activityProgress['percentage'] >= 100 ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-indigo-100 text-indigo-700 border border-indigo-200' }}">
                                                        {{ $activityProgress['percentage'] }}%
                                                    </span>
                                                </div>
                                                <p class="text-[11px] text-slate-500 font-medium mt-0.5">
                                                    {{ $activityProgress['completed_count'] }} of {{ $activityProgress['total_count'] }} activities completed
                                                    @if($activityProgress['percentage'] < 100 && $isOwnProfile)
                                                        • Complete remaining tasks to unlock full community trust!
                                                    @endif
                                                </p>
                                            </div>
                                        </div>

                                        <button type="button"
                                                @click="checklistOpen = !checklistOpen"
                                                class="self-start sm:self-auto text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition">
                                            <span x-text="checklistOpen ? 'Hide Tasks' : 'View Checklist'"></span>
                                            <svg class="w-3.5 h-3.5 transform transition-transform" :class="checklistOpen ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                        </button>
                                    </div>

                                    {{-- PROGRESS BAR --}}
                                    <div class="w-full bg-slate-200/80 rounded-full h-3 overflow-hidden p-0.5 shadow-inner">
                                        <div class="h-full rounded-full transition-all duration-700 ease-out {{ $activityProgress['percentage'] >= 100 ? 'bg-gradient-to-r from-emerald-500 to-teal-400' : ($activityProgress['percentage'] >= 50 ? 'bg-gradient-to-r from-amber-400 to-emerald-500' : 'bg-gradient-to-r from-indigo-500 to-indigo-600') }}"
                                             style="width: {{ $activityProgress['percentage'] }}%"></div>
                                    </div>

                                    {{-- EXPANDABLE CHECKLIST --}}
                                    <div x-show="checklistOpen"
                                         x-collapse
                                         class="mt-4 pt-4 border-t border-slate-200/70 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                        @foreach($activityProgress['activities'] as $act)
                                            <div class="flex items-center justify-between p-3 rounded-xl border transition {{ $act['is_completed'] ? 'bg-white/90 border-emerald-200 shadow-2xs' : 'bg-white border-slate-200 hover:border-indigo-200' }}">
                                                <div class="flex items-center gap-2.5 min-w-0 pr-2">
                                                    @if($act['is_completed'])
                                                        <div class="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
                                                            <svg class="w-3 h-3 stroke-[3]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                                                        </div>
                                                    @else
                                                        <div class="w-5 h-5 rounded-full border-2 border-slate-300 flex items-center justify-center shrink-0">
                                                            <div class="w-1.5 h-1.5 rounded-full bg-slate-300"></div>
                                                        </div>
                                                    @endif
                                                    <div class="min-w-0">
                                                        <div class="text-xs font-bold text-slate-800 truncate {{ $act['is_completed'] ? 'line-through text-slate-500' : '' }}">
                                                            {{ $act['title'] }}
                                                        </div>
                                                        <div class="text-[10px] text-slate-400 font-medium truncate">
                                                            +{{ $act['points'] }}% • {{ $act['description'] }}
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="shrink-0">
                                                    @if($act['is_completed'])
                                                        <span class="text-[10px] font-extrabold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                                                            Done
                                                        </span>
                                                    @elseif($isOwnProfile && !empty($act['action_url']))
                                                        <a href="{{ url($act['action_url']) }}"
                                                           class="text-[10px] font-bold text-white bg-indigo-600 hover:bg-indigo-700 px-2.5 py-1 rounded-lg shadow-xs transition inline-block">
                                                            {{ $act['action_label'] ?: 'Do it' }}
                                                        </a>
                                                    @else
                                                        <span class="text-[10px] font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md">
                                                            Pending
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        @endif

                        <div class="profile-stats grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-center mt-6 pt-6 border-t border-slate-100">
                            <div class="profile-stat p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['posts'] ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Posts</div>
                            </div>

                            <div class="profile-stat p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['comments'] ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Comments</div>
                            </div>

                            <div class="profile-stat p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['likes_received'] ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Likes</div>
                            </div>

                            <a href="{{ request()->fullUrlWithQuery(['tab' => 'followers', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                               class="profile-stat p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 hover:bg-amber-50 hover:border-amber-200 transition min-w-0 group">
                                <div class="text-lg font-extrabold text-[#0b1329] group-hover:text-amber-700">{{ number_format($followersCount) }}</div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Followers</div>
                            </a>

                            <a href="{{ request()->fullUrlWithQuery(['tab' => 'following', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                               class="profile-stat p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 hover:bg-amber-50 hover:border-amber-200 transition min-w-0 group">
                                <div class="text-lg font-extrabold text-[#0b1329] group-hover:text-amber-700">{{ number_format($followingCount) }}</div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Following</div>
                            </a>

                            <div class="profile-stat p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['referred'] ?? $user->stat?->referred_count ?? $user->referred_count ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Referred</div>
                            </div>
                        </div>

                        <div class="profile-tabs flex items-center gap-8 mt-6 border-b border-slate-200 text-xs sm:text-sm font-bold overflow-x-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'posts', 'page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'posts' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Posts
                            </a>

                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'comments', 'page' => null, 'posts_page' => null, 'comments_page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'comments' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Comments <span class="text-slate-400 font-semibold">{{ number_format($profileStats['comments'] ?? 0) }}</span>
                            </a>

                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'followers', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'followers' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Followers <span class="text-slate-400 font-semibold">{{ number_format($followersCount) }}</span>
                            </a>

                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'following', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'following' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                 Following <span class="text-slate-400 font-semibold">{{ number_format($followingCount) }}</span>
                             </a>

                             @if($isOwnProfile)
                                 <a
                                     href="{{ request()->fullUrlWithQuery(['tab' => 'tests', 'page' => null, 'posts_page' => null, 'comments_page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                                     class="pb-3 border-b-2 {{ $activeTab === 'tests' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                                 >
                                     Tests<span class="text-slate-400 font-semibold"> {{ $testStats ? ' (' . $testStats['total'] . ')' : '' }}</span>
                                 </a>
                             @endif
                         </div>

                        <div class="mt-6 space-y-4">
                            @if($activeTab === 'posts')
                            @forelse($posts as $post)
                            @php
                                $availableCategories = ($categories ?? collect());
                                $availableTags = ($tags ?? collect());
                                if ($availableCategories->isEmpty()) {
                                    $availableCategories = \App\Models\Category::query()->orderBy('name')->get();
                                }
                                if ($availableTags->isEmpty()) {
                                    $availableTags = \App\Models\Tag::query()->orderBy('name')->get();
                                }
                                                $author = $post->user;
                                                $profile = $author?->profile;

                                                $authorAvatar = $profile?->avatar
                                                    ? asset('storage/' . $profile->avatar)
                                                    : 'https://ui-avatars.com/api/?name=' . urlencode($author?->name ?? 'User') . '&background=0c1b33&color=fff';

                                                $authorUsername = $profile?->username;
                                                $authorUrl = $authorUsername
                                                    ? route('community.profile', $authorUsername)
                                                    : route('community.profile', $author?->id);

                                                $isOwnPost = auth()->check() && auth()->id() === $post->user_id;
                                                $mediaItems = $post->media ?? collect();

                                                 $titleLength = mb_strlen($post->title ?? '');
                                                 $rawContent = $post->content ?? $post->body ?? '';
                                                 $contentLength = mb_strlen(strip_tags($rawContent));
                                                 $contentLineCount = substr_count($rawContent, "\n") + 1;
                                                 $hasContentOverflow = ($contentLength > 160 || $contentLineCount > 4);

                                                $comments = $post->comments ?? collect();

                                                $commentPayload = $comments
                                                    ->whereNull('parent_id')
                                                    ->take(4)
                                                    ->map(function ($comment) {
                                                        return [
                                                            'id' => $comment->id,
                                                            'content' => $comment->content,
                                                            'parent_id' => $comment->parent_id,
                                                            'created_at_human' => $comment->created_at->diffForHumans(),
                                                            'showReplies' => true,
                                                            'user' => [
                                                                'id' => $comment->user?->id,
                                                                'name' => $comment->user?->name ?? 'User',
                                                                'avatar' => $comment->user?->profile?->avatar
                                                                    ? asset('storage/' . $comment->user->profile->avatar)
                                                                    : 'https://ui-avatars.com/api/?name=' . urlencode($comment->user?->name ?? 'User') . '&background=0c1b33&color=fff',
                                                            ],
                                                            'replies' => $comment->replies->map(function ($reply) {
                                                                return [
                                                                    'id' => $reply->id,
                                                                    'content' => $reply->content,
                                                                    'parent_id' => $reply->parent_id,
                                                                    'created_at_human' => $reply->created_at->diffForHumans(),
                                                                    'user' => [
                                                                        'id' => $reply->user?->id,
                                                                        'name' => $reply->user?->name ?? 'User',
                                                                        'avatar' => $reply->user?->profile?->avatar
                                                                            ? asset('storage/' . $reply->user->profile->avatar)
                                                                            : 'https://ui-avatars.com/api/?name=' . urlencode($reply->user?->name ?? 'User') . '&background=0c1b33&color=fff',
                                                                    ],
                                                                ];
                                                            })->values(),
                                                        ];
                                                    })->values();
                            @endphp
                                        <div
                                            class="community-post-card bg-white p-5 lg:p-6 rounded-2xl shadow-sm border border-slate-200/70 space-y-4 min-w-0"
                                            x-data="{
                                                currentUserId: {{ auth()->check() ? auth()->id() : 'null' }},
                                                postOwnerId: {{ (int) $post->user_id }},

                                                postMenuOpen: false,
                                                postEditOpen: false,
                                                postDeleteConfirm: false,
                                                postActionLoading: false,

                                                postTitle: @js($post->title),
                                                postContent: @js($post->content ?? $post->body ?? ''),
                                                postCategoryId: @js((string) $post->category_id),

                                                selectedTags: @js($post->tags->pluck('id')->map(fn($id) => (int) $id)->values()),
                                                availableTags: @js($availableTags->map(fn($tag) => ['id' => (int) $tag->id, 'name' => $tag->name])->values()),

                                                likesCount: {{ $post->likes_count ?? 0 }},
                                                liked: {{ auth()->check() && $post->likes()->where('user_id', auth()->id())->exists() ? 'true' : 'false' }},
                                                saved: {{ auth()->check() && $post->savedBy()->where('user_id', auth()->id())->exists() ? 'true' : 'false' }},
                                                copied: false,

                                                 expandedTitle: false,
                                                 expandedContent: false,
                                                 canExpandContent: {{ $hasContentOverflow ? 'true' : 'false' }},
                                                 expandedTags: false,

                                                 init() {
                                                     this.$nextTick(() => {
                                                         if (this.$refs.contentRef) {
                                                             if (this.$refs.contentRef.scrollHeight > this.$refs.contentRef.clientHeight + 4) {
                                                                 this.canExpandContent = true;
                                                             }
                                                         }
                                                     });
                                                 },

                                                mediaIndex: 0,
                                                newMediaFiles: [],
                                                newMediaPreviews: [],
                                                newMediaIndex: 0,

                                                commentsCount: {{ $post->comments_count ?? $commentPayload->count() }},
                                                comments: {{ Js::from($commentPayload) }},
                                                hasMoreComments: {{ $post->comments()->whereNull('parent_id')->count() > 4 ? 'true' : 'false' }},
                                                loadingMore: false,
                                                newCommentText: '',

                                                replyingTo: null,
                                                replyText: '',

                                                editingCommentId: null,
                                                editingCommentText: '',
                                                openCommentMenuId: null,

                                                deleteConfirmComment: null,
                                                deleteConfirmIsReply: false,
                                                deleteConfirmParentComment: null,

                                                commentActionLoading: false,
                                                toast: '',
                                                toastType: 'success',
                                                toastTimer: null,

                                                isOwner() {
                                                    return this.currentUserId !== null &&
                                                        Number(this.currentUserId) === Number(this.postOwnerId);
                                                },

                                                toggleTag(id) {
                                                    id = Number(id);

                                                    if (this.selectedTags.includes(id)) {
                                                        this.selectedTags = this.selectedTags.filter(value => Number(value) !== id);
                                                        return;
                                                    }

                                                    if (this.selectedTags.length < 5) {
                                                        this.selectedTags.push(id);
                                                    }
                                                },

                                                openEditPost() {
                                                    if (!this.isOwner()) return;

                                                    this.postMenuOpen = false;
                                                    this.postEditOpen = true;
                                                    this.postTitle = @js($post->title);
                                                    this.postContent = @js($post->content ?? $post->body ?? '');
                                                    this.postCategoryId = @js((string) $post->category_id);
                                                    this.selectedTags = @js($post->tags->pluck('id')->map(fn($id) => (int) $id)->values());
                                                    this.newMediaFiles = [];
                                                    this.newMediaPreviews = [];
                                                    this.newMediaIndex = 0;

                                                    this.$nextTick(() => {
                                                        if (this.$refs.editMediaInput) {
                                                            this.$refs.editMediaInput.value = '';
                                                        }
                                                    });
                                                },

                                                closeEditPost() {
                                                    this.postEditOpen = false;
                                                    this.postMenuOpen = false;
                                                    this.newMediaFiles = [];
                                                    this.newMediaPreviews = [];
                                                    this.newMediaIndex = 0;

                                                    this.$nextTick(() => {
                                                        if (this.$refs.editMediaInput) {
                                                            this.$refs.editMediaInput.value = '';
                                                        }
                                                    });
                                                },

                                                handleEditFiles(event) {
                                                    const incoming = Array.from(event.target.files || []);

                                                    if (!incoming.length) return;

                                                    const remaining = Math.max(0, 10 - this.newMediaFiles.length);
                                                    const files = incoming.slice(0, remaining);

                                                    this.newMediaFiles = this.newMediaFiles.concat(files);
                                                    this.newMediaPreviews.forEach(preview => {
                                                        if (preview.url?.startsWith('blob:')) URL.revokeObjectURL(preview.url);
                                                    });

                                                    this.newMediaPreviews = this.newMediaFiles.map(file => ({
                                                        url: URL.createObjectURL(file),
                                                        type: (file.type && file.type.startsWith('video/')) || /\.(mp4|mov|avi|webm|mkv|m4v)$/i.test(file.name) ? 'video' : 'image',
                                                        name: file.name
                                                    }));

                                                    this.newMediaIndex = Math.max(0, this.newMediaPreviews.length - 1);
                                                    this.syncMediaInput();
                                                },

                                                syncMediaInput() {
                                                    const input = this.$refs.editMediaInput;

                                                    if (!input || typeof DataTransfer === 'undefined') return;

                                                    const transfer = new DataTransfer();

                                                    this.newMediaFiles.forEach(file => transfer.items.add(file));
                                                    input.files = transfer.files;
                                                },

                                                removeNewMedia(index) {
                                                    const preview = this.newMediaPreviews[index];

                                                    if (preview?.url?.startsWith('blob:')) {
                                                        URL.revokeObjectURL(preview.url);
                                                    }

                                                    this.newMediaFiles.splice(index, 1);

                                                    this.newMediaPreviews = this.newMediaFiles.map(file => ({
                                                        url: URL.createObjectURL(file),
                                                        type: file.type.startsWith('video/') ? 'video' : 'image',
                                                        name: file.name
                                                    }));

                                                    this.newMediaIndex = Math.min(
                                                        this.newMediaIndex,
                                                        Math.max(0, this.newMediaPreviews.length - 1)
                                                    );

                                                    this.syncMediaInput();
                                                },

                                                previousMedia() {
                                                    const total = {{ $mediaItems->count() }};
                                                    if (!total) return;
                                                    this.mediaIndex = (this.mediaIndex - 1 + total) % total;
                                                },

                                                nextMedia() {
                                                    const total = {{ $mediaItems->count() }};
                                                    if (!total) return;
                                                    this.mediaIndex = (this.mediaIndex + 1) % total;
                                                },

                                                previousNewMedia() {
                                                    const total = this.newMediaPreviews.length;
                                                    if (!total) return;
                                                    this.newMediaIndex = (this.newMediaIndex - 1 + total) % total;
                                                },

                                                nextNewMedia() {
                                                    const total = this.newMediaPreviews.length;
                                                    if (!total) return;
                                                    this.newMediaIndex = (this.newMediaIndex + 1) % total;
                                                },

                                                toggleLike() {
                                                    @guest
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    @endguest

                                                    fetch('{{ route('community.posts.like', $post) }}', {
                                                        method: 'POST',
                                                        headers: {
                                                            'Content-Type': 'application/json',
                                                            'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                                                            'Accept': 'application/json',
                                                            'X-Requested-With': 'XMLHttpRequest'
                                                        }
                                                    })
                                                    .then(async response => {
                                                        if (response.status === 401) {
                                                            window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                            return null;
                                                        }

                                                        if (!response.ok) throw new Error('Like request failed.');
                                                        return response.json();
                                                    })
                                                    .then(data => {
                                                        if (data?.success) {
                                                            this.liked = Boolean(data.liked);
                                                            this.likesCount = Number(data.likes_count);
                                                        }
                                                    })
                                                    .catch(error => console.error(error));
                                                },

                                                toggleSave() {
                                                    @guest
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    @endguest

                                                    fetch('{{ route('community.posts.save', $post) }}', {
                                                        method: 'POST',
                                                        headers: {
                                                            'Content-Type': 'application/json',
                                                            'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                                                            'Accept': 'application/json',
                                                            'X-Requested-With': 'XMLHttpRequest'
                                                        }
                                                    })
                                                    .then(async response => {
                                                        if (response.status === 401) {
                                                            window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                            return null;
                                                        }

                                                        if (!response.ok) throw new Error('Save request failed.');
                                                        return response.json();
                                                    })
                                                    .then(data => {
                                                        if (data?.success) this.saved = Boolean(data.saved);
                                                    })
                                                    .catch(error => console.error(error));
                                                },

                                                sharePost() {
                                                    window.dispatchEvent(new CustomEvent('open-share-modal', {
                                                        detail: {
                                                            id: {{ (int) $post->id }},
                                                            title: @js($post->title),
                                                            url: @js(route('community.posts.show', $post)),
                                                            text: @js(\Illuminate\Support\Str::limit(strip_tags($post->content ?? $post->body ?? ''), 200)),
                                                            image: @js($post->media?->first() ? asset('storage/' . $post->media->first()->file_path) : null),
                                                            authorName: @js($post->user?->name ?? $user?->name ?? 'User'),
                                                            authorUsername: @js($post->user?->profile?->username ? '@' . $post->user->profile->username : ($user?->profile?->username ? '@' . $user->profile->username : '')),
                                                            authorAvatar: @js($post->user?->profile?->avatar ? asset('storage/' . $post->user->profile->avatar) : ($user?->profile?->avatar ? asset('storage/' . $user->profile->avatar) : 'https://ui-avatars.com/api/?name=' . urlencode($user?->name ?? 'User') . '&background=0c1b33&color=fff')),
                                                            category: @js($post->category?->name ?? ''),
                                                            shareEndpoint: @js(route('community.posts.share', $post))
                                                        }
                                                    }));
                                                },

                                                showToast(message, type = 'success') {
                                                    this.toast = message;
                                                    this.toastType = type;

                                                    clearTimeout(this.toastTimer);
                                                    this.toastTimer = setTimeout(() => {
                                                        this.toast = '';
                                                    }, 2500);
                                                },

                                                async submitComment() {
                                                    @guest
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    @endguest

                                                    const content = this.newCommentText.trim();
                                                    if (!content) return;

                                                    this.commentActionLoading = true;

                                                    try {
                                                        const response = await fetch('{{ route('community.posts.comment.store', $post) }}', {
                                                            method: 'POST',
                                                            headers: {
                                                                'Content-Type': 'application/json',
                                                                'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                                                                'Accept': 'application/json',
                                                                'X-Requested-With': 'XMLHttpRequest'
                                                            },
                                                            body: JSON.stringify({ content })
                                                        });

                                                        if (response.status === 401) {
                                                            window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                            return;
                                                        }

                                                        const data = await response.json();

                                                        if (!response.ok || !data.success) {
                                                            throw new Error(data.message || 'Unable to add comment.');
                                                        }

                                                        const comment = data.comment;
                                                        comment.user = comment.user || {};
                                                        comment.user.id = comment.user.id ?? this.currentUserId;
                                                        comment.user.name = comment.user.name ?? 'You';
                                                        comment.user.avatar = comment.user.avatar ||
                                                            'https://ui-avatars.com/api/?name=' + encodeURIComponent(comment.user.name) + '&background=0c1b33&color=fff';
                                                        comment.replies = comment.replies || [];
                                                        comment.created_at_human = comment.created_at_human || 'Just now';

                                                        this.comments.unshift(comment);
                                                        this.commentsCount = Number(this.commentsCount) + 1;
                                                        this.newCommentText = '';

                                                        this.showToast('Comment added successfully.');
                                                    } catch (error) {
                                                        console.error(error);
                                                        this.showToast(error.message || 'Unable to add comment.', 'error');
                                                    } finally {
                                                        this.commentActionLoading = false;
                                                    }
                                                },

                                                startReply(comment) {
                                                    @guest
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    @endguest

                                                    this.replyingTo = {
                                                        id: Number(comment.id),
                                                        userName: comment.user?.name || 'User'
                                                    };

                                                    this.replyText = '';

                                                    this.$nextTick(() => this.$refs.replyInput?.focus());
                                                },

                                                cancelReply() {
                                                    this.replyingTo = null;
                                                    this.replyText = '';
                                                },

                                                async submitReply() {
                                                    @guest
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    @endguest

                                                    if (!this.replyingTo || !this.replyText.trim()) return;

                                                    const parentId = this.replyingTo.id;
                                                    const content = this.replyText.trim();

                                                    this.commentActionLoading = true;

                                                    try {
                                                        const response = await fetch('{{ route('community.posts.comment.store', $post) }}', {
                                                            method: 'POST',
                                                            headers: {
                                                                'Content-Type': 'application/json',
                                                                'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                                                                'Accept': 'application/json',
                                                                'X-Requested-With': 'XMLHttpRequest'
                                                            },
                                                            body: JSON.stringify({
                                                                content,
                                                                parent_id: parentId
                                                            })
                                                        });

                                                        if (response.status === 401) {
                                                            window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                            return;
                                                        }

                                                        const data = await response.json();

                                                        if (!response.ok || !data.success) {
                                                            throw new Error(data.message || 'Unable to add reply.');
                                                        }

                                                        const parent = this.comments.find(
                                                            item => Number(item.id) === Number(parentId)
                                                        );

                                                        if (parent) {
                                                            parent.replies = parent.replies || [];
                                                            parent.replies.push(data.comment);
                                                            parent.showReplies = true;
                                                        }

                                                        this.commentsCount = Number(this.commentsCount) + 1;
                                                        this.cancelReply();

                                                        this.showToast('Reply added successfully.');
                                                    } catch (error) {
                                                        console.error(error);
                                                        this.showToast(error.message || 'Unable to add reply.', 'error');
                                                    } finally {
                                                        this.commentActionLoading = false;
                                                    }
                                                },

                                                isCommentOwner(comment) {
                                                    return this.currentUserId !== null &&
                                                        Number(comment?.user?.id) === Number(this.currentUserId);
                                                },

                                                startEditComment(comment) {
                                                    if (!this.isCommentOwner(comment)) return;

                                                    this.openCommentMenuId = null;
                                                    this.editingCommentId = Number(comment.id);
                                                    this.editingCommentText = comment.content || '';
                                                },

                                                cancelEditComment() {
                                                    this.editingCommentId = null;
                                                    this.editingCommentText = '';
                                                },

                                                async updateComment(comment) {
                                                    if (!this.isCommentOwner(comment) || !this.editingCommentText.trim()) return;

                                                    this.commentActionLoading = true;

                                                    try {
                                                        const response = await fetch(
                                                            '{{ route('community.comments.update', ['comment' => '__COMMENT_ID__']) }}'
                                                                .replace('__COMMENT_ID__', comment.id),
                                                            {
                                                                method: 'PUT',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                                                                    'Accept': 'application/json',
                                                                    'X-Requested-With': 'XMLHttpRequest'
                                                                },
                                                                body: JSON.stringify({
                                                                    content: this.editingCommentText.trim()
                                                                })
                                                            }
                                                        );

                                                        if (response.status === 401) {
                                                            window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                            return;
                                                        }

                                                        const data = await response.json();

                                                        if (!response.ok || !data.success) {
                                                            throw new Error(data.message || 'Unable to update comment.');
                                                        }

                                                        comment.content = data.comment?.content ?? this.editingCommentText.trim();

                                                        this.cancelEditComment();
                                                        this.showToast('Comment updated successfully.');
                                                    } catch (error) {
                                                        console.error(error);
                                                        this.showToast(error.message || 'Unable to update comment.', 'error');
                                                    } finally {
                                                        this.commentActionLoading = false;
                                                    }
                                                },

                                                requestDeleteComment(comment, isReply = false, parent = null) {
                                                    if (!this.isCommentOwner(comment) || this.commentActionLoading) return;

                                                    this.openCommentMenuId = null;
                                                    this.deleteConfirmComment = comment;
                                                    this.deleteConfirmIsReply = isReply;
                                                    this.deleteConfirmParentComment = parent;
                                                },

                                                cancelDeleteComment(force = false) {
                                                    if (this.commentActionLoading && !force) return;

                                                    this.deleteConfirmComment = null;
                                                    this.deleteConfirmIsReply = false;
                                                    this.deleteConfirmParentComment = null;
                                                },

                                                async confirmDeleteComment() {
                                                    const comment = this.deleteConfirmComment;

                                                    if (!comment || !this.isCommentOwner(comment)) {
                                                        this.cancelDeleteComment();
                                                        return;
                                                    }

                                                    this.commentActionLoading = true;

                                                    try {
                                                        const response = await fetch(
                                                            '{{ route('community.comments.destroy', ['comment' => '__COMMENT_ID__']) }}'
                                                                .replace('__COMMENT_ID__', comment.id),
                                                            {
                                                                method: 'DELETE',
                                                                headers: {
                                                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
                                                                    'Accept': 'application/json',
                                                                    'X-Requested-With': 'XMLHttpRequest'
                                                                }
                                                            }
                                                        );

                                                        if (response.status === 401) {
                                                            window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                            return;
                                                        }

                                                        const data = await response.json();

                                                        if (!response.ok || !data.success) {
                                                            throw new Error(data.message || 'Unable to delete comment.');
                                                        }

                                                        if (this.deleteConfirmIsReply && this.deleteConfirmParentComment) {
                                                            this.deleteConfirmParentComment.replies =
                                                                (this.deleteConfirmParentComment.replies || [])
                                                                    .filter(reply => Number(reply.id) !== Number(comment.id));
                                                        } else {
                                                            this.comments = this.comments.filter(
                                                                item => Number(item.id) !== Number(comment.id)
                                                            );
                                                        }

                                                        this.commentsCount = Math.max(0, Number(this.commentsCount) - 1);
                                                        this.cancelDeleteComment(true);

                                                        this.showToast(
                                                            this.deleteConfirmIsReply ? 'Reply deleted successfully.' : 'Comment deleted successfully.'
                                                        );
                                                    } catch (error) {
                                                        console.error(error);
                                                        this.showToast(error.message || 'Unable to delete comment.', 'error');
                                                    } finally {
                                                        this.commentActionLoading = false;
                                                    }
                                                },

                                                loadMoreComments() {
                                                    if (this.loadingMore || !this.hasMoreComments) return;

                                                    this.loadingMore = true;

                                                    fetch(`{{ route('community.posts.comments', $post) }}?skip=${this.comments.length}`, {
                                                        headers: {
                                                            'Accept': 'application/json',
                                                            'X-Requested-With': 'XMLHttpRequest'
                                                        }
                                                    })
                                                    .then(async response => {
                                                        if (!response.ok) throw new Error('Unable to load comments.');
                                                        return response.json();
                                                    })
                                                    .then(data => {
                                                        if (data.success && Array.isArray(data.comments)) {
                                                            const newComments = data.comments.map(c => ({
                                                                ...c,
                                                                showReplies: true
                                                            }));
                                                            this.comments = this.comments.concat(newComments);
                                                            this.hasMoreComments = Boolean(data.has_more);
                                                        } else {
                                                            this.hasMoreComments = false;
                                                        }
                                                    })
                                                    .catch(error => this.showToast(error.message, 'error'))
                                                    .finally(() => {
                                                        this.loadingMore = false;
                                                    });
                                                }
                                            }"
                                        >

                                            {{-- HEADER --}}
                                            <div class="flex items-start justify-between gap-3">
                                                <div class="flex items-start gap-3 min-w-0 flex-1">
                                                    <img src="{{ $authorAvatar }}"
                                                        alt="{{ $author?->name ?? 'User' }}"
                                                        class="w-10 h-10 rounded-full object-cover shrink-0">

                                                    <div class="min-w-0">
                                                        <div class="font-bold text-slate-900 text-sm truncate flex items-center gap-1.5">
                                                            <a href="{{ $authorUrl }}" class="hover:underline">
                                                                {{ $author?->name ?? 'User' }}
                                                            </a>
                                                            @if ($author?->profile?->country)
                                                                @php
                                                                    $postAuthorIso = strtolower(trim($author->profile->country->iso_code ?: ''));
                                                                    if (!$postAuthorIso && !empty($author->profile->country->code) && strlen(trim($author->profile->country->code)) === 2) {
                                                                        $postAuthorIso = strtolower(trim($author->profile->country->code));
                                                                    }
                                                                @endphp
                                                                @if ($postAuthorIso)
                                                                    <img
                                                                        src="https://flagcdn.com/20x15/{{ $postAuthorIso }}.png"
                                                                        srcset="https://flagcdn.com/40x30/{{ $postAuthorIso }}.png 2x"
                                                                        width="20"
                                                                        height="15"
                                                                        alt="{{ $author->profile->country->name }}"
                                                                        title="{{ $author->profile->country->name }}"
                                                                        class="w-4.5 h-3.5 object-cover rounded-xs shadow-2xs inline-block shrink-0 align-middle"
                                                                        loading="lazy"
                                                                        onerror="this.style.display='none'"
                                                                    >
                                                                @elseif (!empty($author->profile->country->flag) && (str_starts_with($author->profile->country->flag, 'http://') || str_starts_with($author->profile->country->flag, 'https://')))
                                                                    <img
                                                                        src="{{ $author->profile->country->flag }}"
                                                                        alt="{{ $author->profile->country->name }}"
                                                                        title="{{ $author->profile->country->name }}"
                                                                        class="w-4.5 h-3.5 object-cover rounded-xs shadow-2xs inline-block shrink-0 align-middle"
                                                                        loading="lazy"
                                                                        onerror="this.style.display='none'"
                                                                    >
                                                                @endif
                                                            @endif
                                                        </div>

                                                        <div class="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-400">
                                                            @if($authorUsername)
                                                                <span>{{ '@' . $authorUsername }}</span>
                                                                <span>•</span>
                                                            @endif
                                                            <span>{{ $post->created_at->diffForHumans() }}</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="flex items-center gap-2 shrink-0">
                                                    @if($post->category)
                                                        <span class="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2.5 py-1 rounded-md">
                                                            {{ strtoupper($post->category->name) }}
                                                        </span>
                                                    @endif

                                                    @if($post->is_solved)
                                                        <span class="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-1 rounded-md">
                                                            ✓ Solved
                                                        </span>
                                                    @endif

                                                    @auth
                                                        <div class="relative" @click.outside="postMenuOpen = false">
                                                            {{-- POST ACTIONS / 3-DOT MENU --}}
                                                            <button type="button"
                                                                aria-label="Post options"
                                                                title="Post options"
                                                                @click.stop="postMenuOpen = !postMenuOpen"
                                                                class="w-9 h-9 rounded-full flex items-center justify-center
                                                                       bg-white border border-slate-200 text-slate-500
                                                                       hover:bg-slate-100 hover:text-slate-900
                                                                       shadow-sm transition">
                                                                <span class="flex flex-col items-center justify-center gap-[3px]">
                                                                    <span class="block w-1 h-1 rounded-full bg-current"></span>
                                                                    <span class="block w-1 h-1 rounded-full bg-current"></span>
                                                                    <span class="block w-1 h-1 rounded-full bg-current"></span>
                                                                </span>
                                                            </button>

                                                            <div x-show="postMenuOpen" x-cloak x-transition
                                                                class="absolute right-0 top-11 z-[100] w-40 rounded-xl
                                                                       border border-slate-200 bg-white p-1.5 shadow-2xl">
                                                                @if($isOwnPost)
                                                                    <button type="button"
                                                                        @click="openEditPost()"
                                                                        class="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold
                                                                               text-slate-700 hover:bg-slate-50 flex items-center gap-2">
                                                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                                                                            viewBox="0 0 24 24">
                                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                                                        </svg>
                                                                        Edit post
                                                                    </button>

                                                                    <button type="button"
                                                                        @click="postMenuOpen = false; postDeleteConfirm = true"
                                                                        class="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold
                                                                               text-red-600 hover:bg-red-50 flex items-center gap-2">
                                                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                                                                            viewBox="0 0 24 24">
                                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                                d="M3 6h18M8 6V4h8v2m-9 0l1 14h8l1-14M10 11v5m4-5v5"/>
                                                                        </svg>
                                                                        Delete post
                                                                    </button>
                                                                @else
                                                                    <div class="px-3 py-2.5 text-[10px] text-slate-400">
                                                                        You can only edit your own post.
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    @endauth
                                                </div>
                                            </div>

                                            {{-- TITLE & CONTENT --}}
                                            <div class="space-y-1.5 text-left">
                                                <div class="community-post-title text-sm sm:text-base font-bold text-slate-900 leading-snug break-words">
                                                    <h3 :class="expandedTitle ? '' : 'line-clamp-2'" class="m-0 p-0 text-left break-words">
                                                        <a href="{{ route('community.posts.show', $post) }}" class="text-slate-900 hover:underline">
                                                            <span x-text="postTitle"></span>
                                                        </a>
                                                    </h3>

                                                    @if($titleLength > 140)
                                                        <button type="button"
                                                            @click="expandedTitle = !expandedTitle"
                                                            class="mt-1 text-[11px] font-bold text-amber-600 hover:underline text-left inline-block">
                                                            <span x-text="expandedTitle ? 'Show less' : 'Show more'"></span>
                                                        </button>
                                                    @endif
                                                </div>

                                                <div class="community-post-content text-xs sm:text-sm text-slate-600 leading-relaxed break-words text-left">
                                                    <p class="whitespace-pre-wrap break-words text-left"
                                                       :class="expandedContent ? '' : 'max-h-24 overflow-hidden'"
                                                       x-ref="contentRef"
                                                       x-html="formatPostContent(postContent)">{!! \App\Helpers\LinkHelper::makeClickableLinks($post->content ?? $post->body ?? '') !!}</p>

                                                    <div class="mt-1.5 flex justify-start text-left" x-show="canExpandContent">
                                                        <button type="button"
                                                            @click="expandedContent = !expandedContent"
                                                            class="inline-flex items-center gap-1 text-[11px] font-bold text-amber-600 hover:text-amber-700 hover:underline text-left">
                                                            <span x-text="expandedContent ? 'Show less' : 'Show more'"></span>
                                                            <svg class="w-3 h-3 transition-transform" :class="expandedContent ? 'rotate-180' : ''" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 9l6 6 6-6"/>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- MEDIA --}}
                                            @if($mediaItems->isNotEmpty())
                                                <div class="relative w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-200">
                                                    <div class="community-post-media w-full h-[280px] sm:h-[360px] lg:h-[420px] flex items-center justify-center overflow-hidden">
                                                        @foreach($mediaItems as $index => $mediaItem)
                                                            <div x-show="mediaIndex === {{ $index }}" x-cloak
                                                                class="w-full h-full flex items-center justify-center overflow-hidden">
                                                                @if(($mediaItem->type ?? '') === 'video' || str_starts_with($mediaItem->mime_type ?? '', 'video'))
                                                                    <video class="w-full h-full object-contain" controls preload="metadata" playsinline>
                                                                        <source src="{{ asset('storage/' . $mediaItem->file_path) }}" type="{{ $mediaItem->mime_type ?: 'video/mp4' }}">
                                                                        Your browser does not support the video tag.
                                                                    </video>
                                                                @else
                                                                    <img src="{{ asset('storage/' . $mediaItem->file_path) }}"
                                                                        alt="{{ $post->title }}"
                                                                        class="w-full h-full object-contain">
                                                                @endif
                                                            </div>
                                                        @endforeach
                                                    </div>

                                                    @if($mediaItems->count() > 1)
                                                        <button type="button" @click="previousMedia()"
                                                            class="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 shadow flex items-center justify-center text-xl">
                                                            ‹
                                                        </button>

                                                        <button type="button" @click="nextMedia()"
                                                            class="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 shadow flex items-center justify-center text-xl">
                                                            ›
                                                        </button>

                                                        <span class="absolute bottom-3 left-1/2 -translate-x-1/2 bg-black/60 text-white rounded-full px-3 py-1 text-[10px] font-bold"
                                                            x-text="(mediaIndex + 1) + ' / {{ $mediaItems->count() }}'"></span>
                                                    @endif
                                                </div>
                                            @endif

                                            {{-- TAGS --}}
                                            @if($post->tags->isNotEmpty())
                                                <div class="flex flex-wrap gap-1.5">
                                                    @foreach($post->tags as $index => $tag)
                                                        <a href="{{ route('community.index', ['tag' => $tag->slug]) }}"
                                                            x-show="expandedTags || {{ $index }} < 5"
                                                            class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium px-2.5 py-1 rounded-lg">
                                                            #{{ $tag->name }}
                                                        </a>
                                                    @endforeach

                                                    @if($post->tags->count() > 5)
                                                        <button type="button"
                                                            @click="expandedTags = !expandedTags"
                                                            class="text-[11px] font-bold text-amber-600 hover:underline">
                                                            <span x-text="expandedTags ? 'Show less' : '+{{ $post->tags->count() - 5 }} more'"></span>
                                                        </button>
                                                    @endif
                                                </div>
                                            @endif

                                            {{-- ACTION BAR --}}
                                            <div class="flex items-center justify-between pt-3 border-t border-slate-100 text-xs font-semibold text-slate-500">
                                                <div class="flex items-center gap-5">
                                                    <button type="button"
                                                        @click="toggleLike()"
                                                        :class="liked ? 'text-red-500' : 'hover:text-red-500'"
                                                        class="flex items-center gap-1.5">
                                                        ♥ <span x-text="likesCount"></span>
                                                    </button>

                                                    <button type="button"
                                                        @click="showAllComments = true"
                                                        class="flex items-center gap-1.5 hover:text-blue-500">
                                                        💬 <span x-text="commentsCount"></span>
                                                    </button>

                                                    <button type="button"
                                                         @click="sharePost()"
                                                         class="flex items-center gap-1.5 hover:text-emerald-500 transition text-slate-500 font-medium">
                                                         <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                             <path stroke-linecap="round" stroke-linejoin="round"
                                                                 d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z">
                                                             </path>
                                                         </svg>
                                                         <span>Share</span>
                                                     </button>
                                                </div>

                                                {{-- <button type="button"
                                                    @click="toggleSave()"
                                                    :class="saved ? 'text-amber-500' : 'hover:text-amber-500'"
                                                    class="flex items-center gap-1.5">
                                                    <span x-text="saved ? 'Saved' : 'Save'"></span>
                                                </button> --}}
                                            </div>

                                            {{-- COMMENTS --}}
                                            <div class="pt-4 border-t border-slate-100 space-y-4">
                                                <div class="flex items-center justify-between">
                                                    <div>
                                                        <h2 class="text-sm font-bold text-slate-900">Discussion</h2>
                                                        <p class="text-[10px] text-slate-400"
                                                            x-text="commentsCount + (commentsCount === 1 ? ' comment' : ' comments')"></p>
                                                    </div>
                                                </div>

                                                <div class="flex items-end gap-2">
                                                    <input type="text"
                                                        x-model="newCommentText"
                                                        @keydown.enter.prevent="submitComment()"
                                                        placeholder="Write a comment..."
                                                        maxlength="1000"
                                                        class="flex-1 h-10 bg-slate-50 border border-slate-200 rounded-xl px-3 text-xs focus:outline-none focus:ring-2 focus:ring-amber-200">

                                                    <button type="button"
                                                        @click="submitComment()"
                                                        :disabled="commentActionLoading || !newCommentText.trim()"
                                                        class="h-10 px-4 rounded-xl bg-[#0b1329] text-white text-xs font-bold disabled:opacity-40">
                                                        Post
                                                    </button>
                                                </div>

                                                <div x-show="toast" x-cloak
                                                    class="rounded-xl border px-3 py-2 text-[10px] font-semibold"
                                                    :class="toastType === 'error'
                                                        ? 'bg-red-50 border-red-100 text-red-600'
                                                        : 'bg-emerald-50 border-emerald-100 text-emerald-700'">
                                                    <span x-text="toast"></span>
                                                </div>

                                                <div class="space-y-3">
                                                    <template x-for="comment in comments" :key="comment.id">
                                                        <div>
                                                            <div class="flex items-start gap-2.5">
                                                                <img :src="comment.user.avatar"
                                                                    class="w-8 h-8 rounded-full object-cover shrink-0">

                                                                <div class="flex-1 min-w-0">
                                                                    <div class="relative rounded-2xl rounded-tl-md bg-slate-50 border border-slate-100 p-3">

                                                                        <div class="flex items-center gap-2 pr-7">
                                                                            <span class="text-[11px] font-bold text-slate-900"
                                                                                x-text="comment.user.name"></span>
                                                                            <span class="text-[9px] text-slate-400"
                                                                                x-text="comment.created_at_human"></span>
                                                                        </div>

                                                                        <template x-if="editingCommentId === Number(comment.id)">
                                                                            <div class="mt-2">
                                                                                <textarea x-model="editingCommentText"
                                                                                    rows="3"
                                                                                    maxlength="1000"
                                                                                    class="w-full bg-white border border-amber-200 rounded-xl p-2 text-xs resize-none focus:outline-none"></textarea>

                                                                                <div class="flex gap-2 mt-2">
                                                                                    <button type="button"
                                                                                        @click="updateComment(comment)"
                                                                                        class="px-3 py-1.5 rounded-lg bg-[#0b1329] text-white text-[9px] font-bold">
                                                                                        Save
                                                                                    </button>

                                                                                    <button type="button"
                                                                                        @click="cancelEditComment()"
                                                                                        class="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-[9px] font-bold">
                                                                                        Cancel
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </template>

                                                                        <template x-if="editingCommentId !== Number(comment.id)">
                                                                            <p class="mt-1 text-[11px] leading-relaxed text-slate-700 whitespace-pre-wrap break-words"
                                                                                x-html="formatPostContent(comment.content)"></p>
                                                                        </template>

                                                                        <template x-if="isCommentOwner(comment) && editingCommentId !== Number(comment.id)">
                                                                            <div class="absolute right-1 top-1">
                                                                                <button type="button"
                                                                                    @click.stop="openCommentMenuId = openCommentMenuId === Number(comment.id) ? null : Number(comment.id)"
                                                                                    class="w-7 h-7 rounded-full text-slate-400 hover:bg-white">
                                                                                    •••
                                                                                </button>

                                                                                <div x-show="openCommentMenuId === Number(comment.id)"
                                                                                    x-cloak
                                                                                    @click.outside="openCommentMenuId = null"
                                                                                    class="absolute right-0 top-8 z-50 w-28 rounded-xl border border-slate-200 bg-white p-1 shadow-xl">

                                                                                    <button type="button"
                                                                                        @click="startEditComment(comment)"
                                                                                        class="w-full text-left px-2.5 py-2 rounded-lg text-[10px] font-semibold hover:bg-slate-50">
                                                                                        Edit
                                                                                    </button>

                                                                                    <button type="button"
                                                                                        @click="requestDeleteComment(comment)"
                                                                                        class="w-full text-left px-2.5 py-2 rounded-lg text-[10px] font-semibold text-red-600 hover:bg-red-50">
                                                                                        Delete
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </template>
                                                                    </div>
                                                                    <div class="flex items-center gap-2.5 px-1 pt-1">
                                                                        <button type="button"
                                                                            @click="startReply(comment)"
                                                                            class="inline-flex items-center gap-1 text-[9px] font-bold text-slate-400 hover:text-amber-600 transition">
                                                                            <svg class="w-2.5 h-2.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 10h10a4 4 0 014 4v1m0 0l4-4m-4 4l-4-4" />
                                                                            </svg>
                                                                            <span>Reply</span>
                                                                        </button>

                                                                        <template x-if="comment.replies?.length">
                                                                            <button type="button"
                                                                                @click="comment.showReplies = !comment.showReplies"
                                                                                class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 hover:bg-amber-100/80 text-[8.5px] font-bold text-amber-700 transition">
                                                                                <svg class="w-2.5 h-2.5 transition-transform duration-200"
                                                                                    :class="comment.showReplies ? 'rotate-180' : ''"
                                                                                    fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                                                                </svg>
                                                                                <span x-text="comment.showReplies ? 'Hide replies' : (comment.replies.length + (comment.replies.length === 1 ? ' reply' : ' replies'))"></span>
                                                                            </button>
                                                                        </template>
                                                                    </div>

                                                                    <template x-if="comment.replies?.length">
                                                                        <div x-show="comment.showReplies !== false" x-transition
                                                                            class="ml-8 mt-2 pl-3 border-l-2 border-amber-200 space-y-2">

                                                                            <template x-for="reply in comment.replies" :key="reply.id">
                                                                                <div class="flex items-start gap-2">
                                                                                    <img :src="reply.user.avatar"
                                                                                        class="w-6 h-6 rounded-full object-cover shrink-0 ring-1 ring-slate-200">

                                                                                    <div class="flex-1 min-w-0">
                                                                                        <div class="relative rounded-2xl rounded-tl-md bg-slate-50 border border-slate-100 px-2.5 py-2">

                                                                                            <div class="flex items-center gap-2 pr-6">
                                                                                                <span class="text-[10px] font-bold text-slate-800"
                                                                                                    x-text="reply.user.name"></span>
                                                                                                <span
                                                                                                    x-show="Number(reply.user.id) === Number(currentUserId)"
                                                                                                    class="shrink-0 rounded-full bg-amber-100 px-1.5 py-0.5 text-[7px] font-bold text-amber-700">You</span>
                                                                                                <span class="text-[8px] text-slate-400"
                                                                                                    x-text="reply.created_at_human"></span>
                                                                                            </div>

                                                                                            <template x-if="editingCommentId === Number(reply.id)">
                                                                                                <div class="mt-1.5">
                                                                                                    <textarea x-model="editingCommentText"
                                                                                                        rows="2"
                                                                                                        maxlength="1000"
                                                                                                        class="w-full bg-white border border-amber-200 rounded-xl px-2.5 py-2 text-[10px] focus:outline-none focus:ring-2 focus:ring-amber-100 resize-none"></textarea>

                                                                                                    <div class="flex gap-2 mt-1.5">
                                                                                                        <button type="button"
                                                                                                            @click="updateComment(reply)"
                                                                                                            class="px-2.5 py-1.5 rounded-lg bg-[#0b1329] text-white text-[8px] font-bold">
                                                                                                            Save
                                                                                                        </button>

                                                                                                        <button type="button"
                                                                                                            @click="cancelEditComment()"
                                                                                                            class="px-2.5 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-[8px] font-bold">
                                                                                                            Cancel
                                                                                                        </button>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </template>

                                                                                            <template x-if="editingCommentId !== Number(reply.id)">
                                                                                                <p class="mt-0.5 text-[10px] leading-relaxed text-slate-600 whitespace-pre-wrap break-words"
                                                                                                    x-html="formatPostContent(reply.content)"></p>
                                                                                            </template>

                                                                                            <template x-if="isCommentOwner(reply) && editingCommentId !== Number(reply.id)">
                                                                                                <div class="absolute right-1 top-1">
                                                                                                    <button type="button"
                                                                                                        @click.stop="openCommentMenuId = openCommentMenuId === Number(reply.id) ? null : Number(reply.id)"
                                                                                                        class="w-5.5 h-5.5 rounded-full flex items-center justify-center text-slate-400 hover:bg-white hover:text-slate-700 transition">
                                                                                                        <svg class="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
                                                                                                            <circle cx="5" cy="12" r="1.6" />
                                                                                                            <circle cx="12" cy="12" r="1.6" />
                                                                                                            <circle cx="19" cy="12" r="1.6" />
                                                                                                        </svg>
                                                                                                    </button>

                                                                                                    <div x-show="openCommentMenuId === Number(reply.id)"
                                                                                                        x-cloak
                                                                                                        @click.outside="openCommentMenuId = null"
                                                                                                        class="absolute right-0 top-7 z-50 w-28 rounded-xl border border-slate-200 bg-white p-1 shadow-xl">

                                                                                                        <button type="button"
                                                                                                            @click="startEditComment(reply)"
                                                                                                            class="w-full text-left px-2.5 py-2 rounded-lg text-[10px] font-semibold text-slate-600 hover:bg-slate-50">
                                                                                                            Edit
                                                                                                        </button>

                                                                                                        <button type="button"
                                                                                                            @click="requestDeleteComment(reply, true, comment)"
                                                                                                            class="w-full text-left px-2.5 py-2 rounded-lg text-[10px] font-semibold text-red-600 hover:bg-red-50">
                                                                                                            Delete
                                                                                                        </button>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </template>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </template>
                                                                        </div>
                                                                    </template>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </template>

                                                    <div x-show="comments.length === 0"
                                                        class="py-5 text-center text-xs text-slate-400">
                                                        No comments yet. Be the first to reply!
                                                    </div>
                                                </div>

                                                <div x-show="replyingTo" x-cloak
                                                    class="ml-7 flex gap-2">
                                                    <input x-ref="replyInput"
                                                        x-model="replyText"
                                                        @keydown.enter.prevent="submitReply()"
                                                        maxlength="1000"
                                                        :placeholder="'Reply to ' + (replyingTo?.userName || 'User') + '...'"
                                                        class="flex-1 h-9 bg-slate-50 border border-slate-200 rounded-xl px-3 text-[10px] focus:outline-none">

                                                    <button type="button"
                                                        @click="submitReply()"
                                                        :disabled="commentActionLoading || !replyText.trim()"
                                                        class="h-9 px-3 rounded-xl bg-[#0b1329] text-white text-[10px] font-bold disabled:opacity-40">
                                                        Reply
                                                    </button>

                                                    <button type="button"
                                                        @click="cancelReply()"
                                                        class="h-9 px-2 text-[10px] font-bold text-slate-400">
                                                        Cancel
                                                    </button>
                                                </div>

                                                <div x-show="hasMoreComments" class="text-center pt-2">
                                                    <button type="button"
                                                        @click="loadMoreComments()"
                                                        :disabled="loadingMore"
                                                        class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-50 hover:bg-amber-50 border border-slate-200 hover:border-amber-200 text-[10px] font-bold text-slate-600 hover:text-amber-700 transition disabled:opacity-50 shadow-xs">
                                                        <svg x-show="!loadingMore" class="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" stroke-width="2.2"
                                                            viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                                        </svg>
                                                        <svg x-show="loadingMore" class="w-3 h-3 animate-spin text-amber-600" fill="none" viewBox="0 0 24 24">
                                                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                                        </svg>
                                                        <span x-text="loadingMore ? 'Loading comments...' : 'Read more'"></span>
                                                    </button>
                                                </div>
                                            </div>

                                            {{-- EDIT POST MODAL --}}
                                            <template x-teleport="body">
                                                <div x-show="postEditOpen" x-cloak x-transition.opacity
                                                    class="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6">

                                                    <div class="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
                                                        @click="closeEditPost()"></div>

                                                    <div class="relative w-full max-w-[700px] max-h-[calc(100vh-32px)] overflow-hidden rounded-2xl bg-white shadow-2xl"
                                                        @click.stop>

                                                        <form method="POST"
                                                            action="{{ route('community.posts.update', ['post' => $post]) }}"
                                                            enctype="multipart/form-data"
                                                            @submit="postActionLoading = true">

                                                            @csrf
                                                            @method('PUT')

                                                            <div class="h-16 px-5 sm:px-6 flex items-center justify-between border-b border-slate-200">
                                                                <h2 class="text-[17px] font-bold text-slate-900">
                                                                    Edit a discussion
                                                                </h2>

                                                                <button type="button"
                                                                    @click="closeEditPost()"
                                                                    class="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 hover:text-slate-700 text-xl">
                                                                    ×
                                                                </button>
                                                            </div>

                                                            <div class="overflow-y-auto max-h-[calc(100vh-150px)] px-5 sm:px-6 py-5">

                                                                <div class="flex items-center gap-3 mb-5">
                                                                    <img src="{{ $authorAvatar }}"
                                                                        class="w-11 h-11 rounded-full object-cover">

                                                                    <div>
                                                                        <div class="text-sm font-bold text-slate-900">
                                                                            {{ $author?->name ?? 'User' }}
                                                                        </div>

                                                                        <div class="mt-1 flex gap-2">
                                                                            <select name="category_id"
                                                                                x-model="postCategoryId"
                                                                                required
                                                                                class="h-8 rounded-full bg-slate-100 border-0 px-3 text-[11px] font-semibold text-slate-700 focus:outline-none">
                                                                                @foreach($availableCategories as $category)
                                                                                    <option value="{{ $category->id }}">
                                                                                        {{ $category->name }}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>

                                                                            <span class="h-8 px-3 rounded-full bg-slate-100 inline-flex items-center text-[11px] font-semibold text-slate-500">
                                                                                Public
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <input type="text"
                                                                    name="title"
                                                                    x-model="postTitle"
                                                                    maxlength="255"
                                                                    required
                                                                    class="w-full border-0 p-0 text-lg font-bold text-slate-900 focus:outline-none"
                                                                    placeholder="Give your discussion a clear title...">

                                                                <textarea name="content"
                                                                    x-model="postContent"
                                                                    maxlength="10000"
                                                                    required
                                                                    rows="7"
                                                                    class="mt-2 w-full border-0 p-0 text-sm leading-6 text-slate-700 resize-none focus:outline-none whitespace-pre-wrap"
                                                                    placeholder="What do you want to talk about?"></textarea>

                                                                {{-- ALL TAGS --}}
                                                                <div class="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
                                                                    <div class="flex items-center justify-between mb-3">
                                                                        <div>
                                                                            <div class="text-[11px] font-bold uppercase tracking-wide text-slate-500">
                                                                                Tags
                                                                            </div>
                                                                            <div class="text-[10px] text-slate-400 mt-1">
                                                                                Select or unselect tags · Maximum 5
                                                                            </div>
                                                                        </div>

                                                                        <span class="text-[10px] font-bold text-slate-400"
                                                                            x-text="selectedTags.length + '/5'"></span>
                                                                    </div>

                                                                    <div class="flex flex-wrap gap-2">
                                                                        <template x-for="tag in availableTags" :key="tag.id">
                                                                            <button type="button"
                                                                                @click="toggleTag(tag.id)"
                                                                                :class="selectedTags.includes(Number(tag.id))
                                                                                    ? 'bg-[#0b1329] text-white border-[#0b1329]'
                                                                                    : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'"
                                                                                class="h-8 px-3 rounded-full border text-[10px] font-semibold transition">
                                                                                <span x-text="selectedTags.includes(Number(tag.id)) ? '✓ ' : '+ '"></span>
                                                                                <span x-text="tag.name"></span>
                                                                            </button>
                                                                        </template>
                                                                    </div>

                                                                    <template x-for="tag in availableTags" :key="'tag-input-' + tag.id">
                                                                        <input type="checkbox"
                                                                            name="tags[]"
                                                                            :value="tag.id"
                                                                            :checked="selectedTags.includes(Number(tag.id))"
                                                                            class="hidden">
                                                                    </template>
                                                                </div>

                                                                {{-- EXISTING MEDIA --}}
                                                                @if($mediaItems->isNotEmpty())
                                                                    <div class="mt-5">
                                                                        <div class="text-[11px] font-bold uppercase tracking-wide text-slate-500 mb-2">
                                                                            Existing media
                                                                        </div>

                                                                        <div class="relative rounded-xl overflow-hidden bg-slate-950">
                                                                            @foreach($mediaItems as $index => $mediaItem)
                                                                                <div x-show="mediaIndex === {{ $index }}" x-cloak
                                                                                    class="h-[240px] flex items-center justify-center">
                                                                                    @if(($mediaItem->type ?? '') === 'video' || str_starts_with($mediaItem->mime_type ?? '', 'video'))
                                                                                        <video class="w-full h-full object-contain" controls preload="metadata" playsinline>
                                                                                            <source src="{{ asset('storage/' . $mediaItem->file_path) }}" type="{{ $mediaItem->mime_type ?: 'video/mp4' }}">
                                                                                            Your browser does not support the video tag.
                                                                                        </video>
                                                                                    @else
                                                                                        <img src="{{ asset('storage/' . $mediaItem->file_path) }}"
                                                                                            class="w-full h-full object-contain">
                                                                                    @endif
                                                                                </div>
                                                                            @endforeach

                                                                            @if($mediaItems->count() > 1)
                                                                                <button type="button"
                                                                                    @click="previousMedia()"
                                                                                    class="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 shadow text-lg">
                                                                                    ‹
                                                                                </button>

                                                                                <button type="button"
                                                                                    @click="nextMedia()"
                                                                                    class="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 shadow text-lg">
                                                                                    ›
                                                                                </button>

                                                                                <span class="absolute bottom-2 left-1/2 -translate-x-1/2 bg-black/60 text-white rounded-full px-2.5 py-1 text-[9px] font-bold"
                                                                                    x-text="(mediaIndex + 1) + ' / {{ $mediaItems->count() }}'"></span>
                                                                            @endif
                                                                        </div>
                                                                    </div>
                                                                @endif

                                                                {{-- ADD MEDIA --}}
                                                                <div class="mt-5 rounded-xl border border-dashed border-slate-300 p-4">
                                                                    <div class="flex items-center justify-between gap-3 mb-3">
                                                                        <div>
                                                                            <div class="text-[11px] font-bold text-slate-700">
                                                                                Add photos or videos
                                                                            </div>
                                                                            <div class="text-[10px] text-slate-400 mt-1">
                                                                                JPG, PNG, GIF, WEBP, MP4, MOV, AVI · Max 100MB
                                                                            </div>
                                                                        </div>

                                                                        <label class="shrink-0 cursor-pointer inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-[#0b1329] text-white text-[10px] font-bold hover:bg-slate-800">
                                                                            Add media
                                                                            <input type="file"
                                                                                x-ref="editMediaInput"
                                                                                name="media[]"
                                                                                multiple
                                                                                accept="image/*,video/*"
                                                                                @change="handleEditFiles($event)"
                                                                                class="hidden">
                                                                        </label>
                                                                    </div>

                                                                    <template x-if="newMediaPreviews.length">
                                                                        <div class="relative rounded-xl overflow-hidden bg-slate-950">
                                                                            <template x-for="(preview, index) in newMediaPreviews" :key="preview.name + '-' + index">
                                                                                <div x-show="newMediaIndex === index" x-cloak
                                                                                    class="relative h-[220px] flex items-center justify-center">

                                                                                    <template x-if="preview.type === 'video'">
                                                                                        <video :src="preview.url"
                                                                                            class="w-full h-full object-contain"
                                                                                            controls></video>
                                                                                    </template>

                                                                                    <template x-if="preview.type === 'image'">
                                                                                        <img :src="preview.url"
                                                                                            class="w-full h-full object-contain">
                                                                                    </template>

                                                                                    <button type="button"
                                                                                        @click="removeNewMedia(index)"
                                                                                        class="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/70 text-white">
                                                                                        ×
                                                                                    </button>
                                                                                </div>
                                                                            </template>

                                                                            <template x-if="newMediaPreviews.length > 1">
                                                                                <div>
                                                                                    <button type="button"
                                                                                        @click="previousNewMedia()"
                                                                                        class="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 shadow">
                                                                                        ‹
                                                                                    </button>

                                                                                    <button type="button"
                                                                                        @click="nextNewMedia()"
                                                                                        class="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 shadow">
                                                                                        ›
                                                                                    </button>

                                                                                    <span class="absolute bottom-2 left-1/2 -translate-x-1/2 bg-black/60 text-white rounded-full px-2.5 py-1 text-[9px] font-bold"
                                                                                        x-text="(newMediaIndex + 1) + ' / ' + newMediaPreviews.length"></span>
                                                                                </div>
                                                                            </template>
                                                                        </div>
                                                                    </template>

                                                                    <div x-show="newMediaPreviews.length === 0"
                                                                        class="py-5 text-center text-[10px] text-slate-400">
                                                                        No new media selected.
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="h-[70px] px-5 sm:px-6 border-t border-slate-200 flex items-center justify-end gap-2">
                                                                <button type="button"
                                                                    @click="closeEditPost()"
                                                                    class="h-10 px-5 rounded-full border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50">
                                                                    Cancel
                                                                </button>

                                                                <button type="submit"
                                                                    :disabled="postActionLoading"
                                                                    class="h-10 px-5 rounded-full bg-[#ffbd1b] text-slate-950 text-xs font-bold disabled:opacity-50">
                                                                    <span x-text="postActionLoading ? 'Saving...' : 'Save changes'"></span>
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </template>

                                            {{-- DELETE POST MODAL --}}
                                            <template x-teleport="body">
                                                <div x-show="postDeleteConfirm" x-cloak x-transition.opacity
                                                    class="fixed inset-0 z-[210] flex items-center justify-center p-4">

                                                    <div class="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
                                                        @click="postDeleteConfirm = false"></div>

                                                    <div class="relative w-full max-w-sm rounded-2xl bg-white shadow-2xl p-6"
                                                        @click.stop>

                                                        <h3 class="text-sm font-bold text-slate-900">
                                                            Delete this discussion?
                                                        </h3>

                                                        <p class="mt-1 text-xs text-slate-500">
                                                            This post and its discussion will be permanently removed.
                                                        </p>

                                                        <form method="POST"
                                                            action="{{ route('community.posts.destroy', ['post' => $post]) }}"
                                                            @submit="postActionLoading = true"
                                                            class="mt-6 flex justify-end gap-2">
                                                            @csrf
                                                            @method('DELETE')

                                                            <button type="button"
                                                                @click="postDeleteConfirm = false"
                                                                class="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold">
                                                                Cancel
                                                            </button>

                                                            <button type="submit"
                                                                :disabled="postActionLoading"
                                                                class="px-4 py-2.5 rounded-xl bg-red-600 text-white text-xs font-bold disabled:opacity-50">
                                                                <span x-text="postActionLoading ? 'Deleting...' : 'Delete'"></span>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </template>

                                            {{-- DELETE COMMENT / REPLY MODAL --}}
                                            <template x-teleport="body">
                                                <div x-show="deleteConfirmComment" x-cloak x-transition.opacity
                                                    class="fixed inset-0 z-[220] flex items-center justify-center p-4">

                                                    <div class="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
                                                        @click="cancelDeleteComment()"></div>

                                                    <div class="relative w-full max-w-sm rounded-2xl bg-white shadow-2xl p-6"
                                                        @click.stop>

                                                        <h3 class="text-sm font-bold text-slate-900">
                                                            Delete this <span x-text="deleteConfirmIsReply ? 'reply' : 'comment'"></span>?
                                                        </h3>

                                                        <p class="mt-1 text-xs text-slate-500">
                                                            This action cannot be undone.
                                                        </p>

                                                        <div class="mt-6 flex justify-end gap-2">
                                                            <button type="button"
                                                                @click="cancelDeleteComment()"
                                                                :disabled="commentActionLoading"
                                                                class="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold">
                                                                Cancel
                                                            </button>

                                                            <button type="button"
                                                                @click="confirmDeleteComment()"
                                                                :disabled="commentActionLoading"
                                                                class="px-4 py-2.5 rounded-xl bg-red-600 text-white text-xs font-bold disabled:opacity-50">
                                                                <span x-text="commentActionLoading ? 'Deleting...' : 'Delete'"></span>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </template>

                                        </div>
                            @empty
                                <div class="py-16 text-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                                    <div class="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                        <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h6l2 2h6a2 2 0 012 2v10a2 2 0 01-2 2z" />
                                        </svg>
                                    </div>
                                    <p class="text-sm font-semibold text-slate-700">No posts yet</p>
                                    <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                                        When this user creates their first post, it will appear here.
                                    </p>
                                </div>
                            @endforelse

                            @if(method_exists($posts, 'hasPages') && $posts->hasPages())
                                <div class="mt-6">
                                    {{ $posts->appends(['tab' => 'posts'])->links() }}
                                </div>
                            @endif

                            @elseif($activeTab === 'comments')
                                <div class="space-y-4">
                                    @forelse($comments ?? [] as $comment)
                                        @php
                                            $targetPost = $comment->post;
                                            $isPostDeleted = $targetPost && method_exists($targetPost, 'trashed') && $targetPost->trashed();
                                            $targetPostAuthor = $targetPost?->user;
                                            $targetAuthorProfile = $targetPostAuthor?->profile;
                                            $targetAuthorName = $targetPostAuthor?->name ?? 'User';
                                            $isReply = $comment->parent_id && $comment->parent;
                                            $parentUser = $comment->parent?->user;
                                            $parentUserName = $parentUser?->name ?? 'User';
                                        @endphp

                                        <div class="bg-white rounded-2xl p-5 border border-slate-200/70 shadow-xs hover:border-slate-300 transition space-y-3">
                                            {{-- Context Header (Reply / Comment target) --}}
                                            <div class="flex items-start justify-between gap-3 text-xs">
                                                <div class="flex items-center gap-2 flex-wrap min-w-0">
                                                    <span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-50 text-amber-600 shrink-0">
                                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                                        </svg>
                                                    </span>

                                                    <span class="text-slate-500">
                                                        @if($isReply)
                                                            Replied to
                                                            <a href="{{ $parentUser ? ($parentUser->profile?->username ? route('community.profile', $parentUser->profile->username) : route('community.profile', $parentUser->id)) : '#' }}" class="font-bold text-slate-800 hover:text-amber-600 transition">
                                                                {{ $parentUserName }}
                                                            </a>
                                                            on
                                                        @else
                                                            Commented on
                                                            <a href="{{ $targetPostAuthor ? ($targetAuthorProfile?->username ? route('community.profile', $targetAuthorProfile->username) : route('community.profile', $targetPostAuthor->id)) : '#' }}" class="font-bold text-slate-800 hover:text-amber-600 transition">
                                                                {{ $targetAuthorName }}'s
                                                            </a>
                                                        @endif
                                                        post
                                                    </span>

                                                    @if($targetPost)
                                                        <a
                                                            href="{{ route('community.posts.show', $targetPost->id) }}"
                                                            class="font-bold text-[#0b1329] hover:text-amber-600 truncate max-w-xs sm:max-w-md inline-block align-middle transition"
                                                        >
                                                            "{{ Str::limit($targetPost->title, 50) }}"
                                                        </a>
                                                    @endif
                                                </div>

                                                <span class="text-[11px] text-slate-400 whitespace-nowrap shrink-0">
                                                    {{ $comment->created_at?->diffForHumans() }}
                                                </span>
                                            </div>

                                            {{-- Comment Content --}}
                                            <div class="bg-slate-50/80 rounded-xl p-3.5 border border-slate-100 text-xs sm:text-sm text-slate-800 leading-relaxed break-words font-medium">
                                                {{ $comment->content }}
                                            </div>

                                            {{-- Post Preview & Action Link --}}
                                            @if($targetPost)
                                                <div class="flex items-center justify-between pt-1 text-xs">
                                                    <div class="flex items-center gap-2 text-slate-400 truncate min-w-0">
                                                        @if($targetPost->category)
                                                            <span class="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-semibold">
                                                                {{ $targetPost->category->name }}
                                                            </span>
                                                        @endif
                                                        <span class="truncate text-[11px]">
                                                            {{ Str::limit(strip_tags($targetPost->content ?? $targetPost->body ?? ''), 80) }}
                                                        </span>
                                                    </div>

                                                    <a
                                                        href="{{ route('community.posts.show', $targetPost->id) }}"
                                                        class="inline-flex items-center gap-1 font-bold text-amber-600 hover:text-amber-700 transition shrink-0 ml-3"
                                                    >
                                                        <span>View Discussion</span>
                                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                                                        </svg>
                                                    </a>
                                                </div>
                                            @endif
                                        </div>
                                    @empty
                                        <div class="py-16 text-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                                            <div class="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                                <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                                </svg>
                                            </div>
                                            <p class="text-sm font-semibold text-slate-700">No comments yet</p>
                                            <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                                                When this user comments on posts or replies to discussions, they will appear here.
                                            </p>
                                        </div>
                                    @endforelse

                                    @if(isset($comments) && method_exists($comments, 'hasPages') && $comments->hasPages())
                                        <div class="mt-6">
                                            {{ $comments->appends(['tab' => 'comments'])->links() }}
                                        </div>
                                    @endif
                                </div>

                            @elseif($activeTab === 'followers')
                                <div class="bg-slate-50/60 rounded-2xl border border-slate-200/70 p-4 sm:p-5">
                                    <div class="flex items-center justify-between gap-3 mb-4">
                                        <div>
                                            <h2 class="text-sm font-extrabold text-slate-900">Followers</h2>
                                            <p class="text-xs text-slate-400 mt-0.5">People who follow {{ $user->name }}.</p>
                                        </div>
                                        <span class="text-xs font-bold text-amber-600 bg-amber-50 border border-amber-100 px-2.5 py-1 rounded-lg">
                                            {{ number_format($followersCount) }} total
                                        </span>
                                    </div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        @forelse($followers as $follow)
                                            @php
                                                $person = $follow->follower;
                                                $personProfile = $person?->profile;
                                                $personAvatar = $personProfile?->avatar
                                                    ? asset('storage/' . $personProfile->avatar)
                                                    : 'https://ui-avatars.com/api/?name=' . urlencode($person?->name ?? 'User') . '&background=0c1b33&color=fff&size=100';
                                                $personUsername = $personProfile?->username ?? 
                                                    (isset($person->username) ? $person->username : null);
                                            @endphp

                                            @if($person)
                                                <div
                                                    x-data="{ removing: false, removed: false }"
                                                    x-show="!removed"
                                                    x-transition
                                                    class="flex items-center gap-3 p-3 rounded-xl bg-white border border-slate-200/70 hover:border-amber-200 hover:shadow-sm transition min-w-0"
                                                >
                                                    <a
                                                        href="{{ route('community.profile', $personUsername ?: $person->id) }}"
                                                        class="flex items-center gap-3 min-w-0 flex-1"
                                                    >
                                                        <img
                                                            src="{{ $personAvatar }}"
                                                            alt="{{ $person->name }}"
                                                            class="w-11 h-11 rounded-full object-cover border border-slate-100 shrink-0"
                                                        >

                                                        <div class="min-w-0 flex-1">
                                                            <span class="text-sm font-bold text-slate-900 truncate block">
                                                                {{ $person->name }}
                                                            </span>

                                                            @if($personUsername)
                                                                <span class="text-[11px] text-slate-400 truncate block">
                                                                    {{ '@' . $personUsername }}
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </a>

                                                    @if($isOwnProfile)
                                                    <button
                                                        type="button"
                                                        @click.stop="
                                                            if (removing) return;
                                                            removing = true;

                                                            fetch('{{ route('users.followers.remove', $person->id) }}', {
                                                                method: 'POST',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                                    'Accept': 'application/json'
                                                                }
                                                            })
                                                            .then(async response => {
                                                                const data = await response.json();

                                                                if (!response.ok) {
                                                                    throw new Error(data.message || 'Unable to remove follower.');
                                                                }

                                                                return data;
                                                            })
                                                            .then(data => {
                                                                if (data.success) {
                                                                    removed = true;
                                                                }
                                                            })
                                                            .catch(error => {
                                                                console.error(error);
                                                            })
                                                            .finally(() => {
                                                                removing = false;
                                                            });
                                                        "
                                                        :disabled="removing"
                                                        class="shrink-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 bg-red-50 text-red-600 text-[10px] font-bold hover:bg-red-100 hover:border-red-300 transition disabled:opacity-50 disabled:cursor-not-allowed"
                                                    >
                                                        <svg
                                                            x-show="!removing"
                                                            class="w-3 h-3"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2.2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <path
                                                                stroke-linecap="round"
                                                                stroke-linejoin="round"
                                                                d="M6 12h12"
                                                            />
                                                        </svg>

                                                        <svg
                                                            x-show="removing"
                                                            x-cloak
                                                            class="w-3 h-3 animate-spin"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <circle cx="12" cy="12" r="9" class="opacity-25"></circle>
                                                            <path d="M21 12a9 9 0 01-9 9"></path>
                                                        </svg>

                                                        <span x-text="removing ? 'Removing...' : 'Remove'"></span>
                                                    </button>
                                                    @endif
                                                </div>
                                            @endif
                                        @empty
                                            <div class="sm:col-span-2 py-14 text-center bg-white rounded-xl border border-dashed border-slate-200">
                                                <div class="w-11 h-11 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                                    <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5V18a4 4 0 00-4-4h-1m-4 6H3v-2a4 4 0 014-4h3m3-8a4 4 0 11-8 0 4 4 0 018 0zm6 3a3 3 0 11-6 0" />
                                                    </svg>
                                                </div>
                                                <p class="text-sm font-semibold text-slate-700">No followers yet</p>
                                                <p class="text-xs text-slate-400 mt-1">People who follow this profile will appear here.</p>
                                            </div>
                                        @endforelse
                                    </div>

                                    @if(method_exists($followers, 'hasPages') && $followers->hasPages())
                                        <div class="mt-5">
                                            {{ $followers->appends(['tab' => 'followers'])->links() }}
                                        </div>
                                    @endif
                                </div>

                            @elseif($activeTab === 'following')
                                <div class="bg-slate-50/60 rounded-2xl border border-slate-200/70 p-4 sm:p-5">
                                    <div class="flex items-center justify-between gap-3 mb-4">
                                        <div>
                                            <h2 class="text-sm font-extrabold text-slate-900">Following</h2>
                                            <p class="text-xs text-slate-400 mt-0.5">People {{ $user->name }} follows.</p>
                                        </div>
                                        <span class="text-xs font-bold text-amber-600 bg-amber-50 border border-amber-100 px-2.5 py-1 rounded-lg">
                                            {{ number_format($followingCount) }} total
                                        </span>
                                    </div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        @forelse($following as $follow)
                                            @php
                                                $person = $follow->following;
                                                $personProfile = $person?->profile;
                                                $personAvatar = $personProfile?->avatar
                                                    ? asset('storage/' . $personProfile->avatar)
                                                    : 'https://ui-avatars.com/api/?name=' . urlencode($person?->name ?? 'User') . '&background=0c1b33&color=fff&size=100';
                                                $personUsername = $personProfile?->username ?? 
                                                    (isset($person->username) ? $person->username : null);
                                            @endphp

                                            @if($person)
                                                <div
                                                    x-data="{ unfollowing: false, removed: false }"
                                                    x-show="!removed"
                                                    x-transition
                                                    class="flex items-center gap-3 p-3 rounded-xl bg-white border border-slate-200/70 hover:border-amber-200 hover:shadow-sm transition min-w-0"
                                                >
                                                    <a
                                                        href="{{ route('community.profile', $personUsername ?: $person->id) }}"
                                                        class="flex items-center gap-3 min-w-0 flex-1"
                                                    >
                                                        <img
                                                            src="{{ $personAvatar }}"
                                                            alt="{{ $person->name }}"
                                                            class="w-11 h-11 rounded-full object-cover border border-slate-100 shrink-0"
                                                        >

                                                        <div class="min-w-0 flex-1">
                                                            <span class="text-sm font-bold text-slate-900 truncate block">
                                                                {{ $person->name }}
                                                            </span>

                                                            @if($personUsername)
                                                                <span class="text-[11px] text-slate-400 truncate block">
                                                                    {{ '@' . $personUsername }}
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </a>

                                                    @if($isOwnProfile)
                                                    <button
                                                        type="button"
                                                        @click.stop="
                                                            if (unfollowing) return;
                                                            unfollowing = true;

                                                            fetch('{{ route('users.follow.toggle', $person) }}', {
                                                                method: 'POST',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                                    'Accept': 'application/json'
                                                                }
                                                            })
                                                            .then(async response => {
                                                                const data = await response.json();

                                                                if (!response.ok) {
                                                                    throw new Error(data.message || 'Unable to unfollow user.');
                                                                }

                                                                return data;
                                                            })
                                                            .then(data => {
                                                                if (data.success && data.data && data.data.following === false) {
                                                                    removed = true;

                                                                    window.dispatchEvent(
                                                                        new CustomEvent('following-updated', {
                                                                            detail: {
                                                                                delta: -1,
                                                                                userId: {{ (int) $person->id }}
                                                                            }
                                                                        })
                                                                    );
                                                                }
                                                            })
                                                            .catch(error => {
                                                                console.error(error);
                                                            })
                                                            .finally(() => {
                                                                unfollowing = false;
                                                            });
                                                        "
                                                        :disabled="unfollowing"
                                                        class="shrink-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-600 text-[10px] font-bold hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition disabled:opacity-50 disabled:cursor-not-allowed"
                                                    >
                                                        <svg
                                                            x-show="!unfollowing"
                                                            class="w-3 h-3"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <path
                                                                stroke-linecap="round"
                                                                stroke-linejoin="round"
                                                                d="M6 12h12"
                                                            />
                                                        </svg>

                                                        <svg
                                                            x-show="unfollowing"
                                                            x-cloak
                                                            class="w-3 h-3 animate-spin"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <circle cx="12" cy="12" r="9" class="opacity-25"></circle>
                                                            <path d="M21 12a9 9 0 01-9 9"></path>
                                                        </svg>

                                                        <span x-text="unfollowing ? 'Unfollowing...' : 'Unfollow'"></span>
                                                    </button>
                                                    @endif
                                                </div>
                                            @endif
                                        @empty
                                            <div class="sm:col-span-2 py-14 text-center bg-white rounded-xl border border-dashed border-slate-200">
                                                <div class="w-11 h-11 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                                    <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-6-6h12" />
                                                    </svg>
                                                </div>
                                                <p class="text-sm font-semibold text-slate-700">Not following anyone yet</p>
                                                <p class="text-xs text-slate-400 mt-1">People this user follows will appear here.</p>
                                            </div>
                                        @endforelse
                                    </div>

                                    @if(method_exists($following, 'hasPages') && $following->hasPages())
                                        <div class="mt-5">
                                            {{ $following->appends(['tab' => 'following'])->links() }}
                                        </div>
                                     @endif
                                </div>

                                @elseif($activeTab === 'tests')
                                    <div class="space-y-6 max-w-full w-full">
                                        @if(!$isOwnProfile)
                                            <div class="bg-white rounded-2xl border border-slate-200/70 p-12 text-center">
                                                <div class="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
                                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                                                    </svg>
                                                </div>
                                                <h3 class="text-sm font-bold text-slate-800">Test Records are Private</h3>
                                                <p class="text-xs text-slate-400 mt-1">This student's test results are only visible to them.</p>
                                            </div>
                                        @else
                                            {{-- Test Stats Overview --}}
                                            @if($testStats && $testStats['total'] > 0)
                                                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                                    <div class="bg-white rounded-2xl border border-slate-200/70 p-4 text-center shadow-xs">
                                                        <div class="text-2xl font-extrabold text-[#0b1329]">{{ $testStats['total'] }}</div>
                                                        <div class="text-[11px] text-slate-400 font-bold uppercase tracking-wider mt-1">Tests Completed</div>
                                                    </div>
                                                    <div class="bg-white rounded-2xl border border-slate-200/70 p-4 text-center shadow-xs">
                                                        <div class="text-2xl font-extrabold text-emerald-600">{{ $testStats['passed'] }}</div>
                                                        <div class="text-[11px] text-slate-400 font-bold uppercase tracking-wider mt-1">Passed</div>
                                                    </div>
                                                    <div class="bg-white rounded-2xl border border-slate-200/70 p-4 text-center shadow-xs">
                                                        <div class="text-2xl font-extrabold text-rose-600">{{ $testStats['failed'] }}</div>
                                                        <div class="text-[11px] text-slate-400 font-bold uppercase tracking-wider mt-1">Retake Needed</div>
                                                    </div>
                                                    <div class="bg-white rounded-2xl border border-slate-200/70 p-4 text-center shadow-xs">
                                                        <div class="text-2xl font-extrabold text-amber-500">{{ $testStats['best_score'] }}%</div>
                                                        <div class="text-[11px] text-slate-400 font-bold uppercase tracking-wider mt-1">Best Score</div>
                                                    </div>
                                                </div>
                                            @endif

                                            {{-- Test History Cards --}}
                                            <div class="space-y-3">
                                                <div class="flex items-center justify-between">
                                                    <h3 class="text-xs font-bold text-slate-400 uppercase tracking-wider">Test Attempts & Scorecards</h3>
                                                    <a href="{{ route('tests.student.index') }}"
                                                       class="text-xs font-bold text-amber-600 hover:text-amber-700 transition flex items-center gap-1">
                                                        <span>Browse All Tests</span>
                                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                                        </svg>
                                                    </a>
                                                </div>

                                                @forelse(($testAttempts ?? collect()) as $attempt)
                                                    @php
                                                        $test = $attempt->test;
                                                        $isPass = $attempt->result === 'pass';
                                                    @endphp
                                                    <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-amber-300 hover:shadow-sm transition">
                                                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                                            <div class="flex-1 min-w-0">
                                                                <div class="flex items-center gap-2 mb-1.5 flex-wrap">
                                                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-slate-100 text-slate-700 border border-slate-200">
                                                                        {{ $test->testLevel->name ?? 'Proficiency Test' }}
                                                                    </span>
                                                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold {{ $isPass ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-rose-100 text-rose-800 border border-rose-200' }}">
                                                                        {{ $isPass ? '✓ PASSED' : '✗ FAILED' }}
                                                                    </span>
                                                                    <span class="text-[11px] text-slate-400">
                                                                        Attempt #{{ $attempt->attempt_number }}
                                                                    </span>
                                                                </div>

                                                                <h4 class="text-sm font-bold text-slate-900 truncate">{{ $test->title ?? 'Test' }}</h4>

                                                                <div class="flex items-center gap-4 mt-2 text-xs text-slate-500 flex-wrap">
                                                                    <span>
                                                                        Score: <strong class="text-slate-800">{{ $attempt->score_obtained }} / {{ $test->total_marks ?? '—' }} pts</strong> ({{ $attempt->percentage }}%)
                                                                    </span>
                                                                    <span>•</span>
                                                                    <span>
                                                                        Correct: <strong class="text-slate-800">{{ $attempt->correct_count }} of {{ $attempt->total_questions }}</strong>
                                                                    </span>
                                                                    <span>•</span>
                                                                    <span class="text-[11px] text-slate-400">
                                                                        {{ $attempt->submitted_at?->format('M d, Y · h:i A') ?? 'N/A' }}
                                                                    </span>
                                                                </div>
                                                            </div>

                                                            <div class="shrink-0">
                                                                @if($test)
                                                                    <a href="{{ route('tests.student.result', ['test' => $test, 'attempt' => $attempt]) }}"
                                                                       class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-[#0b1329] bg-amber-400 hover:bg-amber-500 transition shadow-xs">
                                                                        <span>View Scorecard</span>
                                                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                                                                        </svg>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>
                                                @empty
                                                    <div class="bg-white rounded-2xl border border-dashed border-slate-200 p-10 text-center">
                                                        <div class="w-12 h-12 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center mx-auto mb-3">
                                                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                                            </svg>
                                                        </div>
                                                        <h4 class="text-sm font-bold text-slate-800">No Tests Taken Yet</h4>
                                                        <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                                                            You haven't participated in any online language proficiency tests yet.
                                                        </p>
                                                        <a href="{{ route('tests.student.index') }}"
                                                           class="inline-flex items-center gap-1.5 mt-4 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#0b1329] hover:bg-slate-800 transition shadow-xs">
                                                            <span>Explore Available Tests</span>
                                                            <svg class="w-3.5 h-3.5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                                                            </svg>
                                                        </a>
                                                    </div>
                                                @endforelse

                                                @if(isset($testAttempts) && method_exists($testAttempts, 'hasPages') && $testAttempts->hasPages())
                                                    <div class="mt-4">
                                                        {{ $testAttempts->appends(['tab' => 'tests'])->links() }}
                                                    </div>
                                                @endif
                                            </div>
                                        @endif
                                    </div>
                                @endif

    {{-- GLOBAL LOGIN PROMPT MODAL --}}
    <div
        x-data="{ globalLoginModal: false }"
        @open-login-modal.window="globalLoginModal = true"
        x-show="globalLoginModal"
        class="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4"
        style="display: none;"
        x-cloak
    >
    <x-community.share-modal />
</div>

    {{-- DELETE ACCOUNT SWEETALERT --}}
    <script>
        function confirmAccountDelete() {
            Swal.fire({
                title: 'Delete Account?',
                html: 'Enter your password to confirm account deletion. This action cannot be undone.',
                icon: 'warning',
                input: 'password',
                inputLabel: 'Current Password',
                inputPlaceholder: 'Type your password',
                inputAttributes: { autocomplete: 'off' },
                showCancelButton: true,
                confirmButtonText: 'Delete My Account',
                cancelButtonText: 'Cancel',
                confirmButtonColor: '#E11D48',
                cancelButtonColor: '#64748b',
                focusConfirm: false,
                preConfirm: (password) => {
                    if (!password) {
                        Swal.showValidationMessage('Password is required');
                        return false;
                    }
                    return password;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-password').value = result.value;
                    document.getElementById('delete-account-form').submit();
                }
            });
        }
    </script>
</body>
</html>
