<?php

namespace App\Http\Controllers\Community;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateProfileRequest;
use App\Models\Country;
use App\Models\Profile;
use App\Models\Like;
use App\Models\Share;
use App\Models\Test;
use App\Models\TestAttempt;
use App\Models\Comment;
use App\Models\Post;
use App\Models\User;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class UserProfileController extends Controller
{
    use AuthorizesRequests;

    /**
     * Display a user's public profile.
     *
     * Note:
     * /community/profile/{username} can also match
     * /community/profile/edit because of the dynamic {username}
     * parameter. We handle "edit" here so the existing route
     * structure does not need to be changed.
     */
    public function show(string $username): View|RedirectResponse
    {
        /*
        |--------------------------------------------------------------------------
        | Handle Profile Edit URL
        |--------------------------------------------------------------------------
        |
        | Because /community/profile/{username} is a dynamic public route,
        | Laravel may reach this method when the URL is:
        |
        | /community/profile/edit
        |
        | In that case, send the authenticated user to the existing edit()
        | method instead of looking for a profile with username "edit".
        |
        */

        if ($username === 'edit') {
            if (!Auth::check()) {
                return redirect()->route('login');
            }

            return $this->edit();
        }

        /*
        |--------------------------------------------------------------------------
        | Public Profile
        |--------------------------------------------------------------------------
        */

        $profile = Profile::with([
            'user.stats',
            'country',
        ])
            ->where('username', $username)
            ->first();

        // Fallback 1: If parameter is numeric, treat as user_id or profile id
        if (!$profile && is_numeric($username)) {
            $profile = Profile::with(['user.stats', 'country'])
                ->where('user_id', (int) $username)
                ->orWhere('id', (int) $username)
                ->first();
        }

        // Fallback 2: Check if an existing notification recorded this username for a user
        if (!$profile) {
            $matchedUserId = \Illuminate\Support\Facades\DB::table('notifications')
                ->where('data', 'like', '%' . $username . '%')
                ->pluck('data')
                ->map(function ($raw) {
                    $decoded = is_string($raw) ? json_decode($raw, true) : (array) $raw;
                    return $decoded['user_id'] ?? null;
                })
                ->filter()
                ->first();

            if ($matchedUserId) {
                $profile = Profile::with(['user.stats', 'country'])
                    ->where('user_id', (int) $matchedUserId)
                    ->first();
            }
        }

        // Fallback 3: Prefix / slug matching (handles truncated or trailing random suffixes)
        if (!$profile && strlen($username) >= 6) {
            $cleanPrefix = preg_replace('/-[a-z0-9]{2,6}$/i', '', $username);
            $profile = Profile::with(['user.stats', 'country'])
                ->where('username', 'like', $cleanPrefix . '%')
                ->first();

            if (!$profile) {
                $profile = Profile::with(['user.stats', 'country'])
                    ->where('username', 'like', substr($username, 0, 10) . '%')
                    ->first();
            }
        }

        // Fallback 4: Match by user's full name slug (e.g. "test-jign" matches "test jign")
        if (!$profile) {
            $nameCandidate = str_replace('-', ' ', $username);
            $matchedUser = User::where('name', 'like', $nameCandidate . '%')->first();
            if ($matchedUser && $matchedUser->profile) {
                $profile = $matchedUser->profile->load(['user.stats', 'country']);
            }
        }

        if (!$profile) {
            abort(404, 'User profile not found.');
        }

        // Canonical redirect: If the requested username was an old identifier, redirect to their active profile
        if ($profile->username && $profile->username !== $username) {
            return redirect()->route('community.profile', ['username' => $profile->username], 301);
        }

        $user = $profile->user;

        /*
        |--------------------------------------------------------------------------
        | User Posts
        |--------------------------------------------------------------------------
        */

        $posts = $user->posts()
            ->with([
                'category',
                'media',
                'tags',
                'comments' => function ($query) {
                    $query->whereNull('parent_id')
                        ->latest()
                        ->take(4)
                        ->with([
                            'user.profile',
                            'replies' => function ($rq) {
                                $rq->oldest()->with('user.profile');
                            },
                        ]);
                },
            ])
            ->withCount([
                'likes',
                'comments',
                'shares',
            ])
            ->latest()
            ->paginate(5, ['*'], 'posts_page');

        /*
        |--------------------------------------------------------------------------
        | User Comments
        |--------------------------------------------------------------------------
        */

        $comments = $user->comments()
            ->with([
                'post.category',
                'post.user.profile',
                'parent.user.profile',
            ])
            ->whereNull('comments.deleted_at')
            ->whereHas('post')
            ->latest()
            ->paginate(10, ['*'], 'comments_page');

        /*
        |--------------------------------------------------------------------------
        | User Activities
        |--------------------------------------------------------------------------
        */

        $activities = $user->activityLogs()
            ->latest()
            ->paginate(10, ['*'], 'activity_page');

        /*
        |--------------------------------------------------------------------------
        | Profile Statistics
        |--------------------------------------------------------------------------
        */

        $profileStats = [
            'posts' => $user->posts()
                ->whereNull('posts.deleted_at')
                ->count(),

            'comments' => $user->comments()
                ->whereNull('comments.deleted_at')
                ->whereHas('post')
                ->count(),

            'likes_received' => Like::whereHas('post', function ($query) use ($user) {
                $query
                    ->where('user_id', $user->id)
                    ->whereNull('posts.deleted_at');
            })->count(),

            'shares' => Share::whereHas('post', function ($query) use ($user) {
                $query
                    ->where('user_id', $user->id)
                    ->whereNull('posts.deleted_at');
            })->count(),

            'referred' => (int) ($user->stat?->referred_count ?? $user->referred_count ?? 0),
        ];

        /*
        |--------------------------------------------------------------------------
        | Top Contributors
        |--------------------------------------------------------------------------
        */

        $topContributors = User::getTopContributors(5);

        /*
        |--------------------------------------------------------------------------
        | Test Results (own profile only)
        |--------------------------------------------------------------------------
        */

        $testStats = null;
        $testAttempts = null;

        $isOwnProfile = auth()->check() && (int) auth()->id() === (int) $user->id;

        if ($isOwnProfile) {
            $testAttempts = TestAttempt::where('user_id', $user->id)
                ->where('status', 'completed')
                ->with(['test.testLevel'])
                ->latest('submitted_at')
                ->paginate(10, ['*'], 'tests_page');

            $completedQuery = TestAttempt::where('user_id', $user->id)
                ->where('status', 'completed');

            $testStats = [
                'total' => $completedQuery->count(),
                'passed' => (clone $completedQuery)->where('result', 'pass')->count(),
                'failed' => (clone $completedQuery)->where('result', 'fail')->count(),
                'avg_score' => round((clone $completedQuery)->avg('percentage') ?? 0, 1),
                'best_score' => (clone $completedQuery)->max('percentage') ?? 0,
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Profile Activity Progress Bar (Set by Admin)
        |--------------------------------------------------------------------------
        */
        $activityProgress = app(\App\Services\ProfileActivityService::class)->calculateProgress($user);

        /*
        |--------------------------------------------------------------------------
        | Public Profile View
        |--------------------------------------------------------------------------
        */

        $profileUser = $user;

        return view(
            'community.profile.show',
            compact(
                'profile',
                'user',
                'profileUser',
                'posts',
                'comments',
                'activities',
                'profileStats',
                'topContributors',
                'testStats',
                'testAttempts',
                'activityProgress'
            )
        );
    }

    /**
     * Show the authenticated user's profile edit page.
     */
    public function edit(): View
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();

        $profile = Profile::where('user_id', $user->id)
            ->with([
                'user.stats',
                'country',
            ])
            ->firstOrFail();

        $this->authorize('update', $profile);

        $countries = Country::orderBy('name')->get();

        /*
        |--------------------------------------------------------------------------
        | User Posts
        |--------------------------------------------------------------------------
        */

        $posts = $user->posts()
            ->latest()
            ->paginate(5, ['*'], 'posts_page');

        /*
        |--------------------------------------------------------------------------
        | User Comments
        |--------------------------------------------------------------------------
        */

        $comments = $user->comments()
            ->latest()
            ->paginate(5, ['*'], 'comments_page');

        /*
        |--------------------------------------------------------------------------
        | User Activities
        |--------------------------------------------------------------------------
        */

        $activities = $user->activityLogs()
            ->latest()
            ->paginate(10, ['*'], 'activity_page');

        /*
        |--------------------------------------------------------------------------
        | Profile Statistics
        |--------------------------------------------------------------------------
        */

        $profileStats = [
            'posts' => $user->posts()
                ->whereNull('posts.deleted_at')
                ->count(),

            'comments' => $user->comments()
                ->whereNull('comments.deleted_at')
                ->count(),

            'likes_received' => Like::whereHas('post', function ($query) use ($user) {
                $query
                    ->where('user_id', $user->id)
                    ->whereNull('posts.deleted_at');
            })->count(),

            'shares' => Share::whereHas('post', function ($query) use ($user) {
                $query
                    ->where('user_id', $user->id)
                    ->whereNull('posts.deleted_at');
            })->count(),
        ];

        /*
        |--------------------------------------------------------------------------
        | Top Contributors
        |--------------------------------------------------------------------------
        */

        $topContributors = User::getTopContributors(5);

        /*
        |--------------------------------------------------------------------------
        | Edit Profile View
        |--------------------------------------------------------------------------
        */

        return view(
            'community.profile.edit',
            compact(
                'profile',
                'user',
                'countries',
                'posts',
                'comments',
                'activities',
                'profileStats',
                'topContributors'
            )
        );
    }

    /**
     * Update the authenticated user's profile.
     */
    public function update(UpdateProfileRequest $request): RedirectResponse
    {
        $user = Auth::user();

        $profile = Profile::where('user_id', $user->id)
            ->firstOrFail();

        $this->authorize('update', $profile);

        $data = $request->validated();

        /*
        |--------------------------------------------------------------------------
        | Avatar
        |--------------------------------------------------------------------------
        */

        if ($request->hasFile('avatar')) {
            if (
                $profile->avatar &&
                Storage::disk('public')->exists($profile->avatar)
            ) {
                Storage::disk('public')->delete($profile->avatar);
            }

            $data['avatar'] = $request
                ->file('avatar')
                ->store('avatars', 'public');
        }

        /*
        |--------------------------------------------------------------------------
        | Cover Image
        |--------------------------------------------------------------------------
        */

        if ($request->hasFile('cover_image')) {
            if (
                $profile->cover_image &&
                Storage::disk('public')->exists($profile->cover_image)
            ) {
                Storage::disk('public')->delete($profile->cover_image);
            }

            $data['cover_image'] = $request
                ->file('cover_image')
                ->store('covers', 'public');
        }

        /*
        |--------------------------------------------------------------------------
        | Save Profile
        |--------------------------------------------------------------------------
        */

        if (isset($data['name']) && filled($data['name'])) {
            $user->update(['name' => trim($data['name'])]);
        }

        $profile->update($data);

        return redirect()
            ->route('community.profile', [
                'username' => $profile->username,
            ])
            ->with('success', 'Profile updated successfully.');
    }

    /**
     * Display a user's followers.
     */
    public function followers(string $username): View
    {
        $profile = Profile::with('user')
            ->where('username', $username)
            ->firstOrFail();

        $user = $profile->user;

        $followers = $user->followers()
            ->with('profile')
            ->paginate(15);

        return view(
            'community.profile.followers',
            compact(
                'profile',
                'user',
                'followers'
            )
        );
    }

    /**
     * Display users that this user follows.
     */
    public function following(string $username): View
    {
        $profile = Profile::with('user')
            ->where('username', $username)
            ->firstOrFail();

        $user = $profile->user;

        $following = $user->following()
            ->with('profile')
            ->paginate(15);

        return view(
            'community.profile.following',
            compact(
                'profile',
                'user',
                'following'
            )
        );
    }

    /**
     * Display the authenticated user's profile directly via their username.
     */
    public function myProfile(): RedirectResponse
    {
        $user = Auth::user();

        $profile = Profile::where('user_id', $user->id)
            ->firstOrFail();

        return redirect()->route(
            'community.profile',
            [
                'username' => $profile->username,
            ]
        );
    }
}