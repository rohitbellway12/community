<?php

namespace App\Http\Controllers\Community;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreGroupRequest;
use App\Http\Requests\UpdateGroupRequest;
use App\Models\Group;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class GroupController extends Controller
{
    use AuthorizesRequests;

    /**
     * Group Management Page
     */
    public function index(Request $request)
    {
        $user = $request->user();

        /*
        |--------------------------------------------------------------------------
        | Joined / Owned Groups
        |--------------------------------------------------------------------------
        |
        | Only show groups where the authenticated user is an active member.
        |
        */
        $groups = $user->groups()
            ->wherePivot('status', 'active')
            ->withCount('users')
            ->with([
                'posts' => function ($query) {
                    $query
                        ->with([
                            'user',
                            'group',
                            'media',
                            'likes',
                            'comments',
                        ])
                        ->latest()
                        ->limit(10);
                },
            ])
            ->when(
                $request->filled('search'),
                function ($query) use ($request) {
                    $query->where(
                        'groups.name',
                        'like',
                        '%' . trim($request->search) . '%'
                    );
                }
            )
            ->latest('groups.created_at')
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Membership Information
        |--------------------------------------------------------------------------
        */
        $groups->each(function ($group) use ($user) {
            $group->is_owner =
                (int) $group->owner_id === (int) $user->id
                || optional($group->pivot)->role === 'owner'
                || optional($group->pivot)->role == 2;

            $group->membership_role = optional($group->pivot)->role;
        });

        /*
        |--------------------------------------------------------------------------
        | Users
        |--------------------------------------------------------------------------
        |
        | Used in the Create Group modal.
        |
        */
        $users = User::query()
            ->where('id', '!=', $user->id)
            ->select([
                'id',
                'name',
                'email',
            ])
            ->orderBy('name')
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Community Sidebar Data
        |--------------------------------------------------------------------------
        */
        $notificationsCount = $user
            ->unreadNotifications()
            ->count();

        $topContributors = User::query()
            ->with('profile')
            ->withCount('posts')
            ->orderByDesc('posts_count')
            ->limit(5)
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Keep these compatible with existing sidebar component.
        |--------------------------------------------------------------------------
        |
        | If your CommunityController already loads categories/tags,
        | you can move those queries here later.
        |
        */
        $categories = collect();
        $tags = collect();

        /*
        |--------------------------------------------------------------------------
        | View
        |--------------------------------------------------------------------------
        */
        return view('community.groups.index', [
            'groups' => $groups,
            'users' => $users,

            'user' => $user,

            'notificationsCount' => $notificationsCount,

            'topContributors' => $topContributors,
            'categories' => $categories,
            'tags' => $tags,
        ]);
    }

    /**
     * Create Group
     */
    public function store(StoreGroupRequest $request)
    {
        $user = $request->user();

        $data = $request->validated();

        $data['owner_id'] = $user->id;

        /*
        |--------------------------------------------------------------------------
        | Cover Image
        |--------------------------------------------------------------------------
        */
        if ($request->hasFile('cover_image')) {
            $data['cover_image'] = $request
                ->file('cover_image')
                ->store('groups/covers', 'public');
        }

        /*
        |--------------------------------------------------------------------------
        | Create Group
        |--------------------------------------------------------------------------
        */
        $group = Group::create($data);

        /*
        |--------------------------------------------------------------------------
        | Add Owner As Active Member
        |--------------------------------------------------------------------------
        */
        $group->users()->attach(
            $user->id,
            [
                'role' => 'owner',
                'status' => 'active',
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | Add Selected Members
        |--------------------------------------------------------------------------
        */
        $memberIds = $request->input('members', []);

        if (is_array($memberIds) && !empty($memberIds)) {

            $memberIds = collect($memberIds)
                ->map(fn ($id) => (int) $id)
                ->filter()
                ->unique()
                ->reject(fn ($id) => $id === (int) $user->id)
                ->values();

            foreach ($memberIds as $memberId) {

                /*
                | Make sure the user actually exists.
                */
                if (!User::whereKey($memberId)->exists()) {
                    continue;
                }

                $group->users()->syncWithoutDetaching([
                    $memberId => [
                        'role' => 'member',
                        'status' => 'active',
                    ],
                ]);
            }
        }

        return redirect()
            ->route('community.groups.index')
            ->with('success', 'Group created successfully.');
    }

    /**
     * Show Group
     */
    public function show(Group $group)
{
    
    $user = Auth::user();

    /*
    |--------------------------------------------------------------------------
    | Group Stats
    |--------------------------------------------------------------------------
    */

    $group->loadCount('users');


    /*
    |--------------------------------------------------------------------------
    | Current User Membership
    |--------------------------------------------------------------------------
    */

    $membership = $user
        ? $group->users()
            ->where('user_id', $user->id)
            ->first()?->pivot
        : null;


    $isMember = $membership
        && $membership->status === 'active';


    /*
    |--------------------------------------------------------------------------
    | Group Posts
    |--------------------------------------------------------------------------
    |
    | Only members can see group posts.
    |
    */

    $posts = $isMember
        ? $group->posts()
            ->with([
                'user',
                'user.profile',
                'group',
                'likes',
                'comments',
                'media',
            ])
            ->latest()
            ->paginate(10)
        : collect();


    /*
    |--------------------------------------------------------------------------
    | Notification Count
    |--------------------------------------------------------------------------
    */

    $notificationsCount = $user
        ? $user->unreadNotifications()->count()
        : 0;


    /*
    |--------------------------------------------------------------------------
    | Right Sidebar
    |--------------------------------------------------------------------------
    */

    $topContributors = User::query()
        ->with('profile')
        ->withCount('posts')
        ->orderByDesc('posts_count')
        ->limit(5)
        ->get();


    /*
    |--------------------------------------------------------------------------
    | Existing Sidebar Data
    |--------------------------------------------------------------------------
    */

    $categories = collect();

    $tags = collect();


    /*
    |--------------------------------------------------------------------------
    | View
    |--------------------------------------------------------------------------
    */

    return view('community.groups.show', [
        'group' => $group,
        'isMember' => $isMember,
        'membership' => $membership,
        'posts' => $posts,

        'user' => $user,

        'notificationsCount' => $notificationsCount,

        'topContributors' => $topContributors,

        'categories' => $categories,

        'tags' => $tags,
    ]);
}

    /**
     * Join Group
     */
    // public function join(Request $request, Group $group)
    // {
    //     $userId = $request->user()->id;

    //     $existingMembership = $group->users()
    //         ->where('user_id', $userId)
    //         ->first();

    //     if ($existingMembership) {

    //         if (
    //             isset($existingMembership->pivot->status)
    //             && $existingMembership->pivot->status === 'active'
    //         ) {
    //             return back()->with(
    //                 'error',
    //                 'You are already a member of this group.'
    //             );
    //         }

    //         return back()->with(
    //             'error',
    //             'You already have a membership or pending request.'
    //         );
    //     }

    //     $group->users()->attach(
    //         $userId,
    //         [
    //             'role' => 'member',
    //             'status' => 'active',
    //         ]
    //     );

    //     return back()->with(
    //         'success',
    //         'You have successfully joined the group.'
    //     );
    // }



    public function join(Request $request, Group $group)
    {
        $user = $request->user();
        $userId = $user->id;

        $existingMembership = $group->users()
            ->where('user_id', $userId)
            ->first();

        if ($existingMembership) {
            $status = $existingMembership->pivot->status ?? null;

            if ($status === 'active') {
                return back()->with('error', 'You are already a member of this group.');
            }

            if ($status === 'pending') {
                return back()->with('error', 'Your join request is already pending owner approval.');
            }
        }

        // Pending status ke sath attach karein
        $group->users()->syncWithoutDetaching([
            $userId => [
                'role' => 'member',
                'status' => 'pending',
            ]
        ]);

        // Group owner ko Laravel Notification bhejein
        $owner = \App\Models\User::find($group->owner_id);
        if ($owner && (int) $owner->id !== (int) $userId) {
            $owner->notify(new \App\Notifications\GroupJoinRequestNotification($group, $user));
        }

        return back()->with('success', 'Join request sent successfully. Waiting for owner approval.');
    }

    /**
     * Leave Group
     */
    public function leave(Request $request, Group $group)
    {
        $userId = $request->user()->id;

        /*
        |--------------------------------------------------------------------------
        | Owner Cannot Leave Own Group
        |--------------------------------------------------------------------------
        */
        if ((int) $group->owner_id === (int) $userId) {
            return back()->with(
                'error',
                'Group owners cannot leave their own group.'
            );
        }

        $group->users()->detach($userId);

        return redirect()
            ->route('community.groups.index')
            ->with(
                'success',
                'You have left the group.'
            );
    }

    /**
     * Group Members
     */
    public function members(Group $group)
    {
        $members = $group->users()
            ->withPivot([
                'role',
                'status',
            ])
            ->paginate(20);

        return view(
            'community.groups.members',
            compact(
                'group',
                'members'
            )
        );
    }

    /**
     * Update Group
     */
    public function update(
        UpdateGroupRequest $request,
        Group $group
    ) {
        $user = $request->user();

        /*
        |--------------------------------------------------------------------------
        | Owner Check
        |--------------------------------------------------------------------------
        */
        if ((int) $group->owner_id !== (int) $user->id) {
            return back()->with(
                'error',
                'Unauthorized action.'
            );
        }

        $data = $request->validated();

        /*
        |--------------------------------------------------------------------------
        | Cover Image
        |--------------------------------------------------------------------------
        */
        if ($request->hasFile('cover_image')) {

            if ($group->cover_image) {
                Storage::disk('public')->delete(
                    $group->cover_image
                );
            }

            $data['cover_image'] = $request
                ->file('cover_image')
                ->store('groups/covers', 'public');
        }

        /*
        |--------------------------------------------------------------------------
        | Update
        |--------------------------------------------------------------------------
        */
        $group->update($data);

        return back()->with(
            'success',
            'Group updated successfully.'
        );
    }

    /**
     * Delete Group
     */
    public function destroy(
        Request $request,
        Group $group
    ) {
        $user = $request->user();

        /*
        |--------------------------------------------------------------------------
        | Owner Check
        |--------------------------------------------------------------------------
        */
        if ((int) $group->owner_id !== (int) $user->id) {
            return back()->with(
                'error',
                'Unauthorized action.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Load Posts + Media
        |--------------------------------------------------------------------------
        */
        $group->load([
            'posts.media',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Delete Posts + Media
        |--------------------------------------------------------------------------
        */
        foreach ($group->posts as $post) {

            foreach ($post->media as $media) {

                if ($media->file_path) {
                    Storage::disk('public')->delete(
                        $media->file_path
                    );
                }

                $media->delete();
            }

            /*
            | Backward compatibility for old image column.
            */
            if (!empty($post->image)) {
                Storage::disk('public')->delete(
                    $post->image
                );
            }

            $post->delete();
        }

        /*
        |--------------------------------------------------------------------------
        | Delete Group Cover
        |--------------------------------------------------------------------------
        */
        if ($group->cover_image) {
            Storage::disk('public')->delete(
                $group->cover_image
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Remove Members
        |--------------------------------------------------------------------------
        */
        $group->users()->detach();

        /*
        |--------------------------------------------------------------------------
        | Delete Group
        |--------------------------------------------------------------------------
        */
        $group->delete();

        return redirect()
            ->route('community.groups.index')
            ->with(
                'success',
                'Group and its posts deleted successfully.'
            );
    }


    /**
     * Accept Group Join Request
     */
    public function acceptRequest(Request $request, Group $group, User $userToAccept)
    {
        $user = $request->user();

        if ((int) $group->owner_id !== (int) $user->id) {
            return back()->with('error', 'Unauthorized action.');
        }

        $group->users()->updateExistingPivot($userToAccept->id, [
            'status' => 'active',
        ]);

        return back()->with('success', "{$userToAccept->name}'s join request has been accepted.");
    }

    /**
     * Reject/Remove Group Join Request
     */
    public function rejectRequest(Request $request, Group $group, User $userToReject)
    {
        $user = $request->user();

        if ((int) $group->owner_id !== (int) $user->id) {
            return back()->with('error', 'Unauthorized action.');
        }

        $group->users()->detach($userToReject->id);

        return back()->with('success', "{$userToReject->name}'s join request has been rejected.");
    }
}