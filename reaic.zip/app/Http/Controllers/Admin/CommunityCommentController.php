<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use Illuminate\Http\Request;

class CommunityCommentController extends Controller
{
    public function index(Request $request)
    {
        $query = Comment::with(['user', 'post', 'replies.user', 'reports']);

        // Search filter
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('content', 'like', "%{$search}%")
                  ->orWhereHas('user', function ($uq) use ($search) {
                      $uq->where('name', 'like', "%{$search}%")
                        ->orWhere('username', 'like', "%{$search}%");
                  })
                  ->orWhereHas('post', function ($pq) use ($search) {
                      $pq->where('title', 'like', "%{$search}%");
                  });
            });
        }

        // Status filter (safe fallback if status is an enum or string)
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        // Type filter (Comment vs Reply: comments have null parent_id, replies have parent_id)
        if ($request->filled('type')) {
            if ($request->input('type') === 'Comment') {
                $query->whereNull('parent_id');
            } elseif ($request->input('type') === 'Reply') {
                $query->whereNotNull('parent_id');
            }
        }

        $comments = $query->latest()->paginate(10)->withQueryString();

        // Calculate statistics for stat cards safely
        $totalCommentsCount = Comment::count();
        $todayCommentsCount = Comment::whereDate('created_at', today())->count();
        
        // Wrap count queries in try-catch blocks to prevent 500 errors if columns/enums differ
        try {
            $reportedCommentsCount = Comment::where('status', 'reported')->count();
        } catch (\Throwable $e) {
            $reportedCommentsCount = 0;
        }

        try {
            $hiddenCommentsCount = Comment::where('status', 'hidden')->count();
        } catch (\Throwable $e) {
            $hiddenCommentsCount = 0;
        }

        return view('admin.comments', compact(
            'comments',
            'totalCommentsCount',
            'todayCommentsCount',
            'reportedCommentsCount',
            'hiddenCommentsCount'
        ));
    }

    public function toggleHide(Comment $comment)
    {
        $currentStatusValue = is_object($comment->status) ? ($comment->status->value ?? $comment->status->name) : $comment->status;
        $newStatus = $currentStatusValue === 'hidden' ? 'active' : 'hidden';
        $comment->update(['status' => $newStatus]);

        if (request()->wantsJson()) {
            return response()->json([
                'success' => true,
                'status' => ucfirst($newStatus),
                'message' => $newStatus === 'hidden' ? 'Comment hidden successfully.' : 'Comment restored.'
            ]);
        }

        return back()->with('success', 'Comment status updated successfully.');
    }

    public function destroy(Comment $comment)
    {
        $comment->delete();

        if (request()->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Comment deleted successfully.'
            ]);
        }

        return back()->with('success', 'Comment deleted successfully.');
    }

    public function bulkAction(Request $request)
    {
        $request->validate([
            'action' => 'required|in:hide,delete',
            'ids' => 'required|array',
            'ids.*' => 'exists:comments,id'
        ]);

        if ($request->action === 'hide') {
            Comment::whereIn('id', $request->ids)->update(['status' => 'hidden']);
            $message = count($request->ids) . ' comments hidden successfully.';
        } else {
            Comment::whereIn('id', $request->ids)->delete();
            $message = count($request->ids) . ' comments deleted successfully.';
        }

        return response()->json([
            'success' => true,
            'message' => $message
        ]);
    }
}