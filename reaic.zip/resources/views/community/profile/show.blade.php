@props([
    'title' => 'Community | REIAC',
    'active' => 'home',
    'user' => auth()->user(),
    'sidebar' => true,
    'rightbar' => true,
    'notificationsCount' => 0,
])

@php
    use App\Models\Follow;

    $avatarUrl = $profile->avatar
        ? asset('storage/' . $profile->avatar)
        : 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=e2e8f0&color=0f172a&size=200';

    $coverUrl = $profile->cover_image
        ? asset('storage/' . $profile->cover_image)
        : 'https://images.unsplash.com/photo-1557683316-973673baf926?w=1200&h=400&fit=crop';

    $bio = $profile->bio
        ?? 'Passionate about learning, sharing knowledge and connecting with the community.';

    $location = $profile->location
        ?? $profile->city
        ?? $profile->country?->name;

    $joinedDate = $user->created_at?->format('F Y');

    $username = $profile->username;

    $activeTab = request()->query('tab', 'posts');

    $followersCount = Follow::where('following_id', $user->id)->count();
    $followingCount = Follow::where('follower_id', $user->id)->count();

    $followers = collect();
    $following = collect();

    if ($activeTab === 'followers') {
        $followers = Follow::where('following_id', $user->id)
            ->with(['follower.profile'])
            ->latest()
            ->paginate(12, ['*'], 'followers_page')
            ->withQueryString();
    }

    if ($activeTab === 'following') {
        $following = Follow::where('follower_id', $user->id)
            ->with(['following.profile'])
            ->latest()
            ->paginate(12, ['*'], 'following_page')
            ->withQueryString();
    }
@endphp

@vite(['resources/css/app.css', 'resources/js/app.js'])

<div class="min-h-screen bg-slate-100/60 text-slate-800 antialiased selection:bg-amber-400 selection:text-slate-950 pb-20 lg:pb-0">
    <head>
        <meta name="csrf-token" content="{{ csrf_token() }}">
    </head>

    <div class="sticky top-0 z-50">
        <x-community.topbar :notifications-count="$notificationsCount" :user="$user" />
    </div>

    <div class="max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div class="grid grid-cols-1 lg:grid-cols-[280px_minmax(0,1fr)] gap-6 items-start">
            
            <x-community.sidebar :top-contributors="$topContributors ?? collect()" />

            <main class="min-w-0 w-full space-y-6">
                <div>
                    <a
                        href="{{ route('community.index') }}"
                        class="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-900 transition py-1"
                    >
                        <svg
                            class="w-4 h-4 shrink-0"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2.5"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M10 19l-7-7m0 0l7-7m-7 7h18"
                            />
                        </svg>
                        <span>Back to community feed</span>
                    </a>
                </div>

                <div class="bg-white rounded-2xl shadow-sm border border-slate-200/70 overflow-hidden">
                    <div class="h-36 sm:h-48 md:h-60 w-full relative bg-slate-900">
                        <img
                            src="{{ $coverUrl }}"
                            alt="Profile cover"
                            class="w-full h-full object-cover"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-transparent"></div>
                    </div>

                    <div class="px-5 sm:px-8 pb-6 relative">
                        <div class="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 -mt-12 sm:-mt-16 md:-mt-20 mb-5 relative z-10">
                            <div class="relative w-fit">
                                <img
                                    src="{{ $avatarUrl }}"
                                    alt="{{ $user->name }}"
                                    class="w-24 h-24 sm:w-32 sm:h-32 md:w-36 md:h-36 rounded-full border-4 border-white object-cover shadow-md bg-white"
                                >
                                <span class="absolute bottom-2 right-2 w-4 h-4 sm:w-5 sm:h-5 bg-emerald-500 border-2 border-white rounded-full"></span>
                            </div>

                            <div class="flex flex-wrap items-center gap-2.5">
                                @if(auth()->id() === $user->id)
                                    <a
                                        href="{{ route('community.profile.edit') }}"
                                        class="bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs px-5 py-2.5 rounded-xl transition shadow-sm inline-flex items-center justify-center cursor-pointer"
                                    >
                                        Edit Profile
                                    </a>
                                @endif
                            </div>
                        </div>

                        <div class="space-y-2.5 min-w-0">
                            <div class="flex flex-wrap items-center gap-2">
                                <h1 class="text-xl sm:text-2xl font-extrabold text-[#0b1329] tracking-tight break-words">
                                    {{ $user->name }}
                                </h1>

                                @if($profile->pronouns)
                                    <span class="bg-blue-50 text-blue-600 text-[10px] font-bold px-2 py-0.5 rounded-md">
                                        {{ $profile->pronouns }}
                                    </span>
                                @endif
                            </div>

                            <p class="text-xs text-slate-400 font-medium break-all">
                                {{ '@' . $username }}
                            </p>

                            <p class="text-xs text-slate-600 leading-relaxed max-w-3xl break-words">
                                {{ $bio }}
                            </p>

                            <div class="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs font-medium text-slate-400 pt-1">
                                @if($location)
                                    <span class="flex items-center gap-1 min-w-0">
                                        <svg
                                            class="w-3.5 h-3.5 text-slate-400 shrink-0"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            viewBox="0 0 24 24"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"
                                            />
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z"
                                            />
                                        </svg>
                                        <span class="truncate">{{ $location }}</span>
                                    </span>
                                @endif

                                @if($joinedDate)
                                    <span class="flex items-center gap-1 min-w-0">
                                        <svg
                                            class="w-3.5 h-3.5 text-slate-400 shrink-0"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            viewBox="0 0 24 24"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"
                                            />
                                        </svg>
                                        <span>Joined {{ $joinedDate }}</span>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-center mt-6 pt-6 border-t border-slate-100">
                            <div class="p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['posts'] ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Posts</div>
                            </div>

                            <div class="p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['comments'] ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Comments</div>
                            </div>

                            <div class="p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['likes_received'] ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Likes</div>
                            </div>

                            <a href="{{ request()->fullUrlWithQuery(['tab' => 'followers', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                               class="p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 hover:bg-amber-50 hover:border-amber-200 transition min-w-0 group">
                                <div class="text-lg font-extrabold text-[#0b1329] group-hover:text-amber-700">{{ number_format($followersCount) }}</div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Followers</div>
                            </a>

                            <a href="{{ request()->fullUrlWithQuery(['tab' => 'following', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                               class="p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 hover:bg-amber-50 hover:border-amber-200 transition min-w-0 group">
                                <div class="text-lg font-extrabold text-[#0b1329] group-hover:text-amber-700">{{ number_format($followingCount) }}</div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Following</div>
                            </a>

                            <div class="p-3.5 rounded-xl bg-slate-50 border border-slate-100/80 min-w-0">
                                <div class="text-lg font-extrabold text-[#0b1329]">
                                    {{ number_format($profileStats['shares'] ?? 0) }}
                                </div>
                                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Shares</div>
                            </div>
                        </div>

                        <div class="flex items-center gap-8 mt-6 border-b border-slate-200 text-xs sm:text-sm font-bold overflow-x-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'posts', 'page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'posts' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Posts
                            </a>

                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'comments', 'page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'comments' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Comments
                            </a>

                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'activity', 'page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'activity' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Activity
                            </a>

                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'followers', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'followers' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Followers <span class="text-slate-400 font-semibold">{{ number_format($followersCount) }}</span>
                            </a>

                            <a
                                href="{{ request()->fullUrlWithQuery(['tab' => 'following', 'page' => null, 'followers_page' => null, 'following_page' => null]) }}"
                                class="pb-3 border-b-2 {{ $activeTab === 'following' ? 'border-amber-500 text-[#0b1329]' : 'border-transparent text-slate-400 hover:text-slate-700' }} transition whitespace-nowrap"
                            >
                                Following <span class="text-slate-400 font-semibold">{{ number_format($followingCount) }}</span>
                            </a>
                        </div>

                        <div class="mt-6 space-y-4">
                            @if($activeTab === 'posts')
                                @forelse($posts as $post)
                                    <div
                                        class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/70 space-y-3.5"
                                        x-data="{
                                            likesCount: {{ $post->likes_count ?? 0 }},
                                            liked: {{ auth()->check() && $post->likes()->where('user_id', auth()->id())->exists() ? 'true' : 'false' }},
                                            saved: {{ auth()->check() && $post->savedBy()->where('user_id', auth()->id())->exists() ? 'true' : 'false' }},
                                            copied: false,
                                            commentsCount: {{ $post->comments_count ?? 0 }},
                                            showAllComments: false,
                                            expandedContent: false,
                                            expandedTags: false,
                                            newCommentText: '',
                                            comments: {{ json_encode($post->comments->map(fn($c) => [
                                                'id' => $c->id,
                                                'content' => $c->content,
                                                'user_id' => $c->user_id,
                                                'created_at_human' => $c->created_at->diffForHumans(),
                                                'user' => [
                                                    'name' => $c->user?->name ?? 'User',
                                                    'avatar' => $c->user?->profile?->avatar
                                                        ? asset('storage/' . $c->user->profile->avatar)
                                                        : 'https://ui-avatars.com/api/?name=' . urlencode($c->user?->name ?? 'User') . '&background=0c1b33&color=fff'
                                                ]
                                            ])) }},
                                            loadingMore: false,
                                            
                                            // Modal & Editing States
                                            showDeleteModal: false,
                                            commentToDeleteId: null,
                                            editingCommentId: null,
                                            editCommentText: '',

                                            toggleLike() {
                                                @guest
                                                    window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                    return;
                                                @endguest

                                                fetch('{{ route('community.posts.like', $post) }}', {
                                                    method: 'POST',
                                                    headers: {
                                                        'Content-Type': 'application/json',
                                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                        'Accept': 'application/json'
                                                    }
                                                })
                                                .then(async res => {
                                                    if (res.status === 401) {
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    }
                                                    return res.json();
                                                })
                                                .then(data => {
                                                    if (data && data.success) {
                                                        this.liked = data.liked;
                                                        this.likesCount = data.likes_count;
                                                    }
                                                });
                                            },

                                            toggleSave() {
                                                @guest
                                                    window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                    return;
                                                @endguest

                                                fetch('{{ route('community.posts.save', $post) }}', {
                                                    method: 'POST',
                                                    headers: {
                                                        'Content-Type': 'application/json',
                                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                        'Accept': 'application/json'
                                                    }
                                                })
                                                .then(async res => {
                                                    if (res.status === 401) {
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    }
                                                    return res.json();
                                                })
                                                .then(data => {
                                                    if (data && data.success) {
                                                        this.saved = data.saved;
                                                    }
                                                });
                                            },

                                            sharePost() {
                                                navigator.clipboard.writeText('{{ route('community.posts.show', $post) }}')
                                                    .then(() => {
                                                        this.copied = true;
                                                        setTimeout(() => {
                                                            this.copied = false;
                                                        }, 2000);
                                                    });
                                            },

                                            submitComment() {
                                                @guest
                                                    window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                    return;
                                                @endguest

                                                if (!this.newCommentText.trim()) {
                                                    return;
                                                }

                                                fetch('{{ route('community.posts.comment.store', $post) }}', {
                                                    method: 'POST',
                                                    headers: {
                                                        'Content-Type': 'application/json',
                                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                        'Accept': 'application/json'
                                                    },
                                                    body: JSON.stringify({
                                                        content: this.newCommentText
                                                    })
                                                })
                                                .then(async res => {
                                                    if (res.status === 401) {
                                                        window.dispatchEvent(new CustomEvent('open-login-modal'));
                                                        return;
                                                    }
                                                    return res.json();
                                                })
                                                .then(data => {
                                                    if (data && data.success) {
                                                        this.comments.unshift(data.comment);
                                                        this.commentsCount++;
                                                        this.newCommentText = '';
                                                    }
                                                });
                                            },

                                            confirmDeleteComment(commentId) {
                                                this.commentToDeleteId = commentId;
                                                this.showDeleteModal = true;
                                            },

                                            executeDeleteComment() {
                                                if (!this.commentToDeleteId) return;

                                                fetch(`/community/comments/${this.commentToDeleteId}`, {
                                                    method: 'DELETE',
                                                    headers: {
                                                        'Content-Type': 'application/json',
                                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                        'Accept': 'application/json'
                                                    }
                                                })
                                                .then(res => res.json())
                                                .then(data => {
                                                    if (data.success) {
                                                        this.comments = this.comments.filter(c => c.id !== this.commentToDeleteId);
                                                        this.commentsCount = Math.max(0, this.commentsCount - 1);
                                                    }
                                                    this.showDeleteModal = false;
                                                    this.commentToDeleteId = null;
                                                });
                                            },

                                            startEditComment(comment) {
                                                this.editingCommentId = comment.id;
                                                this.editCommentText = comment.content;
                                            },

                                            cancelEditComment() {
                                                this.editingCommentId = null;
                                                this.editCommentText = '';
                                            },

                                            updateComment(commentId) {
                                                if (!this.editCommentText.trim()) return;

                                                fetch(`/community/comments/${commentId}`, {
                                                    method: 'PUT',
                                                    headers: {
                                                        'Content-Type': 'application/json',
                                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                        'Accept': 'application/json'
                                                    },
                                                    body: JSON.stringify({ content: this.editCommentText })
                                                })
                                                .then(res => res.json())
                                                .then(data => {
                                                    if (data.success) {
                                                        let index = this.comments.findIndex(c => c.id === commentId);
                                                        if (index !== -1) {
                                                            this.comments[index].content = data.comment.content;
                                                        }
                                                        this.cancelEditComment();
                                                    }
                                                });
                                            },

                                            loadMoreComments() {
                                                this.loadingMore = true;
                                                fetch(`{{ route('community.posts.comments', $post) }}?skip=` + this.comments.length)
                                                    .then(res => res.json())
                                                    .then(data => {
                                                        this.comments = this.comments.concat(data.comments);
                                                        this.loadingMore = false;
                                                    });
                                            }
                                        }"
                                    >

                                        {{-- POST HEADER --}}
                                        <div class="flex items-start justify-between gap-2.5">
                                            <div class="flex items-center gap-2.5 min-w-0 flex-1">
                                                <img
                                                    src="{{ $avatarUrl }}"
                                                    alt="{{ $user->name }}"
                                                    class="w-9 h-9 rounded-full object-cover shrink-0 ring-1 ring-slate-100"
                                                >

                                                <div class="min-w-0 flex-1">
                                                    <div class="font-bold text-slate-900 text-xs truncate flex items-center gap-1.5">
                                                        <span class="hover:underline">
                                                            {{ $user->name }}
                                                        </span>
                                                    </div>

                                                    <div class="text-[11px] text-slate-400 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 mt-0.5 leading-tight">
                                                        @if($username)
                                                            <span class="truncate max-w-[120px] sm:max-w-[200px] font-medium text-slate-500">
                                                                {{ '@' . $username }}
                                                            </span>
                                                            <span class="text-slate-300">•</span>
                                                        @endif

                                                        <span class="whitespace-nowrap shrink-0 text-slate-400">
                                                            {{ $post->created_at?->diffForHumans() }}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="flex items-center gap-1.5 shrink-0">
                                                @if($post->category)
                                                    <span class="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md tracking-wide whitespace-nowrap">
                                                        {{ strtoupper($post->category->name) }}
                                                    </span>
                                                @endif

                                                @if($post->is_solved)
                                                    <span class="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 whitespace-nowrap">
                                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                        Solved
                                                    </span>
                                                @endif

                                                {{-- 3 DOTS DROPDOWN FOR POST OWNER / ADMIN --}}
                                                @auth
                                                    @if(auth()->id() === $post->user_id || (auth()->user()->role ?? '') === 'admin')
                                                        <div class="relative" x-data="{ openDropdown: false }">
                                                            <button 
                                                                type="button" 
                                                                @click="openDropdown = !openDropdown"
                                                                class="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition cursor-pointer"
                                                            >
                                                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                                                    <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/>
                                                                </svg>
                                                            </button>

                                                            <div 
                                                                x-show="openDropdown" 
                                                                @click.away="openDropdown = false"
                                                                x-transition.origin.top.right
                                                                class="absolute right-0 mt-1 w-36 bg-white border border-slate-200 rounded-xl shadow-lg py-1 z-20"
                                                                style="display: none;"
                                                            >
                                                                <form action="{{ route('community.posts.destroy', $post) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this post?');">
                                                                    @csrf
                                                                    @method('DELETE')
                                                                    <button 
                                                                        type="submit" 
                                                                        class="w-full text-left px-3.5 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 flex items-center gap-2 cursor-pointer"
                                                                    >
                                                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                                        </svg>
                                                                        Delete Post
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    @endif
                                                @endauth
                                            </div>
                                        </div>

                                        {{-- TITLE --}}
                                        @if($post->title)
                                            <h3 class="font-bold text-slate-900 text-sm leading-snug">
                                                <a
                                                    href="{{ route('community.posts.show', $post) }}"
                                                    class="hover:underline"
                                                >
                                                    {{ $post->title }}
                                                </a>
                                            </h3>
                                        @endif

                                        {{-- CONTENT --}}
                                        @if($post->content)
                                            <div class="text-xs text-slate-600 leading-relaxed">
                                                <p :class="expandedContent ? '' : 'line-clamp-3'">
                                                    {{ $post->content }}
                                                </p>

                                                @if(mb_strlen($post->content) > 160)
                                                    <button
                                                        type="button"
                                                        @click="expandedContent = !expandedContent"
                                                        class="text-xs font-bold text-amber-600 hover:text-amber-700 hover:underline mt-1.5 inline-block focus:outline-none cursor-pointer"
                                                    >
                                                        <span x-text="expandedContent ? 'Show less' : '...See more'"></span>
                                                    </button>
                                                @endif
                                            </div>
                                        @endif

                                        {{-- MEDIA --}}
                                        @if($post->media && $post->media->isNotEmpty())
                                            <div class="space-y-3 pt-1">
                                                @foreach($post->media as $mediaItem)
                                                    <div class="w-full max-h-[550px] bg-slate-900 rounded-xl overflow-hidden border border-slate-200 flex items-center justify-center">
                                                        @php
                                                            $filePath = $mediaItem->file_path ?? $mediaItem->path ?? '';
                                                        @endphp
                                                        @if(str_starts_with($mediaItem->file_type ?? '', 'video'))
                                                            <video
                                                                src="{{ asset('storage/' . $filePath) }}"
                                                                class="w-full max-h-[550px] object-contain"
                                                                controls
                                                                preload="metadata"
                                                            ></video>
                                                        @else
                                                            <img
                                                                src="{{ asset('storage/' . $filePath) }}"
                                                                alt="{{ $post->title }}"
                                                                class="w-full h-auto max-h-[550px] object-contain"
                                                            >
                                                        @endif
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endif

                                        {{-- TAGS --}}
                                        @if($post->tags && $post->tags->isNotEmpty())
                                            <div class="flex flex-wrap items-center gap-1.5 pt-1">
                                                @foreach($post->tags as $index => $tag)
                                                    <a
                                                        href="{{ route('community.index', ['tag' => $tag->slug]) }}"
                                                        x-show="expandedTags || {{ $index }} < 5"
                                                        class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap"
                                                    >
                                                        #{{ $tag->name }}
                                                    </a>
                                                @endforeach

                                                @if($post->tags->count() > 5)
                                                    <button
                                                        type="button"
                                                        @click="expandedTags = !expandedTags"
                                                        class="text-[11px] font-bold text-amber-600 hover:underline px-2 py-0.5 rounded focus:outline-none cursor-pointer"
                                                    >
                                                        <span x-text="expandedTags ? 'Show less' : '+{{ $post->tags->count() - 5 }} more'"></span>
                                                    </button>
                                                @endif
                                            </div>
                                        @endif

                                        {{-- ACTION BAR --}}
                                        <div class="flex items-center justify-between pt-3 border-t border-slate-100 text-xs font-semibold text-slate-500">
                                            <div class="flex items-center gap-5">
                                                <button
                                                    type="button"
                                                    @click="toggleLike()"
                                                    class="flex items-center gap-1.5 transition cursor-pointer"
                                                    :class="liked ? 'text-red-500' : 'hover:text-red-500'"
                                                >
                                                    <svg
                                                        class="w-4 h-4"
                                                        :fill="liked ? 'currentColor' : 'none'"
                                                        stroke="currentColor"
                                                        stroke-width="2"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                                                        ></path>
                                                    </svg>
                                                    <span x-text="likesCount"></span>
                                                </button>

                                                <button
                                                    type="button"
                                                    @click="showAllComments = !showAllComments"
                                                    class="flex items-center gap-1.5 hover:text-blue-500 transition cursor-pointer"
                                                >
                                                    <svg
                                                        class="w-4 h-4"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        stroke-width="2"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                                                        ></path>
                                                    </svg>
                                                    <span x-text="commentsCount"></span>
                                                </button>

                                                <button
                                                    type="button"
                                                    @click="sharePost()"
                                                    class="flex items-center gap-1.5 transition cursor-pointer"
                                                    :class="copied ? 'text-emerald-600' : 'hover:text-emerald-500'"
                                                >
                                                    <svg
                                                        x-show="!copied"
                                                        class="w-4 h-4"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        stroke-width="2"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"
                                                        ></path>
                                                    </svg>

                                                    <svg
                                                        x-show="copied"
                                                        class="w-4 h-4"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        stroke-width="2.5"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            d="M5 13l4 4L19 7"
                                                        ></path>
                                                    </svg>
                                                    <span x-text="copied ? 'Copied!' : 'Share'"></span>
                                                </button>
                                            </div>
                                        </div>

                                        {{-- COMMENTS SECTION --}}
                                        <div
                                            class="pt-3 border-t border-slate-100 space-y-3"
                                            x-show="showAllComments"
                                            x-cloak
                                        >
                                            <div class="flex gap-2">
                                                <input
                                                    type="text"
                                                    x-model="newCommentText"
                                                    @keydown.enter="submitComment()"
                                                    placeholder="Write a comment..."
                                                    class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400"
                                                >

                                                <button
                                                    type="button"
                                                    @click="submitComment()"
                                                    class="px-3 py-2 bg-[#0b1329] text-white rounded-xl text-xs font-semibold hover:bg-slate-800 transition cursor-pointer"
                                                >
                                                    Post
                                                </button>
                                            </div>

                                            <div class="space-y-2.5 pt-1">
                                                <template x-for="comment in comments" :key="comment.id">
                                                    <div class="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100 relative group">
                                                        {{-- COMMENT USER AVATAR --}}
                                                        <img
                                                            :src="comment.user.avatar"
                                                            class="w-7 h-7 rounded-full object-cover shrink-0"
                                                        >

                                                        <div class="min-w-0 flex-1">
                                                            <div class="flex items-center justify-between">
                                                                <span
                                                                    class="font-bold text-slate-900 text-xs"
                                                                    x-text="comment.user.name"
                                                                ></span>

                                                                <div class="flex items-center gap-2">
                                                                    <span
                                                                        class="text-[10px] text-slate-400"
                                                                        x-text="comment.created_at_human"
                                                                    ></span>

                                                                    {{-- 3 DOTS FOR COMMENT EDIT/DELETE --}}
                                                                    @auth
                                                                        <div class="relative" x-data="{ openCommentMenu: false }">
                                                                            <button 
                                                                                type="button" 
                                                                                @click="openCommentMenu = !openCommentMenu"
                                                                                class="p-1 text-slate-400 hover:text-slate-600 rounded transition cursor-pointer"
                                                                                x-show="comment.user_id === {{ auth()->id() }} || '{{ auth()->user()->role ?? '' }}' === 'admin'"
                                                                            >
                                                                                <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                                                                                    <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/>
                                                                                </svg>
                                                                            </button>

                                                                            <div 
                                                                                x-show="openCommentMenu" 
                                                                                @click.away="openCommentMenu = false"
                                                                                x-transition.origin.top.right
                                                                                class="absolute right-0 mt-1 w-28 bg-white border border-slate-200 rounded-lg shadow-md py-1 z-30"
                                                                                style="display: none;"
                                                                            >
                                                                                <button 
                                                                                    type="button"
                                                                                    @click="startEditComment(comment); openCommentMenu = false;"
                                                                                    class="w-full text-left px-3 py-1.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-1.5 cursor-pointer"
                                                                                >
                                                                                    Edit
                                                                                </button>
                                                                                <button 
                                                                                    type="button"
                                                                                    @click="confirmDeleteComment(comment.id); openCommentMenu = false;"
                                                                                    class="w-full text-left px-3 py-1.5 text-[11px] font-semibold text-red-600 hover:bg-red-50 flex items-center gap-1.5 cursor-pointer"
                                                                                >
                                                                                    Delete
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    @endauth
                                                                </div>
                                                            </div>

                                                            {{-- NORMAL VIEW OR INLINE EDIT FORM --}}
                                                            <template x-if="editingCommentId !== comment.id">
                                                                <p
                                                                    class="text-xs text-slate-700 mt-0.5 leading-relaxed"
                                                                    x-text="comment.content"
                                                                ></p>
                                                            </template>

                                                            <template x-if="editingCommentId === comment.id">
                                                                <div class="mt-2 space-y-2">
                                                                    <textarea
                                                                        x-model="editCommentText"
                                                                        rows="2"
                                                                        class="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400"
                                                                    ></textarea>
                                                                    <div class="flex items-center gap-2">
                                                                        <button
                                                                            type="button"
                                                                            @click="updateComment(comment.id)"
                                                                            class="px-2.5 py-1 bg-amber-400 hover:bg-amber-500 text-slate-950 rounded-md text-[11px] font-bold transition cursor-pointer"
                                                                        >
                                                                            Save
                                                                        </button>
                                                                        <button
                                                                            type="button"
                                                                            @click="cancelEditComment()"
                                                                            class="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-md text-[11px] font-semibold transition cursor-pointer"
                                                                        >
                                                                            Cancel
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </template>

                                                        </div>
                                                    </div>
                                                </template>
                                            </div>

                                            <div
                                                class="text-center pt-1"
                                                x-show="comments.length < commentsCount"
                                            >
                                                <button
                                                    type="button"
                                                    @click="loadMoreComments()"
                                                    class="text-xs font-semibold text-amber-600 hover:underline cursor-pointer"
                                                    x-text="loadingMore ? 'Loading...' : 'See more comments'"
                                                ></button>
                                            </div>
                                        </div>

                                        {{-- CUSTOM DELETE CONFIRMATION MODAL --}}
                                        <div
                                            x-show="showDeleteModal"
                                            class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4"
                                            style="display: none;"
                                            x-cloak
                                        >
                                            <div 
                                                @click.away="showDeleteModal = false"
                                                class="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-100 space-y-4"
                                            >
                                                <div class="w-10 h-10 rounded-full bg-red-50 text-red-500 flex items-center justify-center mx-auto">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                    </svg>
                                                </div>

                                                <div class="text-center space-y-1">
                                                    <h3 class="text-sm font-bold text-slate-900">Delete Comment</h3>
                                                    <p class="text-xs text-slate-500">
                                                        Are you sure you want to delete this comment? This action cannot be undone.
                                                    </p>
                                                </div>

                                                <div class="flex items-center gap-2.5 pt-2">
                                                    <button
                                                        type="button"
                                                        @click="showDeleteModal = false"
                                                        class="flex-1 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition cursor-pointer"
                                                    >
                                                        Cancel
                                                    </button>
                                                    <button
                                                        type="button"
                                                        @click="executeDeleteComment()"
                                                        class="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-semibold transition cursor-pointer"
                                                    >
                                                        Delete
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                @empty
                                    <div class="py-16 text-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                                        <div class="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                            <svg
                                                class="w-5 h-5 text-slate-400"
                                                fill="none"
                                                stroke="currentColor"
                                                stroke-width="2"
                                                viewBox="0 0 24 24"
                                            >
                                                <path
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h6l2 2h6a2 2 0 012 2v10a2 2 0 01-2 2z"
                                                />
                                            </svg>
                                        </div>
                                        <p class="text-sm font-semibold text-slate-700">No posts yet</p>
                                        <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                                            When this user creates their first post, it will appear here.
                                        </p>
                                    </div>
                                @endforelse

                                @if(method_exists($posts, 'hasPages') && $posts->hasPages())
                                    <div class="mt-6">
                                        {{ $posts->appends(['tab' => 'posts'])->links() }}
                                    </div>
                                @endif

                            @elseif($activeTab === 'comments')
                                @forelse($comments ?? [] as $comment)
                                    <div class="p-4 rounded-xl border border-slate-200/70 bg-white space-y-2 shadow-sm">
                                        <div class="flex items-center justify-between text-xs text-slate-400">
                                            <span class="font-semibold text-slate-700">Commented on post</span>
                                            <span>{{ $comment->created_at?->diffForHumans() }}</span>
                                        </div>
                                        <p class="text-xs sm:text-sm text-slate-700 break-words leading-relaxed">
                                            {{ $comment->content ?? $comment->body ?? '' }}
                                        </p>
                                    </div>
                                @empty
                                    <div class="py-16 text-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                                        <div class="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                            <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                            </svg>
                                        </div>
                                        <p class="text-sm font-semibold text-slate-700">No comments yet</p>
                                        <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                                            Comments made by this user will show up here.
                                        </p>
                                    </div>
                                @endforelse

                                @if(isset($comments) && method_exists($comments, 'hasPages') && $comments->hasPages())
                                    <div class="mt-6">
                                        {{ $comments->appends(['tab' => 'comments'])->links() }}
                                    </div>
                                @endif

                            @elseif($activeTab === 'activity')
                                @forelse($activities ?? [] as $activity)
                                    <div class="flex items-start gap-3 p-4 rounded-xl border border-slate-200/70 bg-white shadow-sm">
                                        <div class="w-2 h-2 rounded-full bg-amber-500 mt-2 shrink-0"></div>
                                        <div class="min-w-0 flex-1">
                                            <p class="text-xs sm:text-sm text-slate-700 break-words">
                                                {{ $activity->description ?? $activity->action ?? 'Performed an activity' }}
                                            </p>
                                            <span class="text-[10px] text-slate-400 mt-1 block">
                                                {{ $activity->created_at?->diffForHumans() }}
                                            </span>
                                        </div>
                                    </div>
                                @empty
                                    <div class="py-16 text-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                                        <div class="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                            <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                        </div>
                                        <p class="text-sm font-semibold text-slate-700">No activity yet</p>
                                        <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                                            Recent user activities and events will appear here.
                                        </p>
                                    </div>
                                @endforelse

                                @if(isset($activities) && method_exists($activities, 'hasPages') && $activities->hasPages())
                                    <div class="mt-6">
                                        {{ $activities->appends(['tab' => 'activity'])->links() }}
                                    </div>
                                @endif

                            @elseif($activeTab === 'followers')
                                <div class="bg-slate-50/60 rounded-2xl border border-slate-200/70 p-4 sm:p-5">
                                    <div class="flex items-center justify-between gap-3 mb-4">
                                        <div>
                                            <h2 class="text-sm font-extrabold text-slate-900">Followers</h2>
                                            <p class="text-xs text-slate-400 mt-0.5">People who follow {{ $user->name }}.</p>
                                        </div>
                                        <span class="text-xs font-bold text-amber-600 bg-amber-50 border border-amber-100 px-2.5 py-1 rounded-lg">
                                            {{ number_format($followersCount) }} total
                                        </span>
                                    </div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        @forelse($followers as $follow)
                                            @php
                                                $person = $follow->follower;
                                                $personProfile = $person?->profile;
                                                $personAvatar = $personProfile?->avatar
                                                    ? asset('storage/' . $personProfile->avatar)
                                                    : 'https://ui-avatars.com/api/?name=' . urlencode($person?->name ?? 'User') . '&background=0c1b33&color=fff&size=100';
                                                $personUsername = $personProfile?->username ?? 
                                                    (isset($person->username) ? $person->username : null);
                                            @endphp

                                            @if($person)
                                                <div
                                                    x-data="{ removing: false, removed: false }"
                                                    x-show="!removed"
                                                    x-transition
                                                    class="flex items-center gap-3 p-3 rounded-xl bg-white border border-slate-200/70 hover:border-amber-200 hover:shadow-sm transition min-w-0"
                                                >
                                                    <a
                                                        href="{{ route('community.profile', $personUsername ?: $person->id) }}"
                                                        class="flex items-center gap-3 min-w-0 flex-1"
                                                    >
                                                        <img
                                                            src="{{ $personAvatar }}"
                                                            alt="{{ $person->name }}"
                                                            class="w-11 h-11 rounded-full object-cover border border-slate-100 shrink-0"
                                                        >

                                                        <div class="min-w-0 flex-1">
                                                            <span class="text-sm font-bold text-slate-900 truncate block">
                                                                {{ $person->name }}
                                                            </span>

                                                            @if($personUsername)
                                                                <span class="text-[11px] text-slate-400 truncate block">
                                                                    {{ '@' . $personUsername }}
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </a>

                                                    <button
                                                        type="button"
                                                        @click.stop="
                                                            if (removing) return;
                                                            removing = true;

                                                            fetch('{{ url('/community/followers/' . $person->id . '/remove') }}', {
                                                                method: 'POST',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                                    'Accept': 'application/json'
                                                                }
                                                            })
                                                            .then(async response => {
                                                                const data = await response.json();

                                                                if (!response.ok) {
                                                                    throw new Error(data.message || 'Unable to remove follower.');
                                                                }

                                                                return data;
                                                            })
                                                            .then(data => {
                                                                if (data.success) {
                                                                    removed = true;
                                                                }
                                                            })
                                                            .catch(error => {
                                                                console.error(error);
                                                            })
                                                            .finally(() => {
                                                                removing = false;
                                                            });
                                                        "
                                                        :disabled="removing"
                                                        class="shrink-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 bg-red-50 text-red-600 text-[10px] font-bold hover:bg-red-100 hover:border-red-300 transition disabled:opacity-50 disabled:cursor-not-allowed"
                                                    >
                                                        <svg
                                                            x-show="!removing"
                                                            class="w-3 h-3"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2.2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <path
                                                                stroke-linecap="round"
                                                                stroke-linejoin="round"
                                                                d="M6 12h12"
                                                            />
                                                        </svg>

                                                        <svg
                                                            x-show="removing"
                                                            x-cloak
                                                            class="w-3 h-3 animate-spin"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <circle cx="12" cy="12" r="9" class="opacity-25"></circle>
                                                            <path d="M21 12a9 9 0 01-9 9"></path>
                                                        </svg>

                                                        <span x-text="removing ? 'Removing...' : 'Remove'"></span>
                                                    </button>
                                                </div>
                                            @endif
                                        @empty
                                            <div class="sm:col-span-2 py-14 text-center bg-white rounded-xl border border-dashed border-slate-200">
                                                <div class="w-11 h-11 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                                    <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5V18a4 4 0 00-4-4h-1m-4 6H3v-2a4 4 0 014-4h3m3-8a4 4 0 11-8 0 4 4 0 018 0zm6 3a3 3 0 11-6 0" />
                                                    </svg>
                                                </div>
                                                <p class="text-sm font-semibold text-slate-700">No followers yet</p>
                                                <p class="text-xs text-slate-400 mt-1">People who follow this profile will appear here.</p>
                                            </div>
                                        @endforelse
                                    </div>

                                    @if(method_exists($followers, 'hasPages') && $followers->hasPages())
                                        <div class="mt-5">
                                            {{ $followers->appends(['tab' => 'followers'])->links() }}
                                        </div>
                                    @endif
                                </div>

                            @elseif($activeTab === 'following')
                                <div class="bg-slate-50/60 rounded-2xl border border-slate-200/70 p-4 sm:p-5">
                                    <div class="flex items-center justify-between gap-3 mb-4">
                                        <div>
                                            <h2 class="text-sm font-extrabold text-slate-900">Following</h2>
                                            <p class="text-xs text-slate-400 mt-0.5">People {{ $user->name }} follows.</p>
                                        </div>
                                        <span class="text-xs font-bold text-amber-600 bg-amber-50 border border-amber-100 px-2.5 py-1 rounded-lg">
                                            {{ number_format($followingCount) }} total
                                        </span>
                                    </div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        @forelse($following as $follow)
                                            @php
                                                $person = $follow->following;
                                                $personProfile = $person?->profile;
                                                $personAvatar = $personProfile?->avatar
                                                    ? asset('storage/' . $personProfile->avatar)
                                                    : 'https://ui-avatars.com/api/?name=' . urlencode($person?->name ?? 'User') . '&background=0c1b33&color=fff&size=100';
                                                $personUsername = $personProfile?->username ?? 
                                                    (isset($person->username) ? $person->username : null);
                                            @endphp

                                            @if($person)
                                                <div
                                                    x-data="{ unfollowing: false, removed: false }"
                                                    x-show="!removed"
                                                    x-transition
                                                    class="flex items-center gap-3 p-3 rounded-xl bg-white border border-slate-200/70 hover:border-amber-200 hover:shadow-sm transition min-w-0"
                                                >
                                                    <a
                                                        href="{{ route('community.profile', $personUsername ?: $person->id) }}"
                                                        class="flex items-center gap-3 min-w-0 flex-1"
                                                    >
                                                        <img
                                                            src="{{ $personAvatar }}"
                                                            alt="{{ $person->name }}"
                                                            class="w-11 h-11 rounded-full object-cover border border-slate-100 shrink-0"
                                                        >

                                                        <div class="min-w-0 flex-1">
                                                            <span class="text-sm font-bold text-slate-900 truncate block">
                                                                {{ $person->name }}
                                                            </span>

                                                            @if($personUsername)
                                                                <span class="text-[11px] text-slate-400 truncate block">
                                                                    {{ '@' . $personUsername }}
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </a>

                                                    <button
                                                        type="button"
                                                        @click.stop="
                                                            if (unfollowing) return;
                                                            unfollowing = true;

                                                            fetch('{{ route('users.follow.toggle', $person) }}', {
                                                                method: 'POST',
                                                                headers: {
                                                                    'Content-Type': 'application/json',
                                                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                                                    'Accept': 'application/json'
                                                                }
                                                            })
                                                            .then(async response => {
                                                                const data = await response.json();

                                                                if (!response.ok) {
                                                                    throw new Error(data.message || 'Unable to unfollow user.');
                                                                }

                                                                return data;
                                                            })
                                                            .then(data => {
                                                                if (data.success && data.data && data.data.following === false) {
                                                                    removed = true;

                                                                    window.dispatchEvent(
                                                                        new CustomEvent('following-updated', {
                                                                            detail: {
                                                                                delta: -1,
                                                                                userId: {{ (int) $person->id }}
                                                                            }
                                                                        })
                                                                    );
                                                                }
                                                            })
                                                            .catch(error => {
                                                                console.error(error);
                                                            })
                                                            .finally(() => {
                                                                unfollowing = false;
                                                            });
                                                        "
                                                        :disabled="unfollowing"
                                                        class="shrink-0 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-600 text-[10px] font-bold hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition disabled:opacity-50 disabled:cursor-not-allowed"
                                                    >
                                                        <svg
                                                            x-show="!unfollowing"
                                                            class="w-3 h-3"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <path
                                                                stroke-linecap="round"
                                                                stroke-linejoin="round"
                                                                d="M6 12h12"
                                                            />
                                                        </svg>

                                                        <svg
                                                            x-show="unfollowing"
                                                            x-cloak
                                                            class="w-3 h-3 animate-spin"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <circle cx="12" cy="12" r="9" class="opacity-25"></circle>
                                                            <path d="M21 12a9 9 0 01-9 9"></path>
                                                        </svg>

                                                        <span x-text="unfollowing ? 'Unfollowing...' : 'Unfollow'"></span>
                                                    </button>
                                                </div>
                                            @endif
                                        @empty
                                            <div class="sm:col-span-2 py-14 text-center bg-white rounded-xl border border-dashed border-slate-200">
                                                <div class="w-11 h-11 mx-auto rounded-full bg-slate-100 flex items-center justify-center mb-3">
                                                    <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-6-6h12" />
                                                    </svg>
                                                </div>
                                                <p class="text-sm font-semibold text-slate-700">Not following anyone yet</p>
                                                <p class="text-xs text-slate-400 mt-1">People this user follows will appear here.</p>
                                            </div>
                                        @endforelse
                                    </div>

                                    @if(method_exists($following, 'hasPages') && $following->hasPages())
                                        <div class="mt-5">
                                            {{ $following->appends(['tab' => 'following'])->links() }}
                                        </div>
                                    @endif
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    {{-- GLOBAL LOGIN PROMPT MODAL --}}
    <div
        x-data="{ globalLoginModal: false }"
        @open-login-modal.window="globalLoginModal = true"
        x-show="globalLoginModal"
        class="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4"
        style="display: none;"
        x-cloak
    >
    </div>
</div>