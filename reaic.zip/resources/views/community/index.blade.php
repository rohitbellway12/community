@props([
    'title' => 'Community | REIAC',
    'active' => 'home',
    'user' => auth()->user(),
    'sidebar' => true,
    'rightbar' => true,
    'posts' => collect(),
    'notificationsCount' => 0,
    'trendingTopics' => collect(),
    'categories' => collect(),
    'tags' => collect(),
])

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="bg-[#f3f4f6]" x-data="{ mobileMenuOpen: false }">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body
    class="min-h-screen bg-[#f3f4f6] font-sans text-slate-800 antialiased selection:bg-amber-500 selection:text-white pb-20 lg:pb-0">



    <x-community.topbar :notifications-count="$notificationsCount ?? 0" />

    {{-- MOBILE SIDEBAR OVERLAY --}}
    <div x-show="mobileMenuOpen" class="fixed inset-0 z-50 lg:hidden flex" style="display: none;">

        <div @click="mobileMenuOpen = false" x-show="mobileMenuOpen" x-transition.opacity
            class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"></div>

        <div x-show="mobileMenuOpen" x-transition:enter="transition ease-out duration-300 transform"
            x-transition:enter-start="-translate-x-full" x-transition:enter-end="translate-x-0"
            x-transition:leave="transition ease-in duration-200 transform" x-transition:leave-start="translate-x-0"
            x-transition:leave-end="-translate-x-full"
            class="relative w-80 max-w-[85%] bg-white h-full shadow-2xl flex flex-col z-10 overflow-y-auto">

            @auth
                @php
                    $mobileProfile = $user?->profile;

                    $mobileAvatar = $mobileProfile?->avatar
                        ? asset('storage/' . $mobileProfile->avatar)
                        : 'https://ui-avatars.com/api/?name=' .
                            urlencode($user?->name ?? 'User') .
                            '&background=0c1b33&color=fff';
                @endphp

                <div class="p-4 border-b border-slate-100 flex items-center gap-3">
                    <img src="{{ $mobileAvatar }}" alt="{{ $user?->name }}" class="w-10 h-10 rounded-full object-cover">

                    <div>
                        <div class="font-bold text-slate-900 text-sm">
                            {{ $user?->name }}
                        </div>

                        <a href="{{ route('community.profile.me') }}"
                            class="text-xs text-amber-600 font-semibold hover:underline">
                            View Profile
                        </a>
                    </div>
                </div>
            @endauth

            <nav class="p-3 space-y-1 text-sm font-medium text-slate-600">

                <a href="{{ route('community.index') }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl bg-slate-100 text-slate-900 font-semibold">
                    <svg class="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" stroke-width="2.5"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 011-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 011 1m-6 0h6">
                        </path>
                    </svg>
                    Community Home
                </a>

                <a href="{{ route('community.index') }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50">
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z">
                        </path>
                    </svg>
                    All Discussions
                </a>

                <a href="{{ route('community.index', ['category' => 'general']) }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50">
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16m-7 6h7"></path>
                    </svg>
                    General
                </a>

                <a href="{{ route('community.index', ['category' => 'ask-a-solution']) }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50">
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                        </path>
                    </svg>
                    Ask a Solution
                </a>

                <a href="{{ route('community.index', ['category' => 'jobs-info']) }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50">
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z">
                        </path>
                    </svg>
                    Jobs Info
                </a>

                <div class="border-t border-slate-100 my-2"></div>

                <a href="{{ route('community.activity') }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50">
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    My Activity
                </a>

                <a href="{{ route('community.saved') }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50">
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"></path>
                    </svg>
                    Saved Posts
                </a>

                <div class="border-t border-slate-100 my-2"></div>

                <a href="{{ route('community.profile.edit') }}"
                    class="flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50">
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31.826-2.37-2.37a1.724 1.724 0 001.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z">
                        </path>
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z">
                        </path>
                    </svg>
                    Settings
                </a>

                <form method="POST" action="{{ route('logout') }}">
                    @csrf

                    <button type="submit"
                        class="w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-slate-50 text-red-600 text-left">
                        <svg class="w-4 h-4 text-red-500" fill="none" stroke="currentColor" stroke-width="2"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1">
                            </path>
                        </svg>
                        Logout
                    </button>
                </form>

            </nav>
        </div>
    </div>

  {{-- MAIN CONTENT GRID --}}
    <main
        class="max-w-[1520px] mx-auto px-4 lg:px-6 py-6 grid grid-cols-1 lg:grid-cols-[280px_1fr_330px] xl:grid-cols-[300px_minmax(0,1fr)_360px] gap-6 items-start">

        <x-community.sidebar />

        {{-- CENTER FEED --}}
        <section class="space-y-5 min-w-0">

            <div class="bg-white p-5 lg:p-6 rounded-2xl shadow-sm border border-slate-200/70">

                <h1 class="text-xl lg:text-2xl font-extrabold text-slate-900 tracking-tight">
                    Community
                </h1>

                <p class="text-xs text-slate-500 mt-1">
                    Ask questions. Share knowledge. Find solutions.
                </p>

                <div class="grid grid-cols-2 lg:grid-cols-4 gap-2.5 lg:gap-3 mt-4">

                    <a href="{{ route('community.index') }}"
                        class="p-3 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-2.5 cursor-pointer hover:bg-slate-100 transition">
                        <div
                            class="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10">
                                </path>
                            </svg>
                        </div>

                        <div class="min-w-0">
                            <div class="font-bold text-slate-900 text-xs truncate">
                                All
                            </div>
                            <div class="text-[10px] text-slate-500 truncate">
                                All Discussions
                            </div>
                        </div>
                    </a>

                    <a href="{{ route('community.index', ['category' => 'general']) }}"
                        class="p-3 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-2.5 cursor-pointer hover:bg-slate-100 transition">
                        <div
                            class="w-8 h-8 rounded-lg bg-orange-50 text-orange-500 flex items-center justify-center shrink-0">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253">
                                </path>
                            </svg>
                        </div>

                        <div class="min-w-0">
                            <div class="font-bold text-slate-900 text-xs truncate">
                                General
                            </div>
                            <div class="text-[10px] text-slate-500 truncate">
                                Discuss anything
                            </div>
                        </div>
                    </a>

                    <a href="{{ route('community.index', ['category' => 'ask-a-solution']) }}"
                        class="p-3 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-2.5 cursor-pointer hover:bg-slate-100 transition">
                        <div
                            class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z">
                                </path>
                            </svg>
                        </div>

                        <div class="min-w-0">
                            <div class="font-bold text-slate-900 text-xs truncate">
                                Ask a Solution
                            </div>
                            <div class="text-[10px] text-slate-500 truncate">
                                Get solutions
                            </div>
                        </div>
                    </a>

                    <a href="{{ route('community.index', ['category' => 'jobs-info']) }}"
                        class="p-3 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center gap-2.5 cursor-pointer hover:bg-slate-100 transition">
                        <div
                            class="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z">
                                </path>
                            </svg>
                        </div>

                        <div class="min-w-0">
                            <div class="font-bold text-slate-900 text-xs truncate">
                                Jobs Info
                            </div>
                            <div class="text-[10px] text-slate-500 truncate">
                                Job & Career Info
                            </div>
                        </div>
                    </a>

                </div>

                {{-- SEARCH --}}
                <form method="GET" action="{{ route('community.index') }}"
                    class="mt-4 relative flex items-center">
                    @if (request('category'))
                        <input type="hidden" name="category" value="{{ request('category') }}">
                    @endif

                    @if (request('tag'))
                        <input type="hidden" name="tag" value="{{ request('tag') }}">
                    @endif

                    @if (request('sort'))
                        <input type="hidden" name="sort" value="{{ request('sort') }}">
                    @endif

                    <span class="absolute left-3.5 text-slate-400">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </span>

                    <input type="text" name="search" value="{{ request('search') }}"
                        placeholder="Search discussions, users, topics..."
                        class="w-full bg-slate-50 border border-slate-200/80 rounded-xl pl-10 pr-20 py-2.5 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-400">

                    <button type="submit"
                        class="absolute right-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1 shadow-xs">
                        Search
                    </button>
                </form>

                {{-- SORT --}}
                <div class="flex items-center justify-between mt-4 pt-3.5 border-t border-slate-100 text-xs">

                    <div class="flex items-center gap-5 font-semibold text-slate-500">

                        <a href="{{ request()->fullUrlWithQuery(['sort' => 'latest']) }}"
                            class="{{ request('sort', 'latest') === 'latest' ? 'text-slate-900 border-b-2 border-amber-400 pb-1' : 'hover:text-slate-900 transition' }}">
                            Latest
                        </a>

                        <a href="{{ request()->fullUrlWithQuery(['sort' => 'trending']) }}"
                            class="{{ request('sort') === 'trending' ? 'text-slate-900 border-b-2 border-amber-400 pb-1' : 'hover:text-slate-900 transition' }}">
                            Trending
                        </a>

                        <a href="{{ request()->fullUrlWithQuery(['sort' => 'most_discussed']) }}"
                            class="{{ request('sort') === 'most_discussed' ? 'text-slate-900 border-b-2 border-amber-400 pb-1' : 'hover:text-slate-900 transition' }}">
                            Most Discussed
                        </a>

                    </div>

                </div>
            </div>

            {{-- POSTS --}}
            @php
                $postCollection = method_exists($posts, 'getCollection') ? $posts->getCollection() : collect($posts);

                $authorIds = $postCollection->pluck('user_id')->filter()->unique()->values();

                $followingAuthorIds =
                    auth()->check() && $authorIds->isNotEmpty()
                        ? \App\Models\Follow::where('follower_id', auth()->id())
                            ->whereIn('following_id', $authorIds)
                            ->pluck('following_id')
                            ->map(fn($id) => (int) $id)
                            ->toArray()
                        : [];
            @endphp

            @forelse($posts as $post)

                @php
                    $author = $post->user;
                    $profile = $author?->profile;
                    $isOwnPost = auth()->check() && auth()->id() === $post->user_id;
                    $isFollowingAuthor = auth()->check() && in_array((int) $post->user_id, $followingAuthorIds, true);

                    $authorAvatar = $profile?->avatar
                        ? asset('storage/' . $profile->avatar)
                        : 'https://ui-avatars.com/api/?name=' .
                            urlencode($author?->name ?? 'User') .
                            '&background=0c1b33&color=fff';

                    $authorUsername = $profile?->username;

                    $authorUrl = $authorUsername
                        ? route('community.profile', $authorUsername)
                        : route('community.profile', $author?->id);
                @endphp

                <div class="bg-white p-4 sm:p-5 rounded-2xl shadow-sm border border-slate-200/70 space-y-4 min-w-0 overflow-hidden"
                    @follow-updated.window="
                    if (Number($event.detail.userId) === {{ (int) $post->user_id }}) {
                        following = Boolean($event.detail.following);
                    }
                "
                    x-data="{
                        likesCount: {{ $post->likes_count ?? 0 }},
                        following: {{ $isFollowingAuthor ? 'true' : 'false' }},
                        followLoading: false,
                        liked: {{ $post->likes()->where('user_id', auth()->id())->exists()? 'true': 'false' }},
                        saved: {{ auth()->check() &&$post->savedBy()->where('user_id', auth()->id())->exists()? 'true': 'false' }},
                        copied: false,
                        commentsCount: {{ $post->comments_count ?? 0 }},
                        showAllComments: false,
                        showFullContent: false,
                        showAllTags: false,
                        newCommentText: '',
                        comments: {{ json_encode(
                            $post->comments->map(
                                fn($c) => [
                                    'id' => $c->id,
                                    'content' => $c->content,
                                    'created_at_human' => $c->created_at->diffForHumans(),
                                    'user' => [
                                        'name' => $c->user?->name ?? 'User',
                                        'avatar' => $c->user?->profile?->avatar
                                            ? asset('storage/' . $c->user->profile->avatar)
                                            : 'https://ui-avatars.com/api/?name=' .
                                                urlencode($c->user?->name ?? 'User') .
                                                '&background=0c1b33&color=fff',
                                    ],
                                ],
                            ),
                        ) }},
                        loadingMore: false,
                    
                        toggleFollow() {
                            @guest
                window.dispatchEvent(new CustomEvent('open-login-modal'));
                            return; @endguest
                    
                            @if ($author && !$isOwnPost) if (this.followLoading) {
                                return;
                            }

                            this.followLoading = true;

                            fetch('{{ route('users.follow.toggle', $author) }}', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content'),
                                    'Accept': 'application/json',
                                    'X-Requested-With': 'XMLHttpRequest'
                                }
                            })
                            .then(async response => {
                                if (response.status === 401) {
                                    window.dispatchEvent(new CustomEvent('open-login-modal'));
                                    return null;
                                }

                                if (!response.ok) {
                                    throw new Error('Follow request failed');
                                }

                                return response.json();
                            })
                            .then(data => {
                                if (!data || !data.success || !data.data) {
                                    return;
                                }

                                const following = Boolean(data.data.following);

                                this.following = following;

                                window.dispatchEvent(
                                    new CustomEvent('follow-updated', {
                                        detail: {
                                            userId: {{ (int) $post->user_id }},
                                            following: following
                                        }
                                    })
                                );
                            })
                            .catch(error => {
                                console.error('Follow error:', error);
                            })
                            .finally(() => {
                                this.followLoading = false;
                            }); @endif
                        },
                    
                        toggleLike() {
                            fetch('{{ route('community.posts.like', $post) }}', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content')
                                    }
                                })
                                .then(res => res.json())
                                .then(data => {
                                    if (data.success) {
                                        this.liked = data.liked;
                                        this.likesCount = data.likes_count;
                                    }
                                });
                        },
                    
                        toggleSave() {
                            fetch('{{ route('community.posts.save', $post) }}', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content')
                                    }
                                })
                                .then(res => res.json())
                                .then(data => {
                                    if (data.success) {
                                        this.saved = data.saved;
                                    }
                                });
                        },
                    
                        sharePost() {
                            navigator.clipboard.writeText('{{ route('community.posts.show', $post) }}')
                                .then(() => {
                                    this.copied = true;
                    
                                    setTimeout(() => {
                                        this.copied = false;
                                    }, 2000);
                                });
                        },
                    
                        submitComment() {
                            if (!this.newCommentText.trim()) {
                                return;
                            }
                    
                            fetch('{{ route('community.posts.comment.store', $post) }}', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').getAttribute('content')
                                    },
                                    body: JSON.stringify({
                                        content: this.newCommentText
                                    })
                                })
                                .then(res => res.json())
                                .then(data => {
                                    if (data.success) {
                                        this.comments.unshift(data.comment);
                                        this.commentsCount++;
                                        this.newCommentText = '';
                                    }
                                });
                        },
                    
                        loadMoreComments() {
                            this.loadingMore = true;
                    
                            fetch(`{{ route('community.posts.comments', $post) }}?skip=` + this.comments.length)
                                .then(res => res.json())
                                .then(data => {
                                    this.comments = this.comments.concat(data.comments);
                                    this.loadingMore = false;
                                });
                        }
                    }">

                    {{-- GROUP INFO BADGE & JOIN BUTTON --}}
                    @if ($post->group)
                        @php
                            $group = $post->group;
                            $userMembership = auth()->check() ? $group->users()->where('user_id', auth()->id())->first() : null;
                            $isMember = $userMembership && $userMembership->pivot->status === 'active';
                            $isPending = $userMembership && $userMembership->pivot->status === 'pending';
                            $isRejected = $userMembership && $userMembership->pivot->status === 'rejected';
                        @endphp
                        <div
                            class="flex items-center justify-between bg-slate-50 border border-slate-200/60 px-3 py-2 rounded-xl text-xs">
                            <div class="flex items-center gap-1.5 text-slate-700 font-semibold truncate">
                                <svg class="w-4 h-4 text-slate-400 shrink-0" fill="none" stroke="currentColor"
                                    stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                                </svg>
                                <span>Group:</span>
                                <a href="{{ route('community.groups.show', $group->slug ?? $group->id) }}"
                                    class="text-amber-600 hover:underline truncate">
                                    {{ $group->name }}
                                </a>
                            </div>

                            @auth
                                @if ($isMember)
                                    <span
                                        class="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                                        Member
                                    </span>
                                @elseif ($isPending)
                                    <span
                                        class="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                                        Pending
                                    </span>
                                @else
                                    <form action="{{ route('community.groups.join', $group) }}" method="POST"
                                        class="shrink-0">
                                        
                                        @csrf
                                        <button type="submit"
                                            class="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-[10px] font-bold transition shadow-xs">
                                            {{ $isRejected ? 'Send Again' : 'Join Group' }}
                                        </button>
                                    </form>
                                @endif
                            @else
                                <button type="button" @click="window.dispatchEvent(new CustomEvent('open-login-modal'))"
                                    class="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-[10px] font-bold transition shadow-xs">
                                    Join Group
                                </button>
                            @endauth
                        </div>
                    @endif

                    {{-- POST HEADER --}}
                    <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 min-w-0">
                        <div class="flex items-start gap-3 min-w-0 flex-1">
                            <img src="{{ $authorAvatar }}" alt="{{ $author?->name ?? 'User' }}"
                                class="w-9 h-9 rounded-full object-cover shrink-0">
                            <div class="min-w-0 flex-1">
                                <div class="flex items-center gap-2 min-w-0">
                                    <div class="font-bold text-slate-900 text-xs truncate max-w-full">
                                        @if ($author)
                                            <a href="{{ $authorUrl }}"
                                                class="hover:underline">{{ $author->name }}</a>
                                        @else
                                            User
                                        @endif
                                    </div>

                                    @auth
                                        @if ($author && !$isOwnPost)
                                            <button type="button" @click="toggleFollow()" :disabled="followLoading"
                                                class="shrink-0 inline-flex items-center justify-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed"
                                                :class="following
                                                    ?
                                                    'bg-slate-100 text-slate-600 border-slate-200 hover:bg-red-50 hover:text-red-600 hover:border-red-200' :
                                                    'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-400 hover:text-slate-900 hover:border-amber-400'">
                                                <svg x-show="!following && !followLoading" class="w-3 h-3" fill="none"
                                                    stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M12 5v14M5 12h14" />
                                                </svg>

                                                <svg x-show="following && !followLoading" x-cloak class="w-3 h-3"
                                                    fill="none" stroke="currentColor" stroke-width="2.5"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M5 13l4 4L19 7" />
                                                </svg>

                                                <svg x-show="followLoading" x-cloak class="w-3 h-3 animate-spin"
                                                    fill="none" stroke="currentColor" stroke-width="2"
                                                    viewBox="0 0 24 24">
                                                    <circle cx="12" cy="12" r="9" class="opacity-25">
                                                    </circle>
                                                    <path d="M21 12a9 9 0 01-9 9"></path>
                                                </svg>

                                                <span
                                                    x-text="followLoading ? '...' : (following ? 'Following' : 'Follow')"></span>
                                            </button>
                                        @endif
                                    @endauth
                                </div>
                                <div class="mt-0.5 flex items-center gap-1 text-[11px] text-slate-500 min-w-0">
                                    @if ($authorUsername)
                                        <a href="{{ $authorUrl }}"
                                            class="truncate max-w-[140px] sm:max-w-[220px] hover:text-slate-700 hover:underline">{{ '@' . $authorUsername }}</a>
                                        <span class="shrink-0">•</span>
                                    @endif
                                    <span
                                        class="shrink-0 whitespace-nowrap">{{ $post->created_at->diffForHumans() }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="flex items-center gap-2 flex-wrap sm:justify-end shrink-0">
                            @if ($post->category)
                                <span
                                    class="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2.5 py-1 rounded-md tracking-wide whitespace-nowrap">{{ strtoupper($post->category->name) }}</span>
                            @endif
                            @if ($post->is_solved)
                                <span
                                    class="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-1 rounded-md flex items-center gap-1 whitespace-nowrap">
                                    <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="3"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7">
                                        </path>
                                    </svg>
                                    Solved
                                </span>
                            @endif
                        </div>
                    </div>

                    {{-- TITLE --}}
                    <h3 class="font-bold text-slate-900 text-sm leading-snug">
                        <a href="{{ route('community.posts.show', $post) }}" class="hover:underline">
                            {{ $post->title }}
                        </a>
                    </h3>

                    {{-- CONTENT --}}
                    @php
                        $postContentLength = mb_strlen(strip_tags($post->content ?? ''));
                    @endphp
                    <div class="text-xs text-slate-600 leading-relaxed break-words">
                        <p :class="showFullContent ? '' : 'line-clamp-4'">{{ $post->content }}</p>
                        @if ($postContentLength > 280)
                            <button type="button" @click="showFullContent = !showFullContent"
                                class="mt-1.5 text-[11px] font-bold text-slate-900 hover:text-amber-600 transition"
                                x-text="showFullContent ? 'Show less' : 'Read more'"></button>
                        @endif
                    </div>

                    {{-- MEDIA --}}
                    @if ($post->media && $post->media->isNotEmpty())
                        <div class="space-y-3 pt-1">

                            @foreach ($post->media as $mediaItem)
                                <div
                                    class="w-full max-h-[550px] bg-slate-900 rounded-xl overflow-hidden border border-slate-200 flex items-center justify-center">

                                    @if (str_starts_with($mediaItem->file_type ?? '', 'video'))
                                        <video src="{{ asset('storage/' . $mediaItem->file_path) }}"
                                            class="w-full max-h-[550px] object-contain" controls
                                            preload="metadata"></video>
                                    @else
                                        <img src="{{ asset('storage/' . $mediaItem->file_path) }}"
                                            alt="{{ $post->title }}"
                                            class="w-full h-auto max-h-[550px] object-contain">
                                    @endif

                                </div>
                            @endforeach

                        </div>
                    @endif

                    {{-- TAGS --}}
                    @if ($post->tags && $post->tags->isNotEmpty())
                        @php
                            $visibleTags = $post->tags->take(3);
                            $remainingTags = max($post->tags->count() - 3, 0);
                        @endphp
                        <div class="flex flex-wrap items-center gap-2 pt-1 min-w-0">
                            @foreach ($visibleTags as $tag)
                                <a href="{{ route('community.index', ['tag' => $tag->slug]) }}"
                                    class="max-w-full truncate bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium px-2.5 py-1 rounded-lg transition-colors">#{{ $tag->name }}</a>
                            @endforeach
                            @if ($remainingTags > 0)
                                <template x-if="!showAllTags">
                                    <button type="button" @click="showAllTags = true"
                                        class="text-[11px] font-bold text-slate-500 hover:text-amber-600 transition whitespace-nowrap">+{{ $remainingTags }}
                                        more</button>
                                </template>
                                <template x-if="showAllTags">
                                    <div class="flex flex-wrap items-center gap-2 w-full">
                                        @foreach ($post->tags->slice(3) as $tag)
                                            <a href="{{ route('community.index', ['tag' => $tag->slug]) }}"
                                                class="max-w-full truncate bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium px-2.5 py-1 rounded-lg transition-colors">#{{ $tag->name }}</a>
                                        @endforeach
                                        <button type="button" @click="showAllTags = false"
                                            class="text-[11px] font-bold text-slate-500 hover:text-amber-600 transition whitespace-nowrap">Show
                                            less</button>
                                    </div>
                                </template>
                            @endif
                        </div>
                    @endif

                    {{-- ACTION BAR --}}
                    <div
                        class="flex items-center justify-between pt-3 border-t border-slate-100 text-xs font-semibold text-slate-500">

                        <div class="flex items-center gap-5">

                            <button type="button" @click="toggleLike()" class="flex items-center gap-1.5 transition"
                                :class="liked ? 'text-red-500' : 'hover:text-red-500'">
                                <svg class="w-4 h-4" :fill="liked ? 'currentColor' : 'none'" stroke="currentColor"
                                    stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z">
                                    </path>
                                </svg>

                                <span x-text="likesCount"></span>
                            </button>

                            <button type="button" @click="showAllComments = !showAllComments"
                                class="flex items-center gap-1.5 hover:text-blue-500 transition">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z">
                                    </path>
                                </svg>

                                <span x-text="commentsCount"></span>
                            </button>

                            <button type="button" @click="sharePost()" class="flex items-center gap-1.5 transition"
                                :class="copied ? 'text-emerald-600' : 'hover:text-emerald-500'">
                                <svg x-show="!copied" class="w-4 h-4" fill="none" stroke="currentColor"
                                    stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z">
                                    </path>
                                </svg>

                                <svg x-show="copied" class="w-4 h-4" fill="none" stroke="currentColor"
                                    stroke-width="2.5" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path>
                                </svg>

                                <span x-text="copied ? 'Copied!' : 'Share'"></span>
                            </button>

                        </div>

                        <button type="button" @click="toggleSave()" class="flex items-center gap-1.5 transition"
                            :class="saved ? 'text-amber-500' : 'hover:text-amber-500'">
                            <svg class="w-4 h-4" :fill="saved ? 'currentColor' : 'none'" stroke="currentColor"
                                stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"></path>
                            </svg>

                            <span x-text="saved ? 'Saved' : 'Save'"></span>
                        </button>

                    </div>

                    {{-- COMMENTS --}}
                    <div class="pt-3 border-t border-slate-100 space-y-3" x-show="showAllComments" x-cloak>

                        <div class="flex gap-2">

                            <input type="text" x-model="newCommentText" @keydown.enter="submitComment()"
                                placeholder="Write a comment..."
                                class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-amber-400">

                            <button type="button" @click="submitComment()"
                                class="px-3 py-2 bg-[#0b1329] text-white rounded-xl text-xs font-semibold hover:bg-slate-800 transition">
                                Post
                            </button>

                        </div>

                        <div class="space-y-2.5 pt-1">

                            <template x-for="comment in comments" :key="comment.id">

                                <div
                                    class="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">

                                    <img :src="comment.user.avatar" class="w-7 h-7 rounded-full object-cover shrink-0">

                                    <div class="min-w-0 flex-1">

                                        <div class="flex items-center justify-between">

                                            <span class="font-bold text-slate-900 text-xs"
                                                x-text="comment.user.name"></span>

                                            <span class="text-[10px] text-slate-400"
                                                x-text="comment.created_at_human"></span>

                                        </div>

                                        <p class="text-xs text-slate-700 mt-0.5 leading-relaxed"
                                            x-text="comment.content"></p>

                                    </div>

                                </div>

                            </template>

                        </div>

                        <div class="text-center pt-1" x-show="comments.length < commentsCount">
                            <button type="button" @click="loadMoreComments()"
                                class="text-xs font-semibold text-amber-600 hover:underline"
                                x-text="loadingMore ? 'Loading...' : 'See more comments'"></button>
                        </div>

                    </div>

                </div>

            @empty

                <div class="bg-white p-8 text-center rounded-2xl shadow-sm border border-slate-200/70">
                    <p class="text-xs text-slate-500">
                        No discussions found matching your criteria.
                    </p>
                </div>

            @endforelse

            {{-- PAGINATION --}}
            @if (method_exists($posts, 'links'))
                <div class="mt-4">
                    {{ $posts->links() }}
                </div>
            @endif

        </section>

        {{-- RIGHT SIDEBAR --}}
        <x-community.rightbar :user="$user" :trending-topics="$trendingTopics" />

    </main>
    {{-- MOBILE BOTTOM NAVIGATION --}}
    <div
        class="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 lg:hidden px-4 py-2 z-40 flex items-center justify-around shadow-lg">

        <a href="{{ route('community.index') }}"
            class="flex flex-col items-center gap-1 text-slate-500 hover:text-[#0b1329]">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 011-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 011 1m-6 0h6">
                </path>
            </svg>

            <span class="text-[10px] font-medium">
                Home
            </span>
        </a>

        <a href="{{ route('community.index') }}" class="flex flex-col items-center gap-1 text-[#0b1329] font-bold">
            <svg class="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" stroke-width="2.5"
                viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z">
                </path>
            </svg>

            <span class="text-[10px]">
                Community
            </span>
        </a>

        <button type="button" @click.prevent="$dispatch('open-post-modal')"
            class="flex flex-col items-center justify-center -mt-5 focus:outline-none">
            <div
                class="w-12 h-12 bg-[#0b1329] rounded-full flex items-center justify-center text-white shadow-lg border-4 border-[#f3f4f6] transition-transform hover:scale-105">

                <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"></path>
                </svg>

            </div>

            <span class="text-[10px] font-medium text-slate-700 mt-0.5">
                Create
            </span>
        </button>

        <a href="{{ route('community.notifications') }}"
            class="flex flex-col items-center gap-1 text-slate-500 hover:text-[#0b1329] relative">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9">
                </path>
            </svg>

            @if ($notificationsCount > 0)
                <span
                    class="absolute -top-0.5 right-0.5 bg-red-500 text-white text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-bold">
                    {{ $notificationsCount }}
                </span>
            @endif

            <span class="text-[10px] font-medium">
                Notifications
            </span>
        </a>

        <a href="{{ route('community.profile.me') }}"
            class="flex flex-col items-center gap-1 text-slate-500 hover:text-[#0b1329]">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
            </svg>

            <span class="text-[10px] font-medium">
                Profile
            </span>
        </a>

    </div>



</body>

</html>

