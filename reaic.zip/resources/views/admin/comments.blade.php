@extends('layouts.admin')

@section('title', 'Community Comments | REIAC Admin Panel')

@section('content')
<div x-data="{
        // UI & State
        detailModalOpen: false,
        confirmModalOpen: false,
        toast: { show: false, message: '' },
        selectedComments: [],
        selectAll: false,

        currentComment: {},
        confirmAction: { title: '', message: '', btnText: '', btnClass: '', callback: null },

        // Helpers
        showToast(msg) {
            this.toast.message = msg;
            this.toast.show = true;
            setTimeout(() => { this.toast.show = false; }, 3500);
        },
        toggleSelectAll() {
            if (this.selectAll) {
                this.selectedComments = Array.from(document.querySelectorAll('.comment-checkbox')).map(el => parseInt(el.value));
            } else {
                this.selectedComments = [];
            }
        },
        openDetailModal(comment) {
            this.currentComment = comment;
            this.detailModalOpen = true;
        },
        toggleHide(commentId, currentStatus) {
            fetch(`/admin/comments/${commentId}/toggle-hide`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showToast(data.message);
                    setTimeout(() => window.location.reload(), 800);
                }
            })
            .catch(error => {
                console.error('Toggle hide error:', error);
                this.showToast('Unable to update comment status.');
            });
        },
        triggerDelete(commentId) {
            this.confirmAction = {
                title: 'Delete comment #' + commentId + '?',
                message: 'This action will permanently delete this comment and its associated reply thread.',
                btnText: 'Delete Comment',
                btnClass: 'bg-red-600 hover:bg-red-700 text-white',
                callback: () => {
                    fetch(`/admin/comments/${commentId}`, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}',
                            'Accept': 'application/json'
                        }
                    })
                    .then(async res => {
                        const data = await res.json();
                        if (!res.ok) {
                            throw new Error(data.message || 'Failed to delete comment.');
                        }
                        return data;
                    })
                    .then(data => {
                        if (data.success) {
                            this.showToast(data.message);
                            setTimeout(() => {
                                window.location.reload();
                            }, 800);
                        }
                    })
                    .catch(error => {
                        console.error('Delete comment error:', error);
                        this.showToast(error.message || 'Unable to delete comment.');
                    });
                }
            };
            this.confirmModalOpen = true;
        },
        bulkAction(actionType) {
            if (this.selectedComments.length === 0) return;
            
            const actionText = actionType === 'hide' ? 'hide' : 'delete';
            this.confirmAction = {
                title: `${actionType === 'hide' ? 'Hide' : 'Delete'} ${this.selectedComments.length} selected comments?`,
                message: `Are you sure you want to ${actionText} the selected comments?`,
                btnText: `Confirm ${actionType === 'hide' ? 'Hide' : 'Delete'}`,
                btnClass: actionType === 'hide' ? 'bg-amber-500 hover:bg-amber-600 text-slate-950' : 'bg-red-600 hover:bg-red-700 text-white',
                callback: () => {
                    fetch('/admin/comments/bulk-action', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name=&quot;csrf-token&quot;]').getAttribute('content'),
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({ action: actionType, ids: this.selectedComments })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            this.showToast(data.message);
                            setTimeout(() => window.location.reload(), 800);
                        }
                    });
                }
            };
            this.confirmModalOpen = true;
        }
    }" 
    class="space-y-6 font-sans text-slate-800">

    <!-- Toast Notification Overlay -->
    <div x-show="toast.show" 
         x-transition
         class="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs font-medium px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center space-x-2.5"
         x-cloak>
        <span class="w-2 h-2 rounded-full bg-amber-400"></span>
        <span x-text="toast.message"></span>
    </div>

    <!-- Header Section -->
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-slate-900">Community Comments</h1>
            <p class="text-xs text-slate-500 mt-0.5">Review, moderate and manage comments and replies across the community.</p>
        </div>
    </div>

    <!-- 1. STAT CARDS HEADER -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Total Comments</span>
            <div class="flex items-baseline justify-between">
                <span class="text-2xl font-extrabold text-slate-900">{{ number_format($totalCommentsCount) }}</span>
                <span class="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">Live DB</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Comments Today</span>
            <div class="flex items-baseline justify-between">
                <span class="text-2xl font-extrabold text-slate-900">{{ number_format($todayCommentsCount) }}</span>
                <span class="text-[10px] font-medium text-slate-400">Active engagement</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Reported Comments</span>
            <div class="flex items-baseline justify-between">
                <span class="text-2xl font-extrabold text-slate-900">{{ number_format($reportedCommentsCount) }}</span>
                <span class="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">Action needed</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Deleted / Hidden</span>
            <div class="flex items-baseline justify-between">
                <span class="text-2xl font-extrabold text-slate-900">{{ number_format($hiddenCommentsCount) }}</span>
                <span class="text-[10px] font-medium text-slate-400">Filtered out</span>
            </div>
        </div>
    </div>

    <!-- 2. SEARCH & FILTER TOOLBAR -->
    <form method="GET" action="{{ route('admin.comments') }}" class="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div class="flex flex-col sm:flex-row items-center gap-2.5 w-full md:w-auto">
            <div class="relative w-full sm:w-64">
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Search comments, users, posts..." 
                       class="w-full text-xs pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 outline-none">
                <svg class="w-4 h-4 text-slate-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>

            <select name="status" onchange="this.form.submit()" class="w-full sm:w-auto text-xs border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 font-medium text-slate-700 outline-none">
                <option value="">All Statuses</option>
                <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Active</option>
                <option value="reported" {{ request('status') === 'reported' ? 'selected' : '' }}>Reported</option>
                <option value="hidden" {{ request('status') === 'hidden' ? 'selected' : '' }}>Hidden</option>
            </select>

            <select name="type" onchange="this.form.submit()" class="w-full sm:w-auto text-xs border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 font-medium text-slate-700 outline-none">
                <option value="">All Types</option>
                <option value="Comment" {{ request('type') === 'Comment' ? 'selected' : '' }}>Comments</option>
                <option value="Reply" {{ request('type') === 'Reply' ? 'selected' : '' }}>Replies</option>
            </select>
        </div>

        <div class="flex items-center space-x-3 w-full md:w-auto justify-between md:justify-end">
            <a href="{{ route('admin.comments') }}" class="text-xs text-slate-400 hover:text-slate-600 font-medium">Clear Filters</a>
            <button type="submit" class="px-3 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-bold">Filter</button>
        </div>
    </form>

    <!-- BULK ACTIONS FLOATING TOOLBAR -->
    <div x-show="selectedComments.length > 0" x-transition class="bg-slate-900 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center justify-between text-xs" x-cloak>
        <div class="flex items-center space-x-2">
            <span class="w-2 h-2 rounded-full bg-amber-400"></span>
            <span>Selected <strong x-text="selectedComments.length"></strong> comments</span>
        </div>
        <div class="flex items-center space-x-2">
            <button @click="bulkAction('hide')" class="px-3 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg">Hide Selected</button>
            <button @click="bulkAction('delete')" class="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg">Delete Selected</button>
        </div>
    </div>

    <!-- 3. COMMENTS DATA TABLE -->
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-50/70 text-[10px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-200/60">
                        <th class="py-3 px-3 w-10 text-center">
                            <input type="checkbox" x-model="selectAll" @change="toggleSelectAll()" class="rounded border-slate-300 text-amber-500 focus:ring-amber-500">
                        </th>
                        <th class="py-3 px-4 min-w-[280px]">Comment Content</th>
                        <th class="py-3 px-4">Author</th>
                        <th class="py-3 px-4 min-w-[200px]">On Discussion Post</th>
                        <th class="py-3 px-4 text-center">Type</th>
                        <th class="py-3 px-4 text-center">Likes</th>
                        <th class="py-3 px-4 text-center">Replies</th>
                        <th class="py-3 px-4 text-center">Status</th>
                        <th class="py-3 px-4 text-right">Date</th>
                        <th class="py-3 px-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-xs font-medium">
                    @forelse($comments as $comment)
                        @php
                            $statusVal = is_object($comment->status) ? ($comment->status->value ?? $comment->status->name) : $comment->status;
                            $isReply = !is_null($comment->parent_id);
                            
                            // Robust check for profile pictures (checks user attributes, avatar column, relations, and falls back gracefully)
                            $userModel = $comment->user;
                            $avatarUrl = 'https://ui-avatars.com/api/?name=' . urlencode($userModel->name ?? 'User') . '&background=0B132B&color=fff';
                            
                            if ($userModel) {
                                if (!empty($userModel->profile_photo_url)) {
                                    $avatarUrl = $userModel->profile_photo_url;
                                } elseif (!empty($userModel->avatar)) {
                                    $avatarUrl = $userModel->avatar;
                                } elseif (isset($userModel->profile) && !empty($userModel->profile->avatar)) {
                                    $avatarUrl = $userModel->profile->avatar;
                                } elseif (isset($userModel->profile_photo_path)) {
                                    $avatarUrl = asset('storage/' . $userModel->profile_photo_path);
                                }
                            }
                        @endphp
                        <tr class="hover:bg-slate-50/60 transition-colors">
                            <td class="py-3 px-3 text-center">
                                <input type="checkbox" value="{{ $comment->id }}" x-model="selectedComments" class="comment-checkbox rounded border-slate-300 text-amber-500 focus:ring-amber-500">
                            </td>

                            <td class="py-3 px-4">
                                <a href="javascript:void(0)" @click="openDetailModal({{ json_encode([
                                    'id' => $comment->id,
                                    'content' => $comment->content,
                                    'status' => ucfirst($statusVal),
                                    'likes' => $comment->likes_count ?? 0,
                                    'createdAt' => $comment->created_at->format('d M Y, h:i A'),
                                    'user' => [
                                        'name' => $userModel->name ?? 'Unknown',
                                        'username' => $userModel->username ?? 'user',
                                        'avatar' => $avatarUrl
                                    ],
                                    'post' => [
                                        'title' => $comment->post->title ?? 'Deleted Post'
                                    ],
                                    'replies' => $comment->replies->map(fn($r) => [
                                        'id' => $r->id,
                                        'name' => $r->user->name ?? 'User',
                                        'text' => $r->content,
                                        'time' => $r->created_at->format('d M Y, h:i A')
                                    ])
                                ]) }})" class="font-normal text-slate-800 hover:text-amber-600 line-clamp-2 leading-relaxed">
                                    {{ $comment->content }}
                                </a>
                            </td>

                            <td class="py-3 px-4 whitespace-nowrap">
                                <div class="flex items-center space-x-2">
                                    <img src="{{ $avatarUrl }}" class="w-7 h-7 rounded-full object-cover border border-slate-200" onerror="this.src='https://ui-avatars.com/api/?name={{ urlencode($userModel->name ?? 'User') }}&background=0B132B&color=fff'">
                                    <div>
                                        <p class="font-bold text-slate-900 leading-tight">{{ $userModel->name ?? 'Deleted User' }}</p>
                                        <p class="text-[10px] text-slate-400 font-normal">{{ '@'.($userModel->username ?? 'user') }}</p>
                                    </div>
                                </div>
                            </td>

                            <td class="py-3 px-4">
                                <a href="{{ isset($comment->post) ? route('community.posts.show', $comment->post) : '#' }}" target="_blank" class="font-semibold text-slate-700 hover:underline line-clamp-1">
                                    {{ $comment->post->title ?? 'Deleted Post' }}
                                </a>
                            </td>

                            <td class="py-3 px-4 text-center whitespace-nowrap">
                                <span class="px-2.5 py-0.5 rounded-md text-[10px] font-bold {{ $isReply ? 'bg-sky-50 text-sky-700' : 'bg-slate-100 text-slate-700' }}">
                                    {{ $isReply ? 'Reply' : 'Comment' }}
                                </span>
                            </td>

                            <td class="py-3 px-4 text-center font-bold text-slate-800">{{ $comment->likes_count ?? 0 }}</td>
                            <td class="py-3 px-4 text-center font-bold text-slate-800">{{ $comment->replies->count() }}</td>

                            <td class="py-3 px-4 text-center whitespace-nowrap">
                                @if($statusVal === 'active')
                                    <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                        <span>Visible</span>
                                    </span>
                                @elseif($statusVal === 'reported')
                                    <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200/60">
                                        <span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                                        <span>Reported</span>
                                    </span>
                                @else
                                    <span class="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200/60">
                                        <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                        <span>Hidden</span>
                                    </span>
                                @endif
                            </td>

                            <td class="py-3 px-4 text-right text-slate-400 text-[11px] whitespace-nowrap">{{ $comment->created_at->format('d M Y, h:i A') }}</td>

                            <td class="py-3 px-4 text-right whitespace-nowrap">
                                <div class="flex items-center justify-end space-x-1">
                                    <button @click="openDetailModal({{ json_encode([
                                        'id' => $comment->id,
                                        'content' => $comment->content,
                                        'status' => ucfirst($statusVal),
                                        'likes' => $comment->likes_count ?? 0,
                                        'createdAt' => $comment->created_at->format('d M Y, h:i A'),
                                        'user' => [
                                            'name' => $userModel->name ?? 'Unknown',
                                            'username' => $userModel->username ?? 'user',
                                            'avatar' => $avatarUrl
                                        ],
                                        'post' => [
                                            'title' => $comment->post->title ?? 'Deleted Post'
                                        ],
                                        'replies' => $comment->replies->map(fn($r) => [
                                            'id' => $r->id,
                                            'name' => $r->user->name ?? 'User',
                                            'text' => $r->content,
                                            'time' => $r->created_at->format('d M Y, h:i A')
                                        ])
                                    ]) }})" class="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100" title="View Comment">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                    </button>
                                    <button @click="toggleHide({{ $comment->id }}, '{{ $statusVal }}')" class="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-slate-100" title="Toggle Hide">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858-5.908a9.04 9.04 0 012.122-.363c4.478 0 8.268 2.943 9.542 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21M3 3l18 18"/></svg>
                                    </button>
                                    <button @click="triggerDelete({{ $comment->id }})" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100" title="Delete Comment">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="10" class="py-6 text-center text-slate-400">No comments found in database.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Pagination Footer -->
        <div class="px-5 py-3.5 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs">
            {{ $comments->links() }}
        </div>
    </div>

    <!-- COMMENT DETAIL MODAL -->
    <div x-show="detailModalOpen" class="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4" x-cloak>
        <div @click.outside="detailModalOpen = false" class="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-5 border border-slate-200 overflow-hidden">
            <div class="flex items-center justify-between border-b pb-3">
                <div class="flex items-center space-x-2">
                    <span class="text-xs font-bold px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-mono" x-text="'COMMENT #' + currentComment.id"></span>
                    <span class="text-xs font-bold text-emerald-600 capitalize" x-text="'● ' + currentComment.status"></span>
                </div>
                <button @click="detailModalOpen = false" class="p-1 text-slate-400 hover:text-slate-600"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>
            </div>

            <div class="space-y-4 text-xs">
                <!-- User & Context -->
                <div class="flex items-center space-x-3 p-3 bg-slate-50 rounded-xl">
                    <img :src="currentComment.user?.avatar" class="w-9 h-9 rounded-full object-cover">
                    <div>
                        <p class="font-bold text-slate-900" x-text="currentComment.user?.name"></p>
                        <p class="text-[10px] text-slate-400" x-text="'Commented on: ' + currentComment.post?.title"></p>
                    </div>
                </div>

                <!-- Comment Content -->
                <div class="p-4 bg-white border border-slate-200 rounded-xl text-slate-800 leading-relaxed font-medium">
                    <p x-text="currentComment.content"></p>
                </div>

                <!-- Thread Replies -->
                <div class="space-y-2">
                    <h4 class="font-bold text-slate-900 uppercase tracking-wider text-[10px]">Thread Replies (<span x-text="currentComment.replies?.length || 0"></span>)</h4>
                    <template x-if="currentComment.replies && currentComment.replies.length > 0">
                        <div class="space-y-2 pl-4 border-l-2 border-slate-200">
                            <template x-for="r in currentComment.replies" :key="r.id">
                                <div class="p-2.5 bg-slate-50 rounded-lg">
                                    <div class="flex justify-between font-bold text-slate-900">
                                        <span x-text="r.name"></span>
                                        <span class="text-[10px] text-slate-400" x-text="r.time"></span>
                                    </div>
                                    <p class="text-slate-600 mt-0.5" x-text="r.text"></p>
                                </div>
                            </template>
                        </div>
                    </template>
                    <template x-if="!currentComment.replies || currentComment.replies.length === 0">
                        <p class="text-slate-400 italic">No direct replies on this comment.</p>
                    </template>
                </div>
            </div>

            <div class="flex justify-end space-x-2 border-t pt-3">
                <button @click="toggleHide(currentComment.id, currentComment.status); detailModalOpen = false" class="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl">
                    <span x-text="currentComment.status === 'Hidden' ? 'Restore Comment' : 'Hide Comment'"></span>
                </button>
                <button @click="triggerDelete(currentComment.id)" class="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl">
                    Delete Comment
                </button>
            </div>
        </div>
    </div>

    <!-- CONFIRMATION MODAL -->
    <div x-show="confirmModalOpen" class="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4" x-cloak>
        <div @click.outside="confirmModalOpen = false" class="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200">
            <h3 class="font-bold text-slate-900 text-base" x-text="confirmAction.title"></h3>
            <p class="text-xs text-slate-600 leading-relaxed" x-text="confirmAction.message"></p>
            <div class="flex justify-end space-x-2 pt-2">
                <button @click="confirmModalOpen = false" class="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 rounded-xl">Cancel / Close</button>
                <button @click="confirmAction.callback && confirmAction.callback(); confirmModalOpen = false" :class="confirmAction.btnClass" class="px-4 py-2 text-xs font-bold rounded-xl">
                    <span x-text="confirmAction.btnText"></span>
                </button>
            </div>
        </div>
    </div>

</div>
@endsection