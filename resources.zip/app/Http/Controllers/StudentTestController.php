<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Test;
use App\Models\TestAttempt;
use App\Models\AttemptAnswer;
use App\Models\Question;
use App\Models\TestQuestion;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\Storage;

class StudentTestController extends Controller
{
    public function index(): View
    {
        $user = auth()->user();
        $now = now();

        // Query published tests whose close date has not passed (not expired) and whose test level is active
        $tests = Test::with(['testLevel', 'questions'])
            ->where('status', 'published')
            ->whereHas('testLevel', function ($q) {
                $q->where('status', 'active');
            })
            ->where(function ($q) use ($now) {
                $q->whereNull('close_date')
                  ->orWhere(function ($sub) use ($now) {
                      $sub->whereDate('close_date', '>', $now->toDateString())
                          ->orWhere(function ($s) use ($now) {
                              $s->whereDate('close_date', '=', $now->toDateString())
                                ->where(function ($t) use ($now) {
                                    $t->whereNull('close_time')
                                      ->orWhere('close_time', '>=', $now->toTimeString());
                                });
                          });
                  });
            })
            ->orderBy('open_date', 'asc')
            ->orderByDesc('created_at')
            ->get();

        $userAttempts = collect();
        if ($user) {
            // Filter tests to only those the student has permission to access
            $tests = $tests->filter(function ($test) use ($user) {
                return $test->canUserAccess($user);
            })->values();

            $userAttempts = TestAttempt::where('user_id', $user->id)
                ->whereIn('test_id', $tests->pluck('id'))
                ->latest('created_at')
                ->get()
                ->groupBy('test_id');

            // Exclude tests that the student has already completed (exhausted attempts)
            $tests = $tests->reject(function ($test) use ($userAttempts) {
                $attempts = $userAttempts->get($test->id, collect());
                $completedCount = $attempts->where('status', 'completed')->count();
                $maxAttempts = $test->max_attempts > 0 ? $test->max_attempts : 1;
                return $completedCount >= $maxAttempts;
            })->values();
        }

        foreach ($tests as $test) {
            $attempts = $userAttempts->get($test->id, collect());
            $test->user_attempts_count = $attempts->count();
            $test->latest_attempt = $attempts->first();
            $test->active_attempt = $attempts->firstWhere('status', 'active');
            $test->is_open = $test->isOpen();
            $test->can_take = $user ? $test->isAvailableFor($user) : false;
        }

        $completedCountTotal = $user
            ? TestAttempt::where('user_id', $user->id)->where('status', 'completed')->count()
            : 0;

        return view('student.tests.index', compact('tests', 'user', 'completedCountTotal'));
    }

    public function show(Test $test): View
    {
        $this->authorizeStudent($test, true);
        $test->load(['testLevel', 'questions.options']);

        $user = auth()->user();
        $activeAttempt = TestAttempt::where('user_id', $user->id)
            ->where('test_id', $test->id)
            ->where('status', 'active')
            ->whereNull('submitted_at')
            ->first();

        // Check if active attempt is actually timed out
        if ($activeAttempt && $activeAttempt->isTimedOut()) {
            $activeAttempt->gradeAndComplete(null, 'timeout');
            $activeAttempt = null;
        }

        $completedAttemptsCount = TestAttempt::where('user_id', $user->id)
            ->where('test_id', $test->id)
            ->where('status', 'completed')
            ->count();

        $latestAttempt = TestAttempt::where('user_id', $user->id)
            ->where('test_id', $test->id)
            ->where('status', 'completed')
            ->latest('submitted_at')
            ->first();

        return view('student.tests.show', compact('test', 'activeAttempt', 'completedAttemptsCount', 'latestAttempt'));
    }

    public function start(Request $request, Test $test): RedirectResponse
    {
        $this->authorizeStudent($test);

        $test->load(['questions']);

        if ($test->questions->isEmpty()) {
            return back()->with('error', 'This examination currently has no questions assigned.');
        }

        $userId = auth()->id();

        // Resume ongoing active attempt if available
        $activeAttempt = TestAttempt::where('user_id', $userId)
            ->where('test_id', $test->id)
            ->where('status', 'active')
            ->whereNull('submitted_at')
            ->first();

        if ($activeAttempt) {
            if ($activeAttempt->isTimedOut()) {
                $activeAttempt->gradeAndComplete(null, 'timeout');
                return redirect()->route('tests.student.result', ['test' => $test, 'attempt' => $activeAttempt])
                    ->with('info', 'Examination duration ended. Responses were auto-submitted.');
            }
            return redirect()->route('tests.student.take', ['test' => $test, 'attempt' => $activeAttempt])
                ->with('info', 'Resumed ongoing examination session.');
        }

        // Photo requirement verification
        $candidatePhotoPath = null;
        if ($test->require_camera_photo) {
            $candidatePhotoPath = $this->handleCandidatePhoto($request);
            if (!$candidatePhotoPath) {
                return back()->with('error', 'Candidate face verification is mandatory. Please capture or upload your real-time photo before starting.');
            }
        }

        // Check max attempts
        if ($test->max_attempts > 0) {
            $completedCount = TestAttempt::where('user_id', $userId)
                ->where('test_id', $test->id)
                ->where('status', 'completed')
                ->count();

            if ($completedCount >= $test->max_attempts) {
                $latestAttempt = TestAttempt::where('user_id', $userId)
                    ->where('test_id', $test->id)
                    ->where('status', 'completed')
                    ->latest('submitted_at')
                    ->first();

                if ($latestAttempt) {
                    return redirect()->route('tests.student.result', ['test' => $test, 'attempt' => $latestAttempt])
                        ->with('info', 'You have already completed the maximum allowed attempt (' . $test->max_attempts . ') for this examination.');
                }

                return redirect()->route('tests.student.index')
                    ->with('error', 'You have already completed the maximum allowed attempts for this examination.');
            }
        }

        $userAttemptsCount = TestAttempt::where('test_id', $test->id)->where('user_id', $userId)->count();

        $attempt = TestAttempt::create([
            'user_id' => $userId,
            'test_id' => $test->id,
            'attempt_number' => $userAttemptsCount + 1,
            'candidate_photo' => $candidatePhotoPath,
            'started_at' => now(),
            'allowed_until' => now()->addMinutes($test->duration_minutes),
            'total_questions' => $test->questions->count(),
            'answered_count' => 0,
            'correct_count' => 0,
            'incorrect_count' => 0,
            'unanswered_count' => $test->questions->count(),
            'score_obtained' => 0,
            'percentage' => 0,
            'result' => 'pending',
            'submission_type' => 'manual',
            'tab_switch_count' => 0,
            'status' => 'active',
        ]);

        foreach ($test->questions as $question) {
            AttemptAnswer::create([
                'test_attempt_id' => $attempt->id,
                'question_id' => $question->id,
                'selected_option_id' => null,
                'is_marked_for_review' => false,
                'is_correct' => false,
                'marks_obtained' => 0,
                'answered_at' => null,
            ]);
        }

        return redirect()->route('tests.student.take', ['test' => $test, 'attempt' => $attempt])
            ->with('success', 'Examination session started. All best for your performance!');
    }

    public function take(Test $test, TestAttempt $attempt): View|RedirectResponse
    {
        $this->authorizeStudent($test);

        if ($attempt->user_id !== auth()->id()) {
            abort(403, 'Unauthorized.');
        }

        if ($attempt->status === 'completed') {
            return redirect()->route('tests.student.result', ['test' => $test, 'attempt' => $attempt])
                ->with('info', 'This examination attempt has already been submitted.');
        }

        $this->authorizeAttempt($attempt);

        if ($attempt->isTimedOut()) {
            $attempt->gradeAndComplete(null, 'timeout');
            return redirect()->route('tests.student.result', ['test' => $test, 'attempt' => $attempt])
                ->with('info', 'Allocated examination time has expired. Your responses have been automatically submitted.');
        }

        $test->load(['questions.options', 'testLevel']);

        // Ensure all questions have attempt answer rows
        foreach ($test->questions as $q) {
            AttemptAnswer::firstOrCreate([
                'test_attempt_id' => $attempt->id,
                'question_id' => $q->id,
            ], [
                'selected_option_id' => null,
                'is_marked_for_review' => false,
                'is_correct' => false,
                'marks_obtained' => 0,
                'answered_at' => null,
            ]);
        }

        $attempt->load(['answers']);

        $questionsData = $test->questions->map(function ($q) {
            return [
                'id' => (int) $q->id,
                'question_text' => (string) $q->question_text,
                'question_type' => (string) $q->question_type,
                'marks' => (int) $q->marks,
                'options' => $q->options->map(function ($opt) {
                    return [
                        'id' => (int) $opt->id,
                        'option_label' => (string) $opt->option_label,
                        'option_text' => (string) $opt->option_text,
                    ];
                })->values()->toArray(),
            ];
        })->values()->toArray();

        $answersData = $attempt->answers->map(function ($a) {
            return [
                'id' => (int) $a->id,
                'question_id' => (int) $a->question_id,
                'selected_option_id' => $a->selected_option_id ? (int) $a->selected_option_id : null,
                'is_marked_for_review' => (bool) $a->is_marked_for_review,
            ];
        })->values()->toArray();

        $remainingSeconds = $attempt->allowed_until
            ? max(0, $attempt->allowed_until->timestamp - now()->timestamp)
            : ($test->duration_minutes * 60);

        return view('student.tests.take', compact('test', 'attempt', 'remainingSeconds', 'questionsData', 'answersData'));
    }

    public function submit(Request $request, Test $test, TestAttempt $attempt): RedirectResponse
    {
        $this->authorizeStudent($test);
        $this->authorizeAttempt($attempt);

        $tabSwitchCount = (int) $request->input('tab_switch_count', 0);

        $isTimeout = $attempt->isTimedOut() || $request->input('is_timeout') == '1';
        $submissionType = 'manual';

        if ($isTimeout) {
            $submissionType = 'timeout';
        } elseif ($tabSwitchCount >= 1 || ($test->tab_switch_limit > 0 && $tabSwitchCount >= $test->tab_switch_limit)) {
            $submissionType = 'tab_switch_violation';
        }

        $answers = null;
        if ($request->filled('answers')) {
            $rawAnswers = $request->input('answers');
            if (is_string($rawAnswers)) {
                $decoded = json_decode($rawAnswers, true);
                if (is_array($decoded)) {
                    $answers = $decoded;
                }
            } elseif (is_array($rawAnswers)) {
                $answers = $rawAnswers;
            }
        }

        $attempt->gradeAndComplete($answers, $submissionType, $tabSwitchCount);

        $message = match ($submissionType) {
            'timeout' => 'Examination time expired. Your paper has been auto-submitted.',
            'tab_switch_violation' => 'Screen change detected. Your examination was auto-submitted.',
            default => 'Examination submitted successfully.'
        };

        return redirect()->route('tests.student.result', ['test' => $test, 'attempt' => $attempt])
            ->with('success', $message);
    }

    public function result(Test $test, TestAttempt $attempt): View
    {
        // Verify attempt belongs to the test
        if ((int) $attempt->test_id !== (int) $test->id) {
            abort(404, 'Examination attempt not found.');
        }

        // For completed attempts, allow viewing so mobile users and certificate verifiers can access without web login.
        // For uncompleted attempts, require active authentication.
        if ($attempt->status !== 'completed') {
            $this->authorizeStudent($test, true);
            $this->authorizeAttempt($attempt, false);
        }

        $test->load(['questions.options', 'testLevel']);
        $attempt->load(['answers.question.options', 'answers.option', 'user.profile']);

        // Maintain consistent question ordering according to test definition
        $orderMap = $test->questions->pluck('pivot.question_order', 'id')->all();
        $attempt->setRelation(
            'answers',
            $attempt->answers->sortBy(function ($ans) use ($orderMap) {
                return $orderMap[$ans->question_id] ?? $ans->id;
            })->values()
        );

        return view('student.tests.result', compact('test', 'attempt'));
    }

    public function certificate(Test $test, TestAttempt $attempt): View
    {
        if ((int) $attempt->test_id !== (int) $test->id) {
            abort(404, 'Examination attempt not found.');
        }

        if ($attempt->status !== 'completed') {
            if (!auth()->check() || (int) $attempt->user_id !== (int) auth()->id()) {
                abort(403, 'Examination not completed yet.');
            }
        }

        $test->load(['testLevel']);
        $attempt->load(['user.profile']);

        return view('student.tests.certificate', compact('test', 'attempt'));
    }

    /**
     * Print-only certificate HTML (same card as website). Used by headless Chrome PDF.
     * Requires a valid temporary signed URL.
     */
    public function certificatePrint(Request $request, Test $test, TestAttempt $attempt): View
    {
        if (!$request->hasValidSignature()) {
            abort(403, 'Invalid or expired print link.');
        }

        if ((int) $attempt->test_id !== (int) $test->id) {
            abort(404, 'Examination attempt not found.');
        }

        if ($attempt->status !== 'completed') {
            abort(403, 'Examination not completed yet.');
        }

        $test->load(['testLevel']);
        $attempt->load(['user.profile']);

        return view('student.tests.certificate-print', compact('test', 'attempt'));
    }

    public function downloadCertificatePdf(Request $request, Test $test, TestAttempt $attempt)
    {
        if ((int) $attempt->test_id !== (int) $test->id) {
            abort(404, 'Examination attempt not found.');
        }

        if ($attempt->status !== 'completed') {
            if (!auth()->check() || (int) $attempt->user_id !== (int) auth()->id()) {
                abort(403, 'Examination not completed yet.');
            }
        }

        $pdfService = app(\App\Services\CertificatePdfService::class);
        $safeName = preg_replace('/[^A-Za-z0-9_\-]/', '_', $attempt->user->name ?? 'Candidate');
        $filename = "Certificate_{$safeName}_{$attempt->id}.pdf";

        if ($request->boolean('base64')) {
            $base64 = $pdfService->getPdfBase64($test, $attempt);
            return response()->json([
                'status' => true,
                'filename' => $filename,
                'mime_type' => 'application/pdf',
                'pdf_base64' => $base64,
            ]);
        }

        if ($request->hasAny(['refresh', 'force', 'clear'])) {
            $pdfService->clearCache($test, $attempt);
        }

        // Check if file is available on disk
        $pdfPath = $pdfService->getOrGeneratePdf($test, $attempt);
        if ($pdfPath && file_exists($pdfPath) && filesize($pdfPath) > 1000) {
            if ($request->boolean('inline') || $request->boolean('stream')) {
                return response()->file($pdfPath, [
                    'Content-Type' => 'application/pdf',
                    'Content-Disposition' => 'inline; filename="' . $filename . '"',
                    'Access-Control-Allow-Origin' => '*',
                ]);
            }

            return response()->download($pdfPath, $filename, [
                'Content-Type' => 'application/pdf',
                'Access-Control-Allow-Origin' => '*',
            ]);
        }

        // Fallback: In-memory binary response (never throws FileNotFoundException)
        $binary = $pdfService->getPdfBinary($test, $attempt);
        if ($binary && strlen($binary) > 1000) {
            $disposition = ($request->boolean('inline') || $request->boolean('stream')) ? 'inline' : 'attachment';

            return response($binary, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => "{$disposition}; filename=\"{$filename}\"",
                'Content-Length' => strlen($binary),
                'Access-Control-Allow-Origin' => '*',
            ]);
        }

        // Graceful fallback if no server PDF engine is installed:
        return redirect()->route('tests.student.certificate', [
            'test' => $test->id,
            'attempt' => $attempt->id,
            'autodownload' => 1,
        ]);
    }

    public function saveAnswer(Request $request, Test $test, TestAttempt $attempt): JsonResponse
    {
        $this->authorizeStudent($test);
        $this->authorizeAttempt($attempt);

        $questionId = (int) $request->input('question_id');
        $selectedOptionId = $request->input('selected_option_id') ?? $request->input('option_id');

        if (!$selectedOptionId) {
            return response()->json(['success' => false, 'message' => 'No option selected'], 422);
        }

        $selectedOptionId = (int) $selectedOptionId;

        // Verify that the option belongs to the question
        $optionExists = \App\Models\QuestionOption::where('question_id', $questionId)
            ->where('id', $selectedOptionId)
            ->exists();

        if (!$optionExists) {
            return response()->json(['success' => false, 'message' => 'Invalid option selected for this question'], 422);
        }

        $answer = AttemptAnswer::where('test_attempt_id', $attempt->id)
            ->where('question_id', $questionId)
            ->first();

        if (!$answer) {
            $answer = AttemptAnswer::create([
                'test_attempt_id' => $attempt->id,
                'question_id' => $questionId,
                'selected_option_id' => $selectedOptionId,
                'is_marked_for_review' => false,
                'is_correct' => false,
                'marks_obtained' => 0,
                'answered_at' => now(),
            ]);
        } else {
            $answer->update([
                'selected_option_id' => $selectedOptionId,
                'answered_at' => now(),
            ]);
        }

        return response()->json(['success' => true]);
    }

    public function clearAnswer(Request $request, Test $test, TestAttempt $attempt): JsonResponse
    {
        $this->authorizeStudent($test);
        $this->authorizeAttempt($attempt);

        $questionId = (int) $request->input('question_id');

        $answer = AttemptAnswer::where('test_attempt_id', $attempt->id)
            ->where('question_id', $questionId)
            ->first();

        if ($answer) {
            $answer->update([
                'selected_option_id' => null,
                'answered_at' => null,
            ]);
        }

        return response()->json(['success' => true]);
    }

    public function toggleMarkForReview(Request $request, Test $test, TestAttempt $attempt): JsonResponse
    {
        $this->authorizeStudent($test);
        $this->authorizeAttempt($attempt);

        $questionId = $request->input('question_id');

        $answer = AttemptAnswer::where('test_attempt_id', $attempt->id)
            ->where('question_id', $questionId)
            ->firstOrFail();

        $answer->update([
            'is_marked_for_review' => !$answer->is_marked_for_review,
        ]);

        return response()->json([
            'success' => true,
            'is_marked_for_review' => $answer->is_marked_for_review,
        ]);
    }

    private function authorizeStudent(Test $test, bool $allowClosedView = false): void
    {
        if (!auth()->check()) {
            abort(403, 'Please login to take a test.');
        }

        if (!$test->canUserAccess(auth()->user())) {
            abort(403, 'You do not have permission to access this examination.');
        }

        if ($test->status !== 'published') {
            abort(404, 'Test not found.');
        }

        if ($test->testLevel && $test->testLevel->status !== 'active') {
            abort(403, 'This test level is currently inactive.');
        }

        if (!$allowClosedView && !$test->isOpen()) {
            abort(403, 'This test is not currently available.');
        }
    }

    protected function handleCandidatePhoto(Request $request): ?string
    {
        if ($request->hasFile('candidate_photo') && $request->file('candidate_photo')->isValid()) {
            $path = $request->file('candidate_photo')->store('test-attempts/photos', 'public');
            $this->autoCorrectOrientation(storage_path('app/public/' . $path));
            return $path;
        }

        $base64 = $request->input('candidate_photo_base64') ?? $request->input('candidate_photo');
        if ($base64 && is_string($base64) && str_starts_with($base64, 'data:image/')) {
            $parts = explode(',', $base64);
            if (count($parts) === 2) {
                $data = base64_decode($parts[1]);
                if ($data !== false) {
                    $filename = 'test-attempts/photos/' . uniqid('photo_') . '_' . time() . '.jpg';
                    Storage::disk('public')->put($filename, $data);
                    $this->autoCorrectOrientation(storage_path('app/public/' . $filename));
                    return $filename;
                }
            }
        }

        return null;
    }

    protected function autoCorrectOrientation(string $filePath): void
    {
        if (!file_exists($filePath) || !function_exists('exif_read_data') || !function_exists('imagerotate')) {
            return;
        }

        try {
            $exif = @exif_read_data($filePath);
            if (!empty($exif['Orientation'])) {
                $image = @imagecreatefromstring(file_get_contents($filePath));
                if (!$image) return;

                switch ((int) $exif['Orientation']) {
                    case 3:
                        $image = imagerotate($image, 180, 0);
                        break;
                    case 6:
                        $image = imagerotate($image, -90, 0);
                        break;
                    case 8:
                        $image = imagerotate($image, 90, 0);
                        break;
                    default:
                        imagedestroy($image);
                        return;
                }

                imagejpeg($image, $filePath, 90);
                imagedestroy($image);
            }
        } catch (\Throwable $e) {
            // Ignore if orientation correction fails
        }
    }

    private function authorizeAttempt(TestAttempt $attempt, bool $requireActive = true): void
    {
        if ($attempt->user_id !== auth()->id()) {
            abort(403, 'Unauthorized.');
        }

        if ($requireActive && $attempt->status !== 'active') {
            abort(403, 'This attempt is no longer active.');
        }

        $test = $attempt->test;
        if ($test->close_date) {
            $closesAt = $test->close_time
                ? $test->close_date->copy()->setTimeFrom($test->close_time)
                : $test->close_date->endOfDay();

            if (now()->gt($closesAt)) {
                abort(403, 'This test has expired.');
            }
        }
    }
}