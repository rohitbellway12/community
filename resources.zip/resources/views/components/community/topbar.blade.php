@props([
    'notificationsCount' => 0,
])

<style>
    .language-switcher {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .language-btn {
        border: 1px solid #c89b2a;
        background: transparent;
        color: #c89b2a;
        padding: 6px 14px;
        border-radius: 999px;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
    }
    .language-btn:hover,
    .language-btn.active {
        background: #c89b2a;
        color: #fff;
    }
    #google_translate_element {
        position: absolute;
        left: -9999px;
        top: -9999px;
        height: 0;
        overflow: hidden;
    }
    .goog-te-banner-frame,
    iframe.skiptranslate {
        display: none !important;
        height: 0 !important;
    }
    body {
        top: 0 !important;
    }
    .skiptranslate,
    .goog-te-gadget,
    .goog-logo-link {
        display: none !important;
    }
</style>

@php
    $authUser = auth()->user();

    $topbarProfile = $authUser?->profile;

    $userName = $authUser?->name ?: 'User';
    $defaultAvatar = 'https://ui-avatars.com/api/?name=' .
        urlencode($userName) .
        '&background=0c1b33&color=fff&size=100';

    $topbarAvatar = null;
    $rawAvatar = trim((string) ($topbarProfile?->avatar ?? ''));
    if ($rawAvatar !== '' && $rawAvatar !== 'null' && $rawAvatar !== '0') {
        if (str_starts_with($rawAvatar, 'http://') || str_starts_with($rawAvatar, 'https://')) {
            $topbarAvatar = $rawAvatar;
        } elseif (str_starts_with($rawAvatar, 'storage/')) {
            $topbarAvatar = asset($rawAvatar);
        } else {
            $topbarAvatar = asset('storage/' . ltrim($rawAvatar, '/'));
        }
    }
    if (empty($topbarAvatar)) {
        $topbarAvatar = $defaultAvatar;
    }

    $topbarCountry = $topbarProfile?->country;
    if (!$topbarCountry && $topbarProfile?->country_id) {
        $topbarCountry = \App\Models\Country::find($topbarProfile->country_id);
    }

    $topbarIsoCode = strtolower(trim($topbarCountry?->iso_code ?: ''));
    if (!$topbarIsoCode && !empty($topbarCountry?->code)) {
        $codeTrimmed = strtolower(trim($topbarCountry->code));
        if (strlen($codeTrimmed) === 2) {
            $topbarIsoCode = $codeTrimmed;
        } else {
            $alpha3ToAlpha2 = [
                'bgd' => 'bd', 'ind' => 'in', 'npl' => 'np', 'kor' => 'kr', 'usa' => 'us',
                'gbr' => 'gb', 'can' => 'ca', 'aus' => 'au', 'pak' => 'pk', 'lka' => 'lk',
                'deu' => 'de', 'fra' => 'fr', 'jpn' => 'jp', 'chn' => 'cn', 'are' => 'ae',
                'sau' => 'sa', 'sgp' => 'sg', 'mys' => 'my', 'tha' => 'th', 'vnm' => 'vn',
                'idn' => 'id', 'phl' => 'ph', 'bra' => 'br', 'mex' => 'mx', 'esp' => 'es',
                'ita' => 'it', 'rus' => 'ru', 'tur' => 'tr', 'zaf' => 'za', 'egy' => 'eg',
                'nga' => 'ng', 'ken' => 'ke', 'nzl' => 'nz', 'irl' => 'ie', 'che' => 'ch',
                'nld' => 'nl', 'swe' => 'se', 'nor' => 'no', 'dnk' => 'dk', 'fin' => 'fi',
            ];
            $topbarIsoCode = $alpha3ToAlpha2[$codeTrimmed] ?? '';
        }
    }

    $initialNotifications = [];
    $unreadNotificationsCount = 0;

    if ($authUser) {
        $unreadNotificationsCount = ((int) $notificationsCount > 0)
            ? (int) $notificationsCount
            : (int) $authUser->unreadNotifications()->count();

        $initialNotifications = $authUser->notifications()
            ->orderByRaw('read_at IS NULL DESC')
            ->latest()
            ->take(10)
            ->get()
            ->map(function ($notification) {
                $data = is_array($notification->data) ? $notification->data : [];

                if (empty($data['group_slug'])) {
                    if (!empty($data['url'])) {
                        $data['group_slug'] = basename(parse_url($data['url'], PHP_URL_PATH));
                    } elseif (!empty($data['group_id'])) {
                        $data['group_slug'] = \App\Models\Group::find($data['group_id'])?->slug;
                    }
                }

                $type = strtolower((string) ($notification->type ?? ''));
                $dataType = strtolower((string) ($data['type'] ?? ''));

                if (!empty($data['url'])) {
                    $data['url'] = str_replace('/reaic/', '/community/', $data['url']);
                    $data['url'] = str_replace('/community/community/', '/community/', $data['url']);
                }

                // Dynamically resolve test notification URLs
                if (!empty($data['test_id']) && (
                    $dataType === 'new_test' ||
                    str_contains($type, 'newtest') ||
                    str_contains($data['url'] ?? '', '/tests/student/')
                )) {
                    $data['url'] = route('tests.student.show', ['test' => $data['test_id']]);
                }

                // Resolve follower/profile URL to the user's current live username
                if (!empty($data['user_id']) && (
                    str_contains($data['url'] ?? '', '/profile/') ||
                    str_contains($dataType, 'follow') ||
                    str_contains($type, 'follow')
                )) {
                    $liveUsername = \App\Models\Profile::where('user_id', $data['user_id'])->value('username');
                    if ($liveUsername) {
                        $data['username'] = $liveUsername;
                        $data['url'] = route('community.profile', ['username' => $liveUsername]);
                    }
                }

                $title = $data['title'] ?? null;

                if (!$title) {
                    if ($dataType === 'group_invitation' || str_contains($type, 'groupinvitation')) {
                        $title = 'Group Invitation';
                    } elseif ($dataType === 'group_join_requested' || str_contains($type, 'joinrequest')) {
                        $title = 'Group Join Request';
                    } elseif (str_contains($type, 'reply') || str_contains($dataType, 'reply')) {
                        $title = 'New Reply';
                    } elseif (str_contains($type, 'comment') || str_contains($dataType, 'comment')) {
                        $title = 'New Comment';
                    } elseif (str_contains($type, 'like') || str_contains($dataType, 'like')) {
                        $title = 'Post Liked';
                    } elseif (str_contains($type, 'follow') || str_contains($dataType, 'follow')) {
                        $title = 'New Follower';
                    } else {
                        $title = 'Notification';
                    }
                }

                return [
                    'id' => $notification->id,
                    'type' => $notification->type,
                    'title' => $title,
                    'message' => $data['message'] ?? 'You have a new notification.',
                    'created_at' => $notification->created_at ? $notification->created_at->diffForHumans() : null,
                    'read' => $notification->read_at !== null,
                    'read_at' => $notification->read_at,
                    'data' => $data,
                    'actionStatus' => null,
                ];
            })
            ->values()
            ->toArray();
    }
@endphp

<header
    class="bg-[#0b1329] text-white sticky top-0 z-50"
    x-data="{ mobileMenuOpen: false }"
>
    <div class="max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-8">

        <div class="h-16 flex items-center justify-between gap-4">

            {{-- LEFT SIDE --}}
            <div class="flex items-center gap-3 sm:gap-4 lg:gap-10 min-w-0">

                {{-- Mobile Menu Button --}}
                <button
                    @click="mobileMenuOpen = !mobileMenuOpen"
                    type="button"
                    class="lg:hidden shrink-0 w-9 h-9 rounded-lg flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 transition"
                    :aria-expanded="mobileMenuOpen"
                    aria-label="Toggle navigation"
                >
                    <svg
                        x-show="!mobileMenuOpen"
                        class="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M4 6h16M4 12h16M4 18h16"
                        />
                    </svg>

                    <svg
                        x-show="mobileMenuOpen"
                        x-cloak
                        class="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M6 6l12 12M18 6L6 18"
                        />
                    </svg>
                </button>

                {{-- Logo --}}
                <a
                    href="{{ route('community.index') }}"
                    class="text-base sm:text-xl lg:text-2xl font-black tracking-tight lg:tracking-wider text-white whitespace-nowrap truncate"
                >
                    REIAC Community
                </a>

                {{-- DESKTOP NAVIGATION --}}
                <nav class="hidden lg:flex items-center gap-5 xl:gap-7 text-[13px] font-medium text-slate-300">

                    {{-- Home --}}
                    <a
                        href="https://www.reiaconsultancy.com/"
                        class="hover:text-white transition whitespace-nowrap"
                    >
                        Home
                    </a>

                    {{-- About Us --}}
                    <a
                        href="https://www.reiaconsultancy.com/about-us"
                        class="hover:text-white transition whitespace-nowrap"
                    >
                        About Us
                    </a>

                    {{-- Services --}}
                    <div
                        x-data="{ servicesOpen: false }"
                        class="relative"
                    >
                        <button
                            type="button"
                            @click="servicesOpen = !servicesOpen"
                            @click.outside="servicesOpen = false"
                            class="flex items-center gap-1 text-[13px] font-medium text-slate-300 hover:text-white transition"
                            :class="{ 'text-white': servicesOpen }"
                        >
                            <span>Services</span>

                            <svg
                                class="w-3 h-3 transition-transform duration-200"
                                :class="{ 'rotate-180': servicesOpen }"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M6 9l6 6 6-6"
                                />
                            </svg>
                        </button>

                        <div
                            x-show="servicesOpen"
                            x-cloak
                            x-transition:enter="transition ease-out duration-150"
                            x-transition:enter-start="opacity-0 -translate-y-2 scale-95"
                            x-transition:enter-end="opacity-100 translate-y-0 scale-100"
                            x-transition:leave="transition ease-in duration-100"
                            x-transition:leave-start="opacity-100 translate-y-0 scale-100"
                            x-transition:leave-end="opacity-0 -translate-y-2 scale-95"
                        <div
                            x-show="servicesOpen"
                            x-cloak
                            x-transition:enter="transition ease-out duration-150"
                            x-transition:enter-start="opacity-0 -translate-y-2 scale-95"
                            x-transition:enter-end="opacity-100 translate-y-0 scale-100"
                            x-transition:leave="transition ease-in duration-100"
                            x-transition:leave-start="opacity-100 translate-y-0 scale-100"
                            x-transition:leave-end="opacity-0 -translate-y-2 scale-95"
                            class="absolute left-1/2 -translate-x-1/2 top-full mt-6 w-[240px] bg-white rounded-xl shadow-xl border border-slate-100 overflow-hidden z-50 py-1"
                            style="display: none;"
                        >
                            @php
                                $topbarServiceCategories = \App\Models\ServiceCategory::where('is_active', true)->ordered()->take(5)->get();
                            @endphp
                            @forelse($topbarServiceCategories as $tsc)
                                <a
                                    href="{{ route('services.index', ['category' => $tsc->slug]) }}"
                                    class="block px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-amber-600 transition"
                                >
                                    {{ $tsc->name }}
                                </a>
                            @empty
                                <a
                                    href="{{ route('services.index') }}"
                                    class="block px-4 py-2.5 text-xs font-medium text-slate-600 hover:bg-slate-50 hover:text-amber-500 transition"
                                >
                                    Consultancy Services
                                </a>
                            @endforelse

                            <div class="border-t border-slate-100 mt-1 pt-1">
                                <a
                                    href="{{ route('services.index') }}"
                                    class="block px-4 py-2 text-xs font-black text-emerald-700 hover:bg-emerald-50 transition flex items-center justify-between"
                                >
                                    <span>Browse All Services</span>
                                    <span>&rarr;</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    {{-- For Students --}}
                    <a
                        href="https://www.reiaconsultancy.com/apply"
                        class="hover:text-white transition whitespace-nowrap"
                    >
                        For Students
                    </a>

                    {{-- Community --}}
                    <a
                        href="{{ route('community.index') }}"
                        class="text-white font-semibold relative whitespace-nowrap py-1 {{ request()->routeIs('community.index') ? '' : '' }}"
                    >
                        Community

                        <span class="absolute left-0 right-0 -bottom-1 h-0.5 bg-amber-400 rounded-full"></span>
                    </a>



                    {{-- Notices --}}
                    <a
                        href="https://www.reiaconsultancy.com/notices"
                        class="hover:text-white transition whitespace-nowrap"
                    >
                        Notices
                    </a>

                    {{-- F-2-7 Calculator --}}
                    <a
                        href="https://www.reiaconsultancy.com/visa-calculator"
                        class="hover:text-white transition whitespace-nowrap"
                    >
                        F-2-7 Points Calculator
                    </a>

                    {{-- Contact --}}
                    <a
                        href="https://www.reiaconsultancy.com/contact-us"
                        class="hover:text-white transition whitespace-nowrap"
                    >
                        Contact Us
                    </a>
                </nav>
            </div>

            {{-- RIGHT SIDE --}}
            <div class="flex items-center gap-2 sm:gap-3 shrink-0">

                @auth

                    {{-- DESKTOP NOTIFICATIONS --}}
                    <div
                        class="relative hidden sm:block"
                        x-data="{
                            notificationOpen: false,
                            notificationLoading: false,
                            notifications: {{ \Illuminate\Support\Js::from($initialNotifications) }},
                            unreadCount: {{ (int) $unreadNotificationsCount }},
                            hoverTimer: null,
                            pollingTimer: null,

                            init() {
                                this.broadcastCount();
                                this.startPolling();

                                window.addEventListener('focus', () => this.checkUnreadCount());
                                document.addEventListener('visibilitychange', () => {
                                    if (!document.hidden) {
                                        this.checkUnreadCount();
                                    }
                                });

                                window.addEventListener('refresh-notifications', () => {
                                    this.checkUnreadCount();
                                    if (this.notificationOpen) {
                                        this.loadNotifications(false);
                                    }
                                });
                            },

                            broadcastCount() {
                                window.dispatchEvent(new CustomEvent('notification-count-changed', {
                                    detail: { count: this.unreadCount }
                                }));
                            },

                            startPolling() {
                                if (this.pollingTimer) clearInterval(this.pollingTimer);
                                this.pollingTimer = setInterval(() => {
                                    if (!document.hidden) {
                                        this.checkUnreadCount();
                                    }
                                }, 20000);
                            },

                            async checkUnreadCount() {
                                try {
                                    const response = await fetch('{{ route('community.notifications.unread-count') }}', {
                                        method: 'GET',
                                        headers: {
                                            'Accept': 'application/json',
                                            'X-Requested-With': 'XMLHttpRequest'
                                        }
                                    });

                                    if (!response.ok) return;

                                    const result = await response.json();
                                    if (result.success && typeof result.unread_count !== 'undefined') {
                                        const oldCount = this.unreadCount;
                                        this.unreadCount = result.unread_count;
                                        this.broadcastCount();

                                        if (this.notificationOpen && oldCount !== result.unread_count) {
                                            this.loadNotifications(false);
                                        }
                                    }
                                } catch (e) {
                                    // background poll silent
                                }
                            },

                            openNotifications() {
                                clearTimeout(this.hoverTimer);
                                this.notificationOpen = true;
                                this.loadNotifications(false);
                            },

                            closeNotifications() {
                                clearTimeout(this.hoverTimer);

                                this.hoverTimer = setTimeout(() => {
                                    this.notificationOpen = false;
                                }, 180);
                            },

                            toggleNotifications() {
                                clearTimeout(this.hoverTimer);
                                this.notificationOpen = !this.notificationOpen;

                                if (this.notificationOpen) {
                                    this.loadNotifications(false);
                                }
                            },

                            async loadNotifications(showLoading = true) {
                                if (showLoading && this.notifications.length === 0) {
                                    this.notificationLoading = true;
                                }

                                try {
                                    const response = await fetch(
                                        '{{ route('community.notifications.data') }}',
                                        {
                                            method: 'GET',
                                            headers: {
                                                'Accept': 'application/json',
                                                'X-Requested-With': 'XMLHttpRequest'
                                            }
                                        }
                                    );

                                    if (!response.ok) {
                                        throw new Error('Unable to load notifications.');
                                    }

                                    const result = await response.json();

                                    if (result.success) {
                                        this.notifications =
                                            (result.data.notifications || []).map(n => ({
                                                ...n,
                                                actionStatus: null
                                            }));

                                        this.unreadCount =
                                            result.data.unread_count ?? 0;
                                        this.broadcastCount();
                                    }
                                } catch (error) {
                                    console.error('Notification error:', error);
                                } finally {
                                    this.notificationLoading = false;
                                }
                            },

                            async markAsRead(notification) {
                                if (notification.read) {
                                    return;
                                }

                                notification.read = true;
                                if (this.unreadCount > 0) {
                                    this.unreadCount--;
                                    this.broadcastCount();
                                }

                                try {
                                    const markReadUrl = @js(route('community.notifications.read', ['id' => '__ID__']));
                                    const response = await fetch(
                                        markReadUrl.replace('__ID__', notification.id),
                                        {
                                            method: 'PATCH',
                                            headers: {
                                                'Accept': 'application/json',
                                                'X-CSRF-TOKEN':
                                                    document.querySelector('meta[name=csrf-token]')?.getAttribute('content'),
                                                'X-Requested-With': 'XMLHttpRequest'
                                            }
                                        }
                                    );

                                    if (response.ok) {
                                        const result = await response.json();
                                        if (result.success && result.data && typeof result.data.unread_count !== 'undefined') {
                                            this.unreadCount = result.data.unread_count;
                                            this.broadcastCount();
                                        }
                                    }
                                } catch (error) {
                                    console.error('Read notification error:', error);
                                }
                            },

                            async openNotification(notification) {
                                await this.markAsRead(notification);

                                const data = notification.data || {};
                                const type = (data.type || notification.type || '').toLowerCase();

                                // Do not redirect for group invitations or requests; user uses Accept/Reject buttons
                                if (type.includes('group_invitation') || type.includes('groupinvitation') || type.includes('group_join') || type.includes('joinrequest')) {
                                    return;
                                }

                                if (data.url) {
                                    let cleanUrl = data.url.replace('/reaic/', '/community/').replace('/community/community/', '/community/');
                                    if ((type.includes('new_test') || type.includes('newtest') || cleanUrl.includes('/tests/student/')) && data.test_id) {
                                        cleanUrl = @js(route('tests.student.show', ['test' => '__TEST_ID__'])).replace('__TEST_ID__', data.test_id);
                                    } else if ((type.includes('follow') || cleanUrl.includes('/profile/')) && data.username) {
                                        cleanUrl = @js(route('community.profile', ['username' => '__USERNAME__'])).replace('__USERNAME__', data.username);
                                    } else {
                                        try {
                                            if (cleanUrl.startsWith('http://') || cleanUrl.startsWith('https://')) {
                                                const urlObj = new URL(cleanUrl);
                                                cleanUrl = window.location.origin + urlObj.pathname + urlObj.search + urlObj.hash;
                                            }
                                        } catch (e) {}
                                    }
                                    this.notificationOpen = false;
                                    window.location.href = cleanUrl;
                                    return;
                                }

                                if (data.post_id) {
                                    this.notificationOpen = false;
                                    const postUrl = @js(route('community.posts.show', ['post' => '__POST_ID__']));
                                    window.location.href = postUrl.replace('__POST_ID__', data.post_id);
                                    return;
                                }
                            },

                            async markAllAsRead() {
                                this.notifications =
                                    this.notifications.map(notification => ({
                                        ...notification,
                                        read: true
                                    }));

                                this.unreadCount = 0;
                                this.broadcastCount();

                                try {
                                    const response = await fetch(
                                        '{{ route('community.notifications.read-all') }}',
                                        {
                                            method: 'PATCH',
                                            headers: {
                                                'Accept': 'application/json',
                                                'X-CSRF-TOKEN':
                                                    document.querySelector('meta[name=csrf-token]')?.getAttribute('content'),
                                                'X-Requested-With': 'XMLHttpRequest'
                                            }
                                        }
                                    );

                                    if (!response.ok) {
                                        throw new Error('Unable to mark notifications as read.');
                                    }

                                    const result = await response.json();

                                    if (result.success && result.data && typeof result.data.unread_count !== 'undefined') {
                                        this.unreadCount = result.data.unread_count;
                                        this.broadcastCount();
                                    }
                                } catch (error) {
                                    console.error('Mark all notification error:', error);
                                }
                            },

                            async handleGroupRequest(notification, action) {
                                const data = notification.data || {};
                                const groupSlug = data.group_slug || (data.url ? data.url.split('/').filter(Boolean).pop() : null);
                                const userId = data.user_id;

                                if (!groupSlug || !userId) {
                                    alert('Group or user information not found.');
                                    return;
                                }

                                const acceptUrl = @js(route('community.groups.requests.accept', ['group' => '__GROUP__', 'userToAccept' => '__USER__']));
                                const rejectUrl = @js(route('community.groups.requests.reject', ['group' => '__GROUP__', 'userToReject' => '__USER__']));
                                const endpoint = (action === 'accept' ? acceptUrl : rejectUrl)
                                    .replace('__GROUP__', encodeURIComponent(groupSlug))
                                    .replace('__USER__', encodeURIComponent(userId));

                                try {
                                    const response = await fetch(endpoint, {
                                        method: 'POST',
                                        headers: {
                                            'X-CSRF-TOKEN':
                                                document.querySelector('meta[name=csrf-token]')?.getAttribute('content'),
                                            'Accept': 'application/json',
                                            'Content-Type': 'application/json',
                                            'X-Requested-With': 'XMLHttpRequest'
                                        }
                                    });

                                    const result = await response.json();

                                    if (!response.ok || result.success === false) {
                                        alert(result.message || 'Something went wrong.');
                                        return;
                                    }

                                    notification.actionStatus =
                                        action === 'accept' ? 'accepted' : 'rejected';

                                    if (notification.data) {
                                        notification.data.status = notification.actionStatus;
                                    }

                                    if (!notification.read) {
                                        notification.read = true;
                                        if (this.unreadCount > 0) {
                                            this.unreadCount--;
                                            this.broadcastCount();
                                        }
                                    }

                                } catch (error) {
                                    console.error('Group request error:', error);
                                    alert('Something went wrong.');
                                }
                            },

                            async handleGroupInvitation(notification, action) {
                                const data = notification.data || {};
                                const groupSlug = data.group_slug || (data.url ? data.url.split('/').filter(Boolean).pop() : null);

                                if (!groupSlug) {
                                    alert('Group information not found.');
                                    return;
                                }

                                const acceptUrl = @js(route('community.groups.invitation.accept', ['group' => '__GROUP__']));
                                const rejectUrl = @js(route('community.groups.invitation.reject', ['group' => '__GROUP__']));
                                const endpoint = (action === 'accept' ? acceptUrl : rejectUrl)
                                    .replace('__GROUP__', encodeURIComponent(groupSlug));

                                try {
                                    const response = await fetch(endpoint, {
                                        method: 'POST',
                                        headers: {
                                            'X-CSRF-TOKEN':
                                                document.querySelector('meta[name=csrf-token]')?.getAttribute('content'),
                                            'Accept': 'application/json',
                                            'Content-Type': 'application/json',
                                            'X-Requested-With': 'XMLHttpRequest'
                                        }
                                    });

                                    const result = await response.json();

                                    if (!response.ok || result.success === false) {
                                        alert(result.message || 'Something went wrong.');
                                        return;
                                    }

                                    notification.actionStatus =
                                        action === 'accept' ? 'accepted' : 'rejected';

                                    if (notification.data) {
                                        notification.data.status = notification.actionStatus;
                                    }

                                    if (!notification.read) {
                                        notification.read = true;
                                        if (this.unreadCount > 0) {
                                            this.unreadCount--;
                                            this.broadcastCount();
                                        }
                                    }
                                } catch (error) {
                                    console.error('Group invitation error:', error);
                                    alert('Something went wrong.');
                                }
                            }
                        }"
                        @notification-count-changed.window="if ($event.detail.count !== unreadCount) unreadCount = $event.detail.count"
                        @click.outside="notificationOpen = false"
                        @mouseenter="openNotifications()"
                        @mouseleave="closeNotifications()"
                    >
                        {{-- Bell --}}
                        <button
                            type="button"
                            @click.prevent.stop="toggleNotifications()"
                            class="relative w-9 h-9 rounded-full bg-[#1e293b] flex items-center justify-center text-slate-300 hover:text-white hover:bg-[#263449] transition focus:outline-none"
                            aria-label="Notifications"
                            :aria-expanded="notificationOpen"
                        >
                            <svg
                                class="w-4 h-4"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2.5"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 1 0-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 1 1-6 0v-1m6 0H9"
                                />
                            </svg>

                            <span
                                x-show="unreadCount > 0"
                                x-transition
                                x-text="unreadCount > 99 ? '99+' : unreadCount"
                                class="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 bg-amber-400 text-slate-950 font-bold text-[8px] rounded-full flex items-center justify-center border-2 border-[#0b1329]"
                                style="{{ $unreadNotificationsCount > 0 ? '' : 'display: none;' }}"
                            >{{ $unreadNotificationsCount > 99 ? '99+' : $unreadNotificationsCount }}</span>
                        </button>

                        {{-- Notification Dropdown --}}
                        <div
                            x-show="notificationOpen"
                            x-cloak
                            x-transition:enter="transition ease-out duration-150"
                            x-transition:enter-start="opacity-0 scale-95 -translate-y-2"
                            x-transition:enter-end="opacity-100 scale-100 translate-y-0"
                            x-transition:leave="transition ease-in duration-100"
                            x-transition:leave-start="opacity-100 scale-100 translate-y-0"
                            x-transition:leave-end="opacity-0 scale-95 -translate-y-2"
                            @mouseenter="clearTimeout(hoverTimer)"
                            @mouseleave="closeNotifications()"
                            class="absolute right-0 top-11 w-[380px] max-w-[calc(100vw-2rem)] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-[9999]"
                            style="display: none;"
                        >
                            <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                                <div>
                                    <h3 class="text-sm font-bold text-slate-900">
                                        Notifications
                                    </h3>

                                    <p
                                        class="text-[11px] text-slate-400 mt-1"
                                        x-text="
                                            unreadCount > 0
                                                ? unreadCount + ' unread notification' + (unreadCount === 1 ? '' : 's')
                                                : 'You are all caught up'
                                        "
                                    ></p>
                                </div>

                                <div class="flex items-center gap-3">
                                    <button
                                        type="button"
                                        x-show="unreadCount > 0"
                                        @click.prevent.stop="markAllAsRead()"
                                        class="text-[11px] font-semibold text-amber-500 hover:text-amber-600 transition"
                                    >
                                        Mark all as read
                                    </button>

                                    @if (!request()->routeIs('community.notifications*'))
                                        <a
                                            href="{{ route('community.notifications') }}"
                                            class="text-[11px] font-bold text-slate-700 hover:text-amber-600 transition"
                                        >
                                            View all
                                        </a>
                                    @endif
                                </div>
                            </div>

                            <div x-show="notificationLoading && notifications.length === 0" class="px-5 py-10 text-center">
                                <svg class="w-5 h-5 animate-spin mx-auto text-amber-500" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" />
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v3a5 5 0 00-5 5H4z" />
                                </svg>

                                <p class="text-xs text-slate-400 mt-2">
                                    Loading notifications...
                                </p>
                            </div>

                            <div x-show="!notificationLoading || notifications.length > 0" class="max-h-[420px] overflow-y-auto">

                                <template x-for="notification in notifications" :key="notification.id">
                                    <div
                                        class="w-full text-left px-5 py-4 border-b border-slate-100 hover:bg-slate-50 transition"
                                        :class="notification.read ? 'bg-white' : 'bg-amber-50/70'"
                                    >
                                        <div
                                            class="flex items-start gap-3 cursor-pointer"
                                            @click="openNotification(notification)"
                                        >
                                            <div
                                                class="w-9 h-9 rounded-full shrink-0 flex items-center justify-center"
                                                :class="notification.read ? 'bg-slate-100 text-slate-400' : ((notification.data?.type || '').includes('like') || (notification.title || '').toLowerCase().includes('like') ? 'bg-rose-100 text-rose-500' : ((notification.data?.type || '').includes('reply') || (notification.title || '').toLowerCase().includes('reply') ? 'bg-purple-100 text-purple-600' : ((notification.data?.type || '').includes('comment') || (notification.title || '').toLowerCase().includes('comment') ? 'bg-blue-100 text-blue-600' : ((notification.data?.type || '').includes('follow') || (notification.title || '').toLowerCase().includes('follow') ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'))))"
                                            >
                                                <template x-if="(notification.data?.type || '').includes('like') || (notification.title || '').toLowerCase().includes('like')">
                                                    <svg class="w-4 h-4 text-rose-500" fill="currentColor" viewBox="0 0 24 24">
                                                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                                                    </svg>
                                                </template>
                                                <template x-if="!((notification.data?.type || '').includes('like') || (notification.title || '').toLowerCase().includes('like')) && ((notification.data?.type || '').includes('reply') || (notification.title || '').toLowerCase().includes('reply'))">
                                                    <svg class="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"/>
                                                    </svg>
                                                </template>
                                                <template x-if="!((notification.data?.type || '').includes('like') || (notification.title || '').toLowerCase().includes('like')) && !((notification.data?.type || '').includes('reply') || (notification.title || '').toLowerCase().includes('reply')) && ((notification.data?.type || '').includes('comment') || (notification.title || '').toLowerCase().includes('comment'))">
                                                    <svg class="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M8 10h8M8 14h5m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                                    </svg>
                                                </template>
                                                <template x-if="!((notification.data?.type || '').includes('like') || (notification.title || '').toLowerCase().includes('like')) && !((notification.data?.type || '').includes('reply') || (notification.title || '').toLowerCase().includes('reply')) && !((notification.data?.type || '').includes('comment') || (notification.title || '').toLowerCase().includes('comment')) && ((notification.data?.type || '').includes('follow') || (notification.title || '').toLowerCase().includes('follow'))">
                                                    <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                                                    </svg>
                                                </template>
                                                <template x-if="!((notification.data?.type || '').includes('like') || (notification.title || '').toLowerCase().includes('like')) && !((notification.data?.type || '').includes('reply') || (notification.title || '').toLowerCase().includes('reply')) && !((notification.data?.type || '').includes('comment') || (notification.title || '').toLowerCase().includes('comment')) && !((notification.data?.type || '').includes('follow') || (notification.title || '').toLowerCase().includes('follow'))">
                                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 1 0-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 1 1-6 0v-1m6 0H9"
                                                        />
                                                    </svg>
                                                </template>
                                            </div>

                                            <div class="flex-1 min-w-0">
                                                <div class="flex items-center gap-1.5 mb-0.5">
                                                    <span
                                                        class="text-xs font-bold text-slate-900 truncate"
                                                        x-text="notification.title || 'Notification'"
                                                    ></span>
                                                    <span
                                                        x-show="!notification.read"
                                                        class="px-1.5 py-0.5 bg-amber-500 text-white font-bold text-[9px] rounded-full"
                                                    >
                                                        Unread
                                                    </span>
                                                </div>

                                                <p
                                                    class="text-xs text-slate-700 leading-snug"
                                                    :class="notification.read ? 'font-normal' : 'font-medium'"
                                                    x-text="notification.message || notification.data?.message"
                                                ></p>

                                                <p
                                                    class="text-[10px] text-slate-400 mt-1"
                                                    x-text="notification.created_at"
                                                ></p>
                                            </div>

                                            <span
                                                x-show="!notification.read"
                                                class="w-2 h-2 rounded-full bg-amber-500 mt-2 shrink-0"
                                            ></span>
                                        </div>

                                        {{-- Group Join Request Actions --}}
                                        <template x-if="notification.data && notification.data.type === 'group_join_requested'">
                                            <div class="mt-2 ml-12">
                                                <template x-if="notification.data.status === 'accepted' || notification.data.status === 'active' || notification.actionStatus === 'accepted'">
                                                    <span class="inline-flex items-center text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200 text-[10px] font-semibold">
                                                        Accepted
                                                    </span>
                                                </template>

                                                <template x-if="notification.data.status === 'rejected' || notification.actionStatus === 'rejected'">
                                                    <span class="inline-flex items-center text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded border border-rose-200 text-[10px] font-semibold">
                                                        Rejected
                                                    </span>
                                                </template>

                                                <template x-if="(!notification.data.status || notification.data.status === 'pending') && !notification.actionStatus">
                                                    <div class="flex items-center gap-2">
                                                        <button
                                                            type="button"
                                                            @click.prevent.stop="handleGroupRequest(notification, 'accept')"
                                                            class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold rounded-lg transition shadow-sm"
                                                        >
                                                            Accept
                                                        </button>

                                                        <button
                                                            type="button"
                                                            @click.prevent.stop="handleGroupRequest(notification, 'reject')"
                                                            class="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-semibold rounded-lg transition shadow-sm"
                                                        >
                                                            Reject
                                                        </button>
                                                    </div>
                                                </template>
                                            </div>
                                        </template>

                                        {{-- Group Invitation Actions --}}
                                        <template x-if="notification.data && notification.data.type === 'group_invitation'">
                                            <div class="mt-2 ml-12">
                                                <template x-if="notification.data.status === 'accepted' || notification.actionStatus === 'accepted'">
                                                    <span class="inline-flex items-center text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200 text-[10px] font-semibold">
                                                        Accepted
                                                    </span>
                                                </template>

                                                <template x-if="notification.data.status === 'rejected' || notification.actionStatus === 'rejected'">
                                                    <span class="inline-flex items-center text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded border border-rose-200 text-[10px] font-semibold">
                                                        Rejected
                                                    </span>
                                                </template>

                                                <template x-if="(!notification.data.status || notification.data.status === 'pending') && !notification.actionStatus">
                                                    <div class="flex items-center gap-2">
                                                        <button
                                                            type="button"
                                                            @click.prevent.stop="handleGroupInvitation(notification, 'accept')"
                                                            class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold rounded-lg transition shadow-sm"
                                                        >
                                                            Accept
                                                        </button>

                                                        <button
                                                            type="button"
                                                            @click.prevent.stop="handleGroupInvitation(notification, 'reject')"
                                                            class="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-semibold rounded-lg transition shadow-sm"
                                                        >
                                                            Reject
                                                        </button>
                                                    </div>
                                                </template>
                                            </div>
                                        </template>
                                    </div>
                                </template>

                                <div
                                    x-show="!notificationLoading && notifications.length === 0"
                                    class="px-5 py-10 text-center"
                                >
                                    <div class="w-11 h-11 mx-auto rounded-full bg-slate-50 flex items-center justify-center">
                                        <svg class="w-5 h-5 text-slate-300" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 1 0-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 1 1-6 0v-1m6 0H9"
                                            />
                                        </svg>
                                    </div>

                                    <p class="text-xs font-semibold text-slate-500 mt-3">
                                        You're all caught up
                                    </p>

                                    <p class="text-[10px] text-slate-400 mt-1">
                                        New activity will appear here.
                                    </p>
                                </div>
                            </div>

                            @if (!request()->routeIs('community.notifications*'))
                                {{-- Footer View All Button --}}
                                <div class="p-3 bg-slate-50 border-t border-slate-100">
                                    <a
                                        href="{{ route('community.notifications') }}"
                                        class="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 border border-slate-200/80 text-xs font-bold text-slate-800 hover:text-amber-600 shadow-xs transition"
                                    >
                                        <span>View all notifications</span>
                                        <svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"/>
                                        </svg>
                                    </a>
                                </div>
                            @endif
                        </div>
                    </div>

                    {{-- PROFILE DROPDOWN --}}
                    <div
                        class="relative flex items-center"
                        x-data="{ profileDropdownOpen: false }"
                    >
                        <button
                            @click="profileDropdownOpen = !profileDropdownOpen"
                            @click.outside="profileDropdownOpen = false"
                            type="button"
                            class="relative flex items-center justify-center focus:outline-none group cursor-pointer"
                            aria-label="My profile"
                        >
                            <div class="relative w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#1e293b] ring-2 ring-amber-400 group-hover:ring-white transition shadow-xs flex items-center justify-center shrink-0">
                                <img
                                    src="{{ $topbarAvatar }}"
                                    alt="{{ $userName }}"
                                    class="w-full h-full rounded-full object-cover block"
                                    onerror="this.onerror=null; this.src='{{ $defaultAvatar }}';"
                                >

                                @if ($topbarIsoCode)
                                    <span
                                        class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full border-[1.5px] border-[#0b1329] shadow-xs overflow-hidden bg-white flex items-center justify-center shrink-0 z-10"
                                        title="{{ $topbarCountry?->name ?? 'Country' }}"
                                    >
                                        <img
                                            src="https://flagcdn.com/w40/{{ $topbarIsoCode }}.png"
                                            alt="{{ $topbarCountry?->name ?? 'Country' }}"
                                            class="w-full h-full object-cover rounded-full"
                                            loading="lazy"
                                            onerror="this.style.display='none'"
                                        >
                                    </span>
                                @elseif (!empty($topbarCountry?->flag) && (str_starts_with($topbarCountry->flag, 'http://') || str_starts_with($topbarCountry->flag, 'https://')))
                                    <span
                                        class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full border-[1.5px] border-[#0b1329] shadow-xs overflow-hidden bg-white flex items-center justify-center shrink-0 z-10"
                                        title="{{ $topbarCountry?->name ?? 'Country' }}"
                                    >
                                        <img
                                            src="{{ $topbarCountry->flag }}"
                                            alt="{{ $topbarCountry?->name ?? 'Country' }}"
                                            class="w-full h-full object-cover rounded-full"
                                            loading="lazy"
                                            onerror="this.style.display='none'"
                                        >
                                    </span>
                                @elseif (!empty($topbarCountry?->flag))
                                    <span
                                        class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full border-[1.5px] border-[#0b1329] shadow-xs overflow-hidden bg-white flex items-center justify-center text-[8px] sm:text-[9px] shrink-0 leading-none z-10"
                                        title="{{ $topbarCountry?->name ?? 'Country' }}"
                                    >
                                        {{ $topbarCountry->flag }}
                                    </span>
                                @else
                                    <span
                                        class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#0b1329] z-10"
                                    ></span>
                                @endif
                            </div>
                        </button>

                        <div
                            x-show="profileDropdownOpen"
                            x-cloak
                            x-transition:enter="transition ease-out duration-150"
                            x-transition:enter-start="opacity-0 scale-95 -translate-y-2"
                            x-transition:enter-end="opacity-100 scale-100 translate-y-0"
                            x-transition:leave="transition ease-in duration-100"
                            x-transition:leave-start="opacity-100 scale-100 translate-y-0"
                            x-transition:leave-end="opacity-0 scale-95 -translate-y-2"
                            class="absolute right-0 top-11 w-56 bg-white rounded-2xl shadow-2xl border border-slate-100 py-1.5 z-[9999] text-slate-700"
                            style="display: none;"
                        >
                            <div class="px-4 py-2 border-b border-slate-100">
                                <p class="text-xs font-bold text-slate-900 truncate">
                                    {{ $authUser?->name ?? 'User' }}
                                </p>

                                <p class="text-[11px] text-slate-400 truncate">
                                    {{ $topbarProfile?->username ? '@' . $topbarProfile->username : 'no-handle' }}
                                </p>
                            </div>

                            @if ($authUser?->role instanceof \App\Enums\UserRole)
                                @if ($authUser->role->value === 'admin')
                                    <a
                                        href="{{ route('admin.dashboard') }}"
                                        class="flex items-center gap-3 px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 transition"
                                    >
                                        <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 13h8V3H3v10zm10 8h8V11h-8v10zM3 21h8v-6H3v6zm10-18v6h8V3h-8z" />
                                        </svg>
                                        <span>Admin Dashboard</span>
                                    </a>
                                @endif
                            @endif

                            <a
                                href="{{ $topbarProfile?->username ? route('community.profile', $topbarProfile->username) : route('community.profile.me') }}"
                                class="flex items-center px-4 py-2.5 text-xs font-semibold hover:bg-slate-50 transition text-slate-700"
                            >
                                <svg class="w-4 h-4 mr-2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
                                </svg>
                                View Profile
                            </a>

                            <a
                                href="{{ route('community.saved') }}"
                                class="flex items-center px-4 py-2.5 text-xs font-semibold hover:bg-slate-50 transition text-slate-700"
                            >
                                <svg class="w-4 h-4 mr-2 text-slate-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                </svg>
                                Saved Posts
                            </a>

                            <div class="border-t border-slate-100 my-1"></div>

                            <form method="POST" action="{{ route('logout') }}">
                                @csrf

                                <button
                                    type="submit"
                                    class="w-full flex items-center px-4 py-2.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 transition text-left"
                                >
                                    <svg class="w-4 h-4 mr-2 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                    </svg>
                                    Logout
                                </button>
                            </form>
                        </div>
                    </div>

                @else

                    {{-- GUEST LOGIN --}}
                    <a
                        href="{{ route('login') }}"
                        class="flex items-center justify-center px-3 sm:px-4 h-8 sm:h-9 rounded-lg bg-amber-400 text-slate-950 text-xs font-bold hover:bg-amber-500 transition whitespace-nowrap"
                    >
                      Community Login
                    </a>

                @endauth

                <!--
                <div class="language-switcher">
                    <button type="button" class="language-btn" onclick="changeLanguage('en', this)">EN</button>
                    <button type="button" class="language-btn" onclick="changeLanguage('ko', this)">한국어</button>
                </div>
                <div id="google_translate_element"></div>
                -->

            </div>
        </div>
    </div>

    {{-- MOBILE MENU --}}
    <div
        x-show="mobileMenuOpen"
        x-cloak
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 -translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 translate-y-0"
        x-transition:leave-end="opacity-0 -translate-y-2"
        class="lg:hidden border-t border-white/10 bg-[#0b1329]"
        style="display: none;"
    >
        <nav class="max-w-[1520px] mx-auto px-4 sm:px-6 py-4 space-y-1">

            {{-- Home --}}
            <a
                href="https://www.reiaconsultancy.com/"
                @click="mobileMenuOpen = false"
                class="flex items-center px-3 py-3 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 transition"
            >
                Home
            </a>

            {{-- About Us --}}
            <a
                href="https://www.reiaconsultancy.com/about-us"
                @click="mobileMenuOpen = false"
                class="flex items-center px-3 py-3 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 transition"
            >
                About Us
            </a>

            {{-- Services --}}
            <div x-data="{ mobileServicesOpen: false }">

                <button
                    type="button"
                    @click="mobileServicesOpen = !mobileServicesOpen"
                    class="w-full flex items-center justify-between px-3 py-3 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 transition"
                >
                    <span>Services</span>

                    <svg
                        class="w-4 h-4 transition-transform duration-200"
                        :class="{ 'rotate-180': mobileServicesOpen }"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M19 9l-7 7-7-7"
                        />
                    </svg>
                </button>

                <div
                    x-show="mobileServicesOpen"
                    x-cloak
                    x-transition
                    class="ml-3 mt-1 pl-3 border-l border-white/10 space-y-1"
                >
                    <a
                        href="https://www.reiaconsultancy.com/services/university-admissions"
                        @click="mobileMenuOpen = false"
                        class="block px-3 py-2.5 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-white/5 transition"
                    >
                        University Admissions
                    </a>

                    <a
                        href="https://www.reiaconsultancy.com/services/visa-documentation"
                        @click="mobileMenuOpen = false"
                        class="block px-3 py-2.5 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-white/5 transition"
                    >
                        Visa & Documentation
                    </a>

                    <a
                        href="https://www.reiaconsultancy.com/services/institutional-partnerships"
                        @click="mobileMenuOpen = false"
                        class="block px-3 py-2.5 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-white/5 transition"
                    >
                        Institutional Partnerships
                    </a>

                    <a
                        href="https://www.reiaconsultancy.com/services/career-counseling"
                        @click="mobileMenuOpen = false"
                        class="block px-3 py-2.5 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-white/5 transition"
                    >
                        Career Counseling
                    </a>
                </div>
            </div>

            {{-- For Students --}}
            <a
                href="https://www.reiaconsultancy.com/apply"
                @click="mobileMenuOpen = false"
                class="flex items-center px-3 py-3 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 transition"
            >
                For Students
            </a>

            {{-- Community --}}
            <a
                href="{{ route('community.index') }}"
                @click="mobileMenuOpen = false"
                class="flex items-center px-3 py-3 rounded-xl text-sm font-semibold text-white bg-white/10"
            >
                <span class="w-1.5 h-1.5 rounded-full bg-amber-400 mr-3"></span>
                Community
            </a>



            {{-- Notices --}}
            <a
                href="https://www.reiaconsultancy.com/notices"
                @click="mobileMenuOpen = false"
                class="flex items-center px-3 py-3 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 transition"
            >
                Notices
            </a>

            {{-- F-2-7 Points Calculator --}}
            <a
                href="https://www.reiaconsultancy.com/visa-calculator"
                @click="mobileMenuOpen = false"
                class="flex items-center px-3 py-3 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 transition"
            >
                F-2-7 Points Calculator
            </a>

            {{-- Contact Us --}}
            <a
                href="https://www.reiaconsultancy.com/contact-us"
                @click="mobileMenuOpen = false"
                class="flex items-center px-3 py-3 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 transition"
            >
                Contact Us
            </a>

            {{-- MOBILE AUTH --}}
            @auth

                <div class="pt-3 mt-3 border-t border-white/15 space-y-3">

                    {{-- User --}}
                    <a
                        href="{{ $topbarProfile?->username ? route('community.profile', $topbarProfile->username) : route('community.profile.me') }}"
                        @click="mobileMenuOpen = false"
                        class="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-white/5 transition group"
                    >
                        <div class="relative w-10 h-10 rounded-full bg-[#1e293b] ring-2 ring-amber-400 flex items-center justify-center shrink-0">
                            <img
                                src="{{ $topbarAvatar }}"
                                alt="{{ $userName }}"
                                class="w-full h-full rounded-full object-cover block"
                                onerror="this.onerror=null; this.src='{{ $defaultAvatar }}';"
                            >

                            @if ($topbarIsoCode)
                                <span
                                    class="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-[1.5px] border-[#0b1329] shadow-xs overflow-hidden bg-white flex items-center justify-center shrink-0"
                                    title="{{ $topbarCountry->name }}"
                                >
                                    <img
                                        src="https://flagcdn.com/w40/{{ $topbarIsoCode }}.png"
                                        alt="{{ $topbarCountry->name }}"
                                        class="w-full h-full object-cover rounded-full"
                                        loading="lazy"
                                        onerror="this.style.display='none'"
                                    >
                                </span>
                            @elseif (!empty($topbarCountry?->flag) && (str_starts_with($topbarCountry->flag, 'http://') || str_starts_with($topbarCountry->flag, 'https://')))
                                <span
                                    class="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-[1.5px] border-[#0b1329] shadow-xs overflow-hidden bg-white flex items-center justify-center shrink-0"
                                    title="{{ $topbarCountry->name }}"
                                >
                                    <img
                                        src="{{ $topbarCountry->flag }}"
                                        alt="{{ $topbarCountry->name }}"
                                        class="w-full h-full object-cover rounded-full"
                                        loading="lazy"
                                        onerror="this.style.display='none'"
                                    >
                                </span>
                            @elseif (!empty($topbarCountry?->flag))
                                <span
                                    class="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-[1.5px] border-[#0b1329] shadow-xs overflow-hidden bg-white flex items-center justify-center text-[10px] shrink-0 leading-none"
                                    title="{{ $topbarCountry->name }}"
                                >
                                    {{ $topbarCountry->flag }}
                                </span>
                            @else
                                <span
                                    class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#0b1329]"
                                ></span>
                            @endif
                        </div>

                        <div class="min-w-0">
                            <p class="text-sm font-semibold text-white group-hover:text-amber-400 transition truncate">
                                {{ $authUser?->name ?? 'User' }}
                            </p>

                            @if ($topbarProfile?->username)
                                <p class="text-xs text-slate-400 truncate">
                                    {{ '@' . $topbarProfile->username }}
                                </p>
                            @endif
                        </div>
                    </a>

                    {{-- Admin Dashboard --}}
                    @if ($authUser?->role instanceof \App\Enums\UserRole)
                        @if ($authUser->role->value === 'admin')
                            <a
                                href="{{ route('admin.dashboard') }}"
                                @click="mobileMenuOpen = false"
                                class="flex items-center px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/10 transition"
                            >
                                <svg class="w-4 h-4 mr-2.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 13h8V3H3v10zm10 8h8V11h-8v10zM3 21h8v-6H3v6zm10-18v6h8V3h-8z" />
                                </svg>
                                Admin Dashboard
                            </a>
                        @endif
                    @endif

                    {{-- View Profile --}}
                    <a
                        href="{{ $topbarProfile?->username ? route('community.profile', $topbarProfile->username) : route('community.profile.me') }}"
                        @click="mobileMenuOpen = false"
                        class="flex items-center px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/10 transition"
                    >
                        <svg class="w-4 h-4 mr-2.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
                        </svg>
                        View Profile
                    </a>

                    {{-- Logout --}}
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf

                        <button
                            type="submit"
                            class="w-full flex items-center px-3 py-2.5 rounded-xl text-xs font-semibold text-rose-400 hover:bg-rose-500/10 transition text-left"
                        >
                            <svg class="w-4 h-4 mr-2.5 text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                            </svg>
                            Logout
                        </button>
                    </form>

                </div>

            @else

                {{-- Guest Login --}}
                <div class="pt-3 mt-3 border-t border-white/10 px-3">
                    <a
                        href="{{ route('login') }}"
                        @click="mobileMenuOpen = false"
                        class="flex items-center justify-center w-full py-2.5 rounded-xl bg-amber-400 text-slate-950 text-xs font-bold hover:bg-amber-500 transition"
                    >
                        Community Login
                    </a>
                </div>

            @endauth

        </nav>
    </div>
</header>

{{-- MOBILE BOTTOM NAVIGATION --}}
<div
    x-data="{}"
    class="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200/80 lg:hidden px-3 pt-2 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))] z-50 flex items-center justify-between shadow-[0_-4px_20px_rgba(0,0,0,0.06)]"
>
    {{-- Groups --}}
    <a
        href="{{ auth()->check() ? route('community.groups.index') : route('login') }}"
        class="flex flex-1 flex-col items-center justify-center gap-1 py-1 transition touch-manipulation {{ request()->routeIs('community.groups.*') ? 'text-[#0b1329] font-bold' : 'text-slate-400 hover:text-slate-600 font-medium' }}"
    >
        <svg class="h-5 w-5 pointer-events-none" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a4 4 0 00-4-4h-1" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 20H4v-2a4 4 0 014-4h1" />
            <circle cx="9" cy="7" r="4" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 3.5a4 4 0 010 7" />
        </svg>

        <span class="text-[10px] tracking-tight pointer-events-none">
            Groups
        </span>
    </a>

    {{-- Community --}}
    <a
        href="{{ route('community.index') }}"
        class="flex flex-1 flex-col items-center justify-center gap-1 py-1 transition touch-manipulation {{ request()->routeIs('community.index') ? 'text-[#0b1329] font-bold' : 'text-slate-400 hover:text-slate-600 font-medium' }}"
    >
        <svg class="w-5 h-5 pointer-events-none" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
        </svg>

        <span class="text-[10px] tracking-tight pointer-events-none">
            Community
        </span>
    </a>

    {{-- Create --}}
    <div class="flex flex-1 flex-col items-center justify-center">
        <button
            type="button"
            @click="$dispatch('{{ auth()->check() ? 'open-post-modal' : 'open-login-modal' }}')"
            onclick="window.dispatchEvent(new CustomEvent('{{ auth()->check() ? 'open-post-modal' : 'open-login-modal' }}'))"
            class="group relative -top-4 w-12 h-12 bg-[#0b1329] hover:bg-[#162247] rounded-full flex items-center justify-center text-white shadow-xl shadow-slate-900/20 border-4 border-white transition transform active:scale-95 touch-manipulation cursor-pointer"
        >
            <svg
                class="w-6 h-6 transition-transform group-hover:rotate-90 duration-300 pointer-events-none"
                fill="none"
                stroke="currentColor"
                stroke-width="2.5"
                viewBox="0 0 24 24"
            >
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" />
            </svg>
        </button>

        <span class="text-[10px] font-semibold text-slate-700 -mt-2 pointer-events-none">
            Create
        </span>
    </div>

    {{-- Notifications / Alerts (Direct Route) --}}
    <a
        href="{{ auth()->check() ? route('community.notifications') : route('login') }}"
        class="flex flex-1 flex-col items-center justify-center gap-1 py-1 transition relative w-full touch-manipulation {{ request()->routeIs('community.notifications*') ? 'text-[#0b1329] font-bold' : 'text-slate-400 hover:text-slate-600 font-medium' }}"
    >
        <div
            class="relative pointer-events-none"
            x-data="{ count: {{ (int) $unreadNotificationsCount }} }"
            @notification-count-changed.window="count = $event.detail.count"
        >
            <svg class="w-5 h-5 pointer-events-none" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 1 0-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 1 1-6 0v-1m6 0H9"
                />
            </svg>

            @auth
                <span
                    x-show="count > 0"
                    x-transition
                    x-text="count > 99 ? '99+' : count"
                    class="absolute -top-1.5 -right-2.5 bg-amber-500 text-slate-950 text-[9px] min-w-[16px] h-4 px-1 rounded-full flex items-center justify-center font-bold border border-white"
                    style="{{ $unreadNotificationsCount > 0 ? '' : 'display: none;' }}"
                >
                    {{ $unreadNotificationsCount > 99 ? '99+' : $unreadNotificationsCount }}
                </span>
            @endauth
        </div>

        <span class="text-[10px] tracking-tight pointer-events-none">
            Alerts
        </span>
    </a>

    {{-- Profile / Login --}}
    @auth
        <a
            href="{{ $topbarProfile?->username ? route('community.profile', $topbarProfile->username) : route('community.profile.me') }}"
            class="flex flex-1 flex-col items-center justify-center gap-1 py-1 transition touch-manipulation {{ request()->routeIs('community.profile*') ? 'text-[#0b1329] font-bold' : 'text-slate-400 hover:text-slate-600 font-medium' }}"
        >
            <div class="relative w-5 h-5 rounded-full flex items-center justify-center shrink-0 pointer-events-none {{ request()->routeIs('community.profile*') ? 'ring-2 ring-[#0b1329] ring-offset-1' : 'ring-1 ring-slate-300' }}">
                <img
                    src="{{ $topbarAvatar }}"
                    alt="{{ $userName }}"
                    class="w-full h-full rounded-full object-cover"
                    onerror="this.onerror=null; this.src='{{ $defaultAvatar }}';"
                >
                @if ($topbarIsoCode)
                    <span class="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full overflow-hidden border border-white flex items-center justify-center bg-white shrink-0">
                        <img src="https://flagcdn.com/w40/{{ $topbarIsoCode }}.png" alt="" class="w-full h-full object-cover rounded-full">
                    </span>
                @endif
            </div>

            <span class="text-[10px] tracking-tight pointer-events-none">
                Profile
            </span>
        </a>
    @else
        <a
            href="{{ route('login') }}"
            class="flex flex-1 flex-col items-center justify-center gap-1 py-1 text-slate-400 hover:text-slate-600 font-medium touch-manipulation"
        >
            <svg class="w-5 h-5 pointer-events-none" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"
                />
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M10 17l5-5-5-5"
                />
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M15 12H3"
                />
            </svg>

            <span class="text-[10px] tracking-tight pointer-events-none">
                Community Login
            </span>
        </a>
    @endauth

    <script>
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ko',
                autoDisplay: false
            }, 'google_translate_element');
        }

        function triggerTranslate(lang) {
            const combo = document.querySelector('.goog-te-combo');
            if (!combo) return false;
            combo.value = lang;
            combo.dispatchEvent(new Event('change', { bubbles: true }));
            return true;
        }

        function changeLanguage(lang, btn) {
            document.querySelectorAll('.language-btn').forEach(function (b) {
                b.classList.remove('active');
            });
            btn.classList.add('active');

            var count = 0;
            var timer = setInterval(function () {
                var done = triggerTranslate(lang);
                hideGoogleBar();
                count++;
                if (done || count > 20) clearInterval(timer);
            }, 200);
        }

        function hideGoogleBar() {
            document.body.style.top = '0px';
            var banners = document.querySelectorAll('.goog-te-banner-frame, iframe.skiptranslate');
            for (var i = 0; i < banners.length; i++) {
                banners[i].style.display = 'none';
                banners[i].style.height = '0';
            }
        }

        setInterval(hideGoogleBar, 300);

        // Global helper to convert plain text URLs into safe clickable HTML links
        if (typeof window.formatPostContent !== 'function') {
            window.formatPostContent = function(text) {
                if (!text) return '';
                const escaped = String(text)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');

                const urlPattern = /(https?:\/\/[^\s<]+[^<.,:;"')\]\s]|www\.[^\s<]+[^<.,:;"')\]\s])/gi;

                return escaped.replace(urlPattern, function(matchedUrl) {
                    var href = matchedUrl;
                    if (/^www\./i.test(href)) {
                        href = 'https://' + href;
                    }
                    return '<a href="' + href + '" target="_blank" rel="noopener noreferrer" class="text-amber-600 hover:text-amber-700 underline font-semibold break-all inline cursor-pointer" onclick="event.stopPropagation()">' + matchedUrl + '</a>';
                });
            };
        }
    </script>

    <script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</div>
