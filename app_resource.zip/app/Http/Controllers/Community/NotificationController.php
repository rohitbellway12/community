<?php

namespace App\Http\Controllers\Community;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;

class NotificationController extends Controller
{
    /**
     * Get latest notifications for notification dropdown.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $notifications = $user->notifications()
            ->latest()
            ->take(10)
            ->get()
            ->map(function ($notification) {
                return [
                    'id' => $notification->id,

                    'type' => $notification->type,

                    'message' => $notification->data['message']
                        ?? 'You have a new notification.',

                    'created_at' => $notification->created_at
                        ->diffForHumans(),

                    'read' => $notification->read_at !== null,

                    'read_at' => $notification->read_at,

                    'data' => $notification->data,
                ];
            })
            ->values();

        $unreadCount = $user
            ->unreadNotifications()
            ->count();

        return response()->json([
            'success' => true,

            'data' => [
                'notifications' => $notifications,

                'unread_count' => $unreadCount,
            ],
        ]);
    }


    public function page(Request $request): View
{
    $user = $request->user();

    $notifications = $user->notifications()
        ->latest()
        ->get();

    $unreadCount = $user
        ->unreadNotifications()
        ->count();

    return view('community.notifications', [
        'notifications' => $notifications,
        'unreadCount' => $unreadCount,
    ]);
}


    /**
     * Get unread notification count only.
     */
    public function unreadCount(Request $request): JsonResponse
    {
        $count = $request->user()
            ->unreadNotifications()
            ->count();

        return response()->json([
            'success' => true,
            'unread_count' => $count,
        ]);
    }


    /**
     * Mark one notification as read.
     */
    public function markAsRead(
        Request $request,
        string $id
    ): JsonResponse {

        $notification = $request->user()
            ->notifications()
            ->where('id', $id)
            ->firstOrFail();

        if ($notification->read_at === null) {
            $notification->markAsRead();
        }

        return response()->json([
            'success' => true,
            'message' => 'Notification marked as read.',
            'unread_count' => $request->user()
                ->unreadNotifications()
                ->count(),
        ]);
    }


    /**
     * Delete a specific notification.
     */
    public function destroy(Request $request, string $id): JsonResponse
    {
        $notification = $request->user()
            ->notifications()
            ->where('id', $id)
            ->first();

        if ($notification) {
            $notification->delete();
        }

        return response()->json([
            'success' => true,
            'message' => 'Notification deleted successfully.',
            'unread_count' => $request->user()
                ->unreadNotifications()
                ->count(),
        ]);
    }


    /**
     * Mark all notifications as read.
     */
    public function markAllAsRead(
        Request $request
    ): JsonResponse {

        $request->user()
            ->unreadNotifications
            ->markAsRead();

        return response()->json([
            'success' => true,
            'message' => 'All notifications marked as read.',
            'unread_count' => 0,
        ]);
    }
}