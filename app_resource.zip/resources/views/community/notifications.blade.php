@props([
    'title' => 'Notifications | REIAC Community',
    'user' => auth()->user(),
    'notificationsCount' => 0,
    'topContributors' => collect(),
    'trendingTopics' => collect(),
    'categories' => collect(),
    'tags' => collect(),
])

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}"
      class="bg-[#f3f4f6]"
      x-data="{ mobileMenuOpen: false }">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        [x-cloak] {
            display: none !important;
        }

        html,
        body {
            margin: 0;
            min-height: 100%;
        }

        body {
            background: #f3f4f6;
        }

        .notification-page {
            min-height: 100vh;
        }

        .notification-card {
            transition: background-color .18s ease, box-shadow .18s ease;
        }

        .notification-card:hover {
            box-shadow: 0 4px 18px rgba(15, 23, 42, .06);
        }

        @media (max-width: 1023px) {
            .notification-main {
                padding-bottom: 88px !important;
            }
        }
    </style>
</head>

<body class="min-h-screen bg-[#f3f4f6] font-sans text-slate-800 antialiased selection:bg-amber-500 selection:text-white">

    {{-- COMMUNITY TOPBAR --}}
    <div class="sticky top-0 z-50">
        <x-community.topbar
            :notifications-count="$notificationsCount ?? 0"
            :user="$user"
        />
    </div>

    {{-- MOBILE SIDEBAR OVERLAY --}}
    <div
        x-show="mobileMenuOpen"
        x-cloak
        class="fixed inset-0 z-[60] lg:hidden flex"
    >
        <div
            @click="mobileMenuOpen = false"
            x-show="mobileMenuOpen"
            x-transition.opacity
            class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
        ></div>

        <div
            x-show="mobileMenuOpen"
            x-transition:enter="transition ease-out duration-300 transform"
            x-transition:enter-start="-translate-x-full"
            x-transition:enter-end="translate-x-0"
            x-transition:leave="transition ease-in duration-200 transform"
            x-transition:leave-start="translate-x-0"
            x-transition:leave-end="-translate-x-full"
            class="relative z-10 flex h-full w-80 max-w-[85%] flex-col overflow-y-auto bg-white shadow-2xl"
        >
            @auth
                @php
                    $mobileProfile = $user?->profile;
                    $mobileAvatar = $mobileProfile?->avatar
                        ? asset('storage/' . $mobileProfile->avatar)
                        : 'https://ui-avatars.com/api/?name=' . urlencode($user?->name ?? 'User') . '&background=0c1b33&color=fff';
                @endphp

                <div class="flex items-center gap-3 border-b border-slate-100 p-4">
                    <img
                        src="{{ $mobileAvatar }}"
                        alt="{{ $user?->name ?? 'User' }}"
                        class="h-10 w-10 rounded-full object-cover"
                    >

                    <div class="min-w-0">
                        <div class="truncate text-sm font-bold text-slate-900">
                            {{ $user?->name }}
                        </div>

                        <a
                            href="{{ route('community.profile', $user?->profile?->username ?? $user?->id) }}"
                            class="text-xs font-semibold text-amber-600 hover:underline"
                        >
                            View Profile
                        </a>
                    </div>
                </div>
            @endauth

            <nav class="space-y-1 p-3 text-sm font-medium text-slate-600">
                <a
                    href="{{ route('community.index') }}"
                    class="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-slate-50"
                >
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="M3 12l9-9 9 9M5 10v10h14V10M9 20v-6h6v6"/>
                    </svg>
                    Community
                </a>

                @auth
                    <a
                        href="{{ route('community.notifications') }}"
                        class="flex items-center gap-3 rounded-xl bg-slate-50 px-3 py-2.5 font-semibold text-slate-900"
                    >
                        <svg class="h-4 w-4 text-amber-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                  d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                        Notifications
                    </a>
                @endauth

                <a
                    href="{{ route('community.index') }}"
                    class="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-slate-50"
                >
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a2 2 0 01-2-.586M7 7V6a2 2 0 012-2h8a2 2 0 012 2v6a2 2 0 01-2 2h-4l-4 4v-4H7a2 2 0 01-2-2V7h2z"/>
                    </svg>
                    Discussions
                </a>

                @auth
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button
                            type="submit"
                            class="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-red-600 hover:bg-red-50"
                        >
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                      d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                            </svg>
                            Logout
                        </button>
                    </form>
                @endauth
            </nav>
        </div>
    </div>

    {{-- MAIN COMMUNITY LAYOUT --}}
    <main class="notification-main mx-auto grid w-full max-w-[1520px] grid-cols-1 items-start gap-6 px-4 py-6 lg:grid-cols-[280px_minmax(0,1fr)_330px] xl:grid-cols-[300px_minmax(0,1fr)_360px] lg:px-6">

        {{-- LEFT SIDEBAR --}}
        <aside class="hidden lg:block">
            <x-community.sidebar
                :top-contributors="$topContributors ?? collect()"
                :categories="$categories ?? collect()"
                :tags="$tags ?? collect()"
            />
        </aside>

        {{-- CENTER --}}
        <section class="min-w-0 space-y-5">

            {{-- Page Header --}}
            <div class="rounded-2xl border border-slate-200/70 bg-white p-5 shadow-sm sm:p-6">
                <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

                    <div>
                        <div class="flex items-center gap-2">
                            <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
                                <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                          d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                                </svg>
                            </div>

                            <h1 class="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
                                Notifications
                            </h1>
                        </div>

                        <p class="mt-2 text-sm text-slate-500">
                            All your community notifications, including read and unread activity.
                        </p>
                    </div>

                    <div class="flex flex-wrap items-center justify-end gap-2">
                        <span class="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-600">
                            {{ $notifications->count() }} total
                        </span>

                        @if($unreadCount > 0)
                            <span class="rounded-full bg-blue-100 px-3 py-1.5 text-xs font-semibold text-blue-700">
                                <span id="page-unread-count">{{ $unreadCount }}</span> unread
                            </span>

                            <button
                                type="button"
                                id="mark-all-notifications-read"
                                class="inline-flex items-center gap-1.5 rounded-xl bg-[#0b1329] px-3 py-2 text-xs font-bold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
                            >
                                <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                                </svg>
                                Mark all as read
                            </button>
                        @endif
                    </div>
                </div>
            </div>

            {{-- Notification List --}}
            <div class="overflow-hidden rounded-2xl border border-slate-200/70 bg-white shadow-sm">

                @forelse($notifications as $notification)

                    @php
                        $isUnread = $notification->read_at === null;
                        $data = is_array($notification->data) ? $notification->data : [];
                        $message = $data['message'] ?? 'You have a new notification.';
                        $notificationTitle = $data['title'] ?? 'Notification';
                        $type = strtolower((string) ($notification->type ?? ''));
                        $url = $data['url'] ?? null;
                    @endphp

                    <article
                        class="notification-card border-b border-slate-100 p-4 last:border-b-0 sm:p-5 {{ $isUnread ? 'bg-blue-50/40' : 'bg-white' }}"
                    >
                        <div class="flex gap-3 sm:gap-4">

                            {{-- Icon --}}
                            <div class="shrink-0">
                                <div class="flex h-11 w-11 items-center justify-center rounded-full
                                    {{ $isUnread ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500' }}">

                                    @if(str_contains($type, 'comment'))
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                  d="M8 10h8M8 14h5m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                        </svg>
                                    @elseif(str_contains($type, 'like'))
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M14 9V5a3 3 0 00-6 0v4m0 0H5a2 2 0 00-2 2v7a2 2 0 002 2h9.5a2 2 0 001.94-1.515L18.5 12A2 2 0 0016.56 9H14z"/>
                                        </svg>
                                    @elseif(str_contains($type, 'follow'))
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M15 20a6 6 0 00-12 0m6-10a4 4 0 100-8 4 4 0 000 8zm6 3v6m3-3h-6"/>
                                        </svg>
                                    @elseif(str_contains($type, 'reply'))
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M9 17l-5-5 5-5m-5 5h10a6 6 0 016 6v1"/>
                                        </svg>
                                    @else
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                                        </svg>
                                    @endif
                                </div>
                            </div>

                            {{-- Content --}}
                            <div class="min-w-0 flex-1">
                                <div class="flex items-start justify-between gap-3">

                                    <div class="min-w-0">
                                        <h2 class="text-sm font-bold {{ $isUnread ? 'text-slate-900' : 'text-slate-700' }}">
                                            {{ $notificationTitle }}
                                        </h2>

                                        <p class="mt-1 text-sm leading-6 {{ $isUnread ? 'text-slate-700' : 'text-slate-500' }}">
                                            {{ $message }}
                                        </p>
                                    </div>

                                    @if($isUnread)
                                        <span
                                            class="mt-1 h-2.5 w-2.5 shrink-0 rounded-full bg-blue-600"
                                            title="Unread"
                                        ></span>
                                    @endif
                                </div>

                                <div class="mt-3 flex flex-wrap items-center gap-2.5">
                                    <span class="text-xs text-slate-400">
                                        {{ $notification->created_at?->diffForHumans() }}
                                    </span>

                                    @if($isUnread)
                                        <span
                                            data-notification-status="{{ $notification->id }}"
                                            class="notification-status rounded-full bg-blue-100 px-2.5 py-1 text-[11px] font-semibold text-blue-700"
                                        >
                                            Unread
                                        </span>

                                        <button
                                            type="button"
                                            data-mark-read="{{ $notification->id }}"
                                            class="mark-notification-read inline-flex items-center gap-1 rounded-lg border border-blue-200 bg-white px-2.5 py-1.5 text-[11px] font-bold text-blue-600 transition hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-60"
                                        >
                                            <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                                            </svg>
                                            Mark as read
                                        </button>
                                    @else
                                        <span
                                            data-notification-status="{{ $notification->id }}"
                                            class="notification-status rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-500"
                                        >
                                            Read
                                        </span>
                                    @endif

                                    @if($url)
                                        <a
                                            href="{{ $url }}"
                                            class="ml-auto inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-bold text-blue-600 transition hover:bg-blue-50 hover:text-blue-700"
                                        >
                                            View
                                            <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                      d="M9 5l7 7-7 7"/>
                                            </svg>
                                        </a>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </article>

                @empty

                    <div class="px-6 py-16 text-center sm:py-20">
                        <div class="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-400">
                            <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"
                                      d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                            </svg>
                        </div>

                        <h2 class="mt-4 text-base font-bold text-slate-800">
                            No notifications yet
                        </h2>

                        <p class="mx-auto mt-1 max-w-sm text-sm text-slate-500">
                            When someone interacts with your posts, comments, or profile, you'll see the activity here.
                        </p>

                        <a
                            href="{{ route('community.index') }}"
                            class="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#0b1329] px-4 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
                        >
                            Go to Community
                        </a>
                    </div>

                @endforelse
            </div>
        </section>

        {{-- RIGHT SIDEBAR --}}
        <aside class="hidden lg:block">
            <x-community.rightbar
                :user="$user"
                :trending-topics="$trendingTopics ?? collect()"
            />
        </aside>
    </main>

    {{-- MOBILE BOTTOM NAVIGATION --}}
    <div class="fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around border-t border-slate-200 bg-white px-4 py-2 shadow-lg lg:hidden">

        <a
            href="{{ route('community.index') }}"
            class="flex flex-col items-center gap-1 text-slate-500"
        >
            <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 011-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 011 1m-6 0h6"/>
            </svg>
            <span class="text-[10px] font-medium">Home</span>
        </a>

        <a
            href="{{ route('community.notifications') }}"
            class="flex flex-col items-center gap-1 font-bold text-[#0b1329]"
        >
            <div class="relative">
                <svg class="h-5 w-5 text-amber-500" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                </svg>

                @if($unreadCount > 0)
                    <span class="absolute -right-2 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">
                        {{ $unreadCount > 99 ? '99+' : $unreadCount }}
                    </span>
                @endif
            </div>

            <span class="text-[10px]">Notifications</span>
        </a>

        <button
            type="button"
            @click.prevent="
                @auth
                    $dispatch('open-post-modal')
                @else
                    window.dispatchEvent(new CustomEvent('open-login-modal'))
                @endauth
            "
            class="flex flex-col items-center justify-center -mt-5 focus:outline-none"
        >
            <div class="flex h-12 w-12 items-center justify-center rounded-full border-4 border-[#f3f4f6] bg-[#0b1329] text-white shadow-lg">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 5v14M5 12h14"/>
                </svg>
            </div>
            <span class="mt-1 text-[10px] font-medium text-slate-500">Create</span>
        </button>

        @auth
            <a
                href="{{ route('community.profile', $user?->profile?->username ?? $user?->id) }}"
                class="flex flex-col items-center gap-1 text-slate-500"
            >
                <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M20 21a8 8 0 00-16 0m8-10a4 4 0 100-8 4 4 0 000 8z"/>
                </svg>
                <span class="text-[10px] font-medium">Profile</span>
            </a>
        @else
            <a
                href="{{ route('login') }}"
                class="flex flex-col items-center gap-1 text-slate-500"
            >
                <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4m-4-4l4-4m0 0l-4-4m4 4H3"/>
                </svg>
                <span class="text-[10px] font-medium">Login</span>
            </a>
        @endauth

    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const csrfToken =
                document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

            const unreadCountElement = document.getElementById('page-unread-count');
            const markAllButton = document.getElementById('mark-all-notifications-read');

            function updateUnreadCount(decrement = false) {
                if (!unreadCountElement) return;

                let count = Number(unreadCountElement.textContent || 0);

                if (decrement) {
                    count = Math.max(0, count - 1);
                }

                unreadCountElement.textContent = count;

                if (count === 0) {
                    if (markAllButton) {
                        markAllButton.remove();
                    }

                    const unreadBadge = unreadCountElement.closest('span.rounded-full');
                    if (unreadBadge) {
                        unreadBadge.remove();
                    }
                }
            }

            async function markNotificationAsRead(notificationId, button) {
                if (!notificationId || button?.disabled) return;

                if (button) {
                    button.disabled = true;
                }

                try {
                    const response = await fetch(
                        "{{ url('/community/notifications') }}/" +
                        notificationId +
                        "/read",
                        {
                            method: "PATCH",
                            headers: {
                                "Accept": "application/json",
                                "X-CSRF-TOKEN": csrfToken,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        }
                    );

                    if (!response.ok) {
                        throw new Error("Unable to mark notification as read.");
                    }

                    const notificationCard = button?.closest('.notification-card');

                    if (notificationCard) {
                        notificationCard.classList.remove('bg-blue-50/40');
                        notificationCard.classList.add('bg-white');

                        const unreadDot = notificationCard.querySelector(
                            '[title="Unread"]'
                        );

                        if (unreadDot) {
                            unreadDot.remove();
                        }

                        const status = notificationCard.querySelector(
                            '[data-notification-status="' + notificationId + '"]'
                        );

                        if (status) {
                            status.textContent = "Read";
                            status.className =
                                "notification-status rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-500";
                        }

                        button.remove();
                    }

                    updateUnreadCount(true);

                } catch (error) {
                    console.error("Mark notification as read error:", error);

                    if (button) {
                        button.disabled = false;
                    }

                    alert("Unable to mark this notification as read.");
                }
            }

            document.querySelectorAll('[data-mark-read]').forEach(function (button) {
                button.addEventListener('click', function (event) {
                    event.preventDefault();
                    event.stopPropagation();

                    markNotificationAsRead(
                        button.getAttribute('data-mark-read'),
                        button
                    );
                });
            });

            if (markAllButton) {
                markAllButton.addEventListener('click', async function () {
                    if (markAllButton.disabled) return;

                    markAllButton.disabled = true;

                    try {
                        const response = await fetch(
                            "{{ route('community.notifications.read-all') }}",
                            {
                                method: "PATCH",
                                headers: {
                                    "Accept": "application/json",
                                    "X-CSRF-TOKEN": csrfToken,
                                    "X-Requested-With": "XMLHttpRequest"
                                }
                            }
                        );

                        if (!response.ok) {
                            throw new Error("Unable to mark notifications as read.");
                        }

                        document.querySelectorAll('.notification-card').forEach(function (card) {
                            card.classList.remove('bg-blue-50/40');
                            card.classList.add('bg-white');

                            const unreadDot = card.querySelector('[title="Unread"]');
                            if (unreadDot) {
                                unreadDot.remove();
                            }

                            const status = card.querySelector('.notification-status');

                            if (status) {
                                status.textContent = "Read";
                                status.className =
                                    "notification-status rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-500";
                            }

                            const button = card.querySelector('[data-mark-read]');
                            if (button) {
                                button.remove();
                            }
                        });

                        if (unreadCountElement) {
                            unreadCountElement.textContent = "0";
                        }

                        const unreadBadge = unreadCountElement?.closest('span.rounded-full');
                        if (unreadBadge) {
                            unreadBadge.remove();
                        }

                        markAllButton.remove();

                    } catch (error) {
                        console.error("Mark all notifications error:", error);
                        markAllButton.disabled = false;
                        alert("Unable to mark notifications as read.");
                    }
                });
            }
        });
    </script>

</body>
</html>
